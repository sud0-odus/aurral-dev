import importlib.util
from pathlib import Path
import unittest
spec=importlib.util.spec_from_file_location('deploy',Path(__file__).with_name('deploy.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class TargetTests(unittest.TestCase):
    def test_same_container_is_supported(self):
        m.validate_targets(109,109,{'memory':'4096','ostype':'debian'})
    def test_small_container_is_rejected(self):
        with self.assertRaisesRegex(RuntimeError,'2 GB'):m.validate_targets(121,109,{'memory':'512'})
    def test_non_debian_is_rejected(self):
        with self.assertRaisesRegex(RuntimeError,'Debian'):m.validate_targets(121,109,{'memory':'2048','ostype':'alpine'})
    def test_separate_debian_container_is_accepted(self):m.validate_targets(121,109,{'memory':'2048','ostype':'debian'})
if __name__=='__main__':unittest.main()
