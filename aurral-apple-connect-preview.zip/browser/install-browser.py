#!/usr/bin/env python3
"""Install the isolated Apple sign-in service in a fresh Debian container."""
import argparse
import hashlib
import json
import ipaddress
import os
from pathlib import Path
import secrets
import shutil
import socket
import subprocess
import sys

ROOT = Path('/opt/aurral-apple-browser')

def run(*args): subprocess.run(args, check=True)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--install', action='store_true', required=True)
    parser.add_argument('--listen-lan', action='store_true')
    args=parser.parse_args()
    if os.geteuid()!=0: raise RuntimeError('Run as root inside the Debian application or browser container.')
    if Path('/etc/pve').exists():
        raise RuntimeError('Run inside a container, not on the Proxmox host.')
    if shutil.disk_usage('/opt').free < 2 * 1024**3:
        raise RuntimeError('At least 2 GiB free disk is needed for Chromium, its dependencies and the application backup.')
    if (ROOT/'bridge.py').exists(): raise RuntimeError('Browser service already installed; preserve its key and configuration before updating.')
    kit=Path(__file__).resolve().parent
    manifest=json.loads((kit/'manifest.json').read_text())
    for relative, expected in manifest['files'].items():
        candidate=kit/relative
        if not candidate.resolve().is_relative_to(kit.resolve()) or hashlib.sha256(candidate.read_bytes()).hexdigest()!=expected:
            raise RuntimeError('Browser kit checksum mismatch.')
    run('apt-get','update')
    run('apt-get','install','-y','--no-install-recommends','python3','python3-venv','chromium','xvfb','xauth','fonts-liberation','openssl','ca-certificates')
    try: import pwd;pwd.getpwnam('aurral-apple')
    except KeyError: run('useradd','--system','--home-dir','/var/lib/aurral-apple-browser','--shell','/usr/sbin/nologin','aurral-apple')
    ROOT.mkdir(mode=0o750,exist_ok=True)
    run('python3','-m','venv',str(ROOT/'venv'))
    run(str(ROOT/'venv/bin/python'),'-m','pip','install','playwright==1.62.0')
    shutil.copy2(kit/'bridge.py',ROOT/'bridge.py.new')
    (ROOT/'bridge.key').write_text(secrets.token_urlsafe(48)+'\n')
    hostname=socket.gethostname()
    addresses=[]
    for raw in subprocess.check_output(['hostname','-I'],text=True).split():
        try:
            ip=ipaddress.ip_address(raw)
            if not ip.is_loopback:addresses.append(str(ip))
        except ValueError:pass
    if not addresses:raise RuntimeError('The browser container needs a LAN IP address.')
    san='DNS:localhost,IP:127.0.0.1,DNS:'+hostname+','+','.join('IP:'+ip for ip in addresses)
    run('openssl','req','-x509','-newkey','rsa:2048','-nodes','-days','365','-keyout',str(ROOT/'server.key'),'-out',str(ROOT/'server.crt'),'-subj','/CN='+hostname,'-addext','subjectAltName='+san)
    for name in ['bridge.key','server.key']: os.chmod(ROOT/name,0o600)
    run('chown','-R','root:aurral-apple',str(ROOT))
    for name in ['bridge.key','server.key']: os.chmod(ROOT/name,0o640)
    home=Path('/var/lib/aurral-apple-browser');home.mkdir(mode=0o700,exist_ok=True)
    run('chown','aurral-apple:aurral-apple',str(home))
    shutil.copy2(kit/'aurral-apple-browser.service',Path('/etc/systemd/system/aurral-apple-browser.service'))
    if args.listen_lan:
        override=Path('/etc/systemd/system/aurral-apple-browser.service.d');override.mkdir(exist_ok=True)
        (override/'listen.conf').write_text('[Service]\nEnvironment=APPLE_BROWSER_BIND=0.0.0.0\n')
    os.replace(ROOT/'bridge.py.new',ROOT/'bridge.py')
    run('systemctl','daemon-reload');run('systemctl','enable','--now','aurral-apple-browser.service')
    run('systemctl','is-active','--quiet','aurral-apple-browser.service')
    print('PASS: Apple browser service active. No Chromium session starts until Connect Apple Music is clicked.')
    print('Service URL: https://'+(addresses[0] if args.listen_lan else '127.0.0.1')+':3334/')
    print('Pairing files (transfer privately to CT109): '+str(ROOT/'bridge.key')+' and '+str(ROOT/'server.crt'))
    print('Limits: half of one CPU, 1024 MiB service memory, no swap. Browser sign-in limit 10 minutes; closed-client timeout 90 seconds.')

if __name__=='__main__':
    try:main()
    except Exception as e:print('STOPPED: '+str(e),file=sys.stderr);sys.exit(1)
