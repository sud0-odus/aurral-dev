#!/usr/bin/env python3
"""On-demand Apple sign-in bridge. Credentials never leave this service."""
import base64
import collections
import hmac
import ipaddress
import json
import os
from pathlib import Path
import queue
import secrets
import selectors
import shutil
import signal
import ssl
import subprocess
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, quote

WIDTH, HEIGHT = 1000, 760
SESSION_TTL = 3600
SIGNIN_TTL = 600
IDLE_TTL = 90
APPLE = 'https://amp-api.music.apple.com'
ALLOWED_DOMAINS = ('apple.com', 'apple.com.cn', 'mzstatic.com', 'cdn-apple.com', 'apple-cloudkit.com')


class BridgeError(Exception):
    def __init__(self, message, status=400):
        self.status = status
        super().__init__(message)


def allowed_url(url):
    p = urlsplit(url)
    if p.scheme in ('about', 'data', 'blob'):
        return True
    return p.scheme == 'https' and any(p.hostname == d or (p.hostname or '').endswith('.' + d) for d in ALLOWED_DOMAINS)


def artwork(attrs):
    art = attrs.get('artwork') or {}
    url = art.get('url') if isinstance(art, dict) else None
    return {'url': url, 'width': art.get('width'), 'height': art.get('height')} if isinstance(url, str) and allowed_url(url) else None


def validate_events(events):
    if not isinstance(events, list) or not 1 <= len(events) <= 32:
        raise BridgeError('Expected 1 to 32 input events')
    out = []
    for e in events:
        if not isinstance(e, dict):
            raise BridgeError('Invalid input event')
        kind = e.get('kind')
        if kind == 'click':
            x, y = e.get('x'), e.get('y')
            if not isinstance(x, (float, int)) or not isinstance(y, (float, int)) or not 0 <= x < WIDTH or not 0 <= y < HEIGHT:
                raise BridgeError('Invalid pointer position')
            out.append({'kind': kind, 'x': x, 'y': y})
        elif kind == 'text' and isinstance(e.get('text'), str) and 0 < len(e['text']) <= 2048:
            out.append({'kind': kind, 'text': e['text']})
        elif kind == 'key' and e.get('key') in {'Enter', 'Tab', 'Shift+Tab', 'Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Escape', 'Control+a', 'Home', 'End'}:
            out.append({'kind': kind, 'key': e['key']})
        elif kind == 'scroll' and isinstance(e.get('dy'), (int, float)) and -2000 <= e['dy'] <= 2000:
            out.append({'kind': kind, 'dy': e['dy']})
        else:
            raise BridgeError('Unsupported input event')
    return out


def kill_browser_tree(root):
    """Last-resort cleanup of this session's Playwright driver and descendants."""
    if not root: return
    parents = collections.defaultdict(list)
    for proc in Path('/proc').iterdir():
        if not proc.name.isdecimal(): continue
        try:
            fields = (proc/'stat').read_text().rsplit(') ', 1)[1].split()
            parents[int(fields[1])].append(int(proc.name))
        except (OSError, ValueError, IndexError): pass
    descendants = []
    def visit(pid):
        for child in parents.get(pid, []): visit(child)
        descendants.append(pid)
    visit(root)
    for pid in descendants:
        try: os.kill(pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError): pass


def ensure_memory_headroom():
    """Refuse a new browser when the CT is already under memory pressure."""
    try:
        root = Path('/sys/fs/cgroup')
        limit = (root/'memory.max').read_text().strip()
        if limit != 'max':
            spare = int(limit) - int((root/'memory.current').read_text())
            try:
                stats = dict(line.split() for line in (root/'memory.stat').read_text().splitlines())
                spare += max(0, int(stats.get('inactive_file', '0')))
            except (OSError, ValueError): pass
            if spare < 1280 * 1024 * 1024:
                raise BridgeError('Not enough free memory to start Apple sign-in safely. Try again when the server is less busy.', 503)
    except (OSError, ValueError):
        # The service's own 1 GiB hard memory cap still applies on older hosts.
        pass


class BrowserEngine:
    def __init__(self, start_url='https://music.apple.com/'):
        self.context = self.pw = self.display = self.profile = None
        self.bearer = None
        self.driver_pid = None
        try:
            self.profile = tempfile.TemporaryDirectory(prefix='aurral-apple-')
            os.chmod(self.profile.name, 0o700)
            env = dict(os.environ)
            headless = os.environ.get('APPLE_BROWSER_HEADLESS') == '1'
            if not headless:
                self.display = subprocess.Popen(['Xvfb', '-displayfd', '1', '-screen', '0', '1100x840x24', '-nolisten', 'tcp'], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
                with selectors.DefaultSelector() as selector:
                    selector.register(self.display.stdout, selectors.EVENT_READ)
                    if not selector.select(5):
                        raise RuntimeError('Display startup timed out')
                    number = self.display.stdout.readline().strip()
                if not number.isdecimal():
                    raise RuntimeError('Display startup failed')
                env['DISPLAY'] = ':' + number
            from playwright.sync_api import sync_playwright
            self.pw = sync_playwright().start()
            self.driver_pid = self.pw._impl_obj._connection._transport._proc.pid
            self.context = self.pw.chromium.launch_persistent_context(
                self.profile.name, executable_path=os.environ.get('APPLE_BROWSER_CHROMIUM', '/usr/bin/chromium'),
                headless=headless, env=env, viewport={'width': WIDTH, 'height': HEIGHT},
                accept_downloads=False, chromium_sandbox=os.environ.get('APPLE_BROWSER_CHROMIUM_SANDBOX') == '1',
                args=['--disable-dev-shm-usage', '--disable-blink-features=AutomationControlled'],
            )
            self.context.route('**/*', lambda route: route.continue_() if allowed_url(route.request.url) else route.abort())
            self.context.on('request', self.observe)
            self.page = self.context.pages[0] if self.context.pages else self.context.new_page()
            self.page.goto(start_url, wait_until='domcontentloaded', timeout=45000)
        except BaseException:
            self.close()
            raise

    def observe(self, request):
        host = urlsplit(request.url).hostname or ''
        if host != 'api.music.apple.com' and not (host.startswith('amp-api') and host.endswith('.music.apple.com')):
            return
        try: auth = request.all_headers().get('authorization', '')
        except Exception: return
        if auth.startswith('Bearer ') and len(auth) < 20000:
            self.bearer = auth

    def current_page(self):
        pages = [p for p in self.context.pages if not p.is_closed()]
        if not pages:
            raise BridgeError('Sign-in window closed', 410)
        page = pages[-1]
        if page.viewport_size != {'width': WIDTH, 'height': HEIGHT}: page.set_viewport_size({'width': WIDTH, 'height': HEIGHT})
        return page

    def tick(self):
        self.current_page().wait_for_timeout(50)

    def input(self, events):
        p = self.current_page()
        for e in events:
            if e['kind'] == 'click': p.mouse.click(e['x'], e['y'])
            elif e['kind'] == 'text': p.keyboard.insert_text(e['text'])
            elif e['kind'] == 'key': p.keyboard.press(e['key'])
            elif e['kind'] == 'scroll': p.mouse.wheel(0, e['dy'])

    def screenshot(self):
        return self.current_page().screenshot(type='jpeg', quality=65, timeout=5000)

    def authenticated_headers(self):
        if not self.bearer:
            return None
        user = next((c['value'] for c in self.context.cookies(['https://music.apple.com/']) if c['name'] == 'media-user-token'), None)
        if not user:
            return None
        headers = {'Authorization': self.bearer, 'Music-User-Token': user, 'Origin': 'https://music.apple.com', 'Referer': 'https://music.apple.com/'}
        try:
            response = self.context.request.get(APPLE + '/v1/me/library/playlists?limit=1', headers=headers, timeout=5000, max_redirects=0)
            body = response.json() if response.status == 200 else None
            return headers if isinstance(body, dict) and isinstance(body.get('data'), list) else None
        except Exception:
            return None

    def close(self):
        watchdog = threading.Timer(15, kill_browser_tree, args=(self.driver_pid,))
        watchdog.daemon = True
        watchdog.start()
        try:
            if self.context: self.context.close()
        finally:
            try:
                if self.pw: self.pw.stop()
            finally:
                if self.display:
                    self.display.terminate()
                    try: self.display.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        self.display.kill(); self.display.wait(timeout=5)
                if self.profile: self.profile.cleanup()
                self.context = self.pw = self.display = self.profile = None
                watchdog.cancel()


class Manager:
    def __init__(self, factory=BrowserEngine, clock=time.monotonic):
        self.factory, self.clock = factory, clock
        self.lock = threading.RLock()
        self.active = None
        self.sessions = {}
        self.connections = {}
        self.collections = threading.BoundedSemaphore(2)

    def _connection(self, user):
        saved = self.connections.get(user)
        if saved and saved['expires'] <= self.clock():
            self.connections.pop(user, None); saved = None
        return saved

    def status(self, user):
        with self.lock:
            saved = self._connection(user)
            return {'configured': True, 'connected': bool(saved), 'expiresInSeconds': max(0, int(saved['expires'] - self.clock())) if saved else 0}

    def start(self, user):
        with self.lock:
            if self.active:
                if self.active['user'] == user and not self.active['cancel'].is_set():
                    return self.public(self.active)
                raise BridgeError('Another sign-in is active. Try again when it finishes.', 409)
            ensure_memory_headroom()
            if len(self.connections) >= 32 and user not in self.connections:
                for uid in list(self.connections): self._connection(uid)
                if len(self.connections) >= 32: raise BridgeError('Connection capacity reached', 429)
            self.sessions = {k: v for k, v in self.sessions.items() if self.clock() - v['created'] < SIGNIN_TTL + 60}
            session = {'id': secrets.token_urlsafe(24), 'user': user, 'state': 'starting', 'created': self.clock(), 'seen': self.clock(), 'cancel': threading.Event(), 'events': queue.Queue(maxsize=16), 'image': None, 'message': None}
            self.sessions[session['id']] = self.active = session
            thread = threading.Thread(target=self.run, args=(session,), daemon=True)
            session['thread'] = thread
            thread.start()
            return self.public(session)

    def public(self, s):
        return {'id': s['id'], 'state': s['state'], 'message': s['message'], 'width': WIDTH, 'height': HEIGHT, 'browserRunning': self.active is s}

    def get(self, user, sid):
        with self.lock:
            s = self.sessions.get(sid)
            if not s or s['user'] != user: raise BridgeError('Sign-in session not found', 404)
            s['seen'] = self.clock()
            result = self.public(s)
            if s['image'] and s['state'] == 'signing_in': result['image'] = base64.b64encode(s['image']).decode('ascii')
            return result

    def input(self, user, sid, events):
        events = validate_events(events)
        with self.lock:
            self.get(user, sid)
            s = self.sessions[sid]
            if s['state'] != 'signing_in': raise BridgeError('Sign-in is not accepting input', 409)
            try: s['events'].put_nowait(events)
            except queue.Full: raise BridgeError('Sign-in input is busy; wait a moment.', 429)
        return {'ok': True}

    def cancel(self, user, sid=None):
        with self.lock:
            if sid is None: self.connections.pop(user, None)
            s = self.sessions.get(sid) if sid else self.active
            if s and s['user'] == user:
                s['cancel'].set()
                if sid and self.connections.get(user, {}).get('sid') == sid: self.connections.pop(user, None)
            elif sid: raise BridgeError('Sign-in session not found', 404)
        return {'ok': True}

    def run(self, s):
        engine, captured, outcome = None, None, 'cancelled'
        try:
            engine = self.factory()
            with self.lock: s['state'] = 'signing_in'
            next_image = next_auth = 0
            while not s['cancel'].is_set():
                now = self.clock()
                if now - s['created'] >= SIGNIN_TTL or now - s['seen'] >= IDLE_TTL:
                    outcome = 'expired'; break
                try: engine.input(s['events'].get_nowait())
                except queue.Empty: pass
                engine.tick()
                if now >= next_auth:
                    captured = engine.authenticated_headers(); next_auth = now + 5
                    if captured: outcome = 'connected'; break
                if now >= next_image:
                    image = engine.screenshot()
                    if len(image) > 1500000: raise BridgeError('Sign-in screen exceeded the image limit')
                    with self.lock: s['image'] = image
                    next_image = now + 0.8
        except Exception as error:
            print('Apple sign-in failed: '+type(error).__name__+'; state='+s['state'], flush=True)
            outcome = 'failed'
            with self.lock: s['message'] = 'Hosted browser could not complete sign-in. Cancel and try again.'
        finally:
            with self.lock: s['state'] = 'closing'; s['image'] = None
            try:
                if engine: engine.close()
            except Exception:
                outcome = 'failed'; captured = None
                with self.lock: s['message'] = 'Browser cleanup failed. Restart the Apple browser service.'
            with self.lock:
                if s['cancel'].is_set(): outcome = 'cancelled'; captured = None
                if captured and outcome == 'connected': self.connections[s['user']] = {'headers': captured, 'expires': self.clock() + SESSION_TTL, 'sid': s['id']}
                s['state'] = outcome
                if self.active is s: self.active = None
                print('Apple sign-in browser closed; result='+outcome, flush=True)
                while not s['events'].empty():
                    try: s['events'].get_nowait()
                    except queue.Empty: break

    def inventory(self, user):
        if not self.collections.acquire(blocking=False): raise BridgeError('Playlist collection is busy. Try again shortly.', 409)
        try: return self._inventory(user)
        finally: self.collections.release()

    def _inventory(self, user):
        with self.lock:
            saved = self._connection(user)
            if not saved: raise BridgeError('Connect Apple Music again to read playlists.', 409)
            headers = dict(saved['headers'])
        from urllib.request import Request, build_opener, HTTPRedirectHandler
        class NoRedirect(HTTPRedirectHandler):
            def redirect_request(self, *_): raise BridgeError('Unexpected Apple redirect.', 502)
        opener = build_opener(NoRedirect())
        from urllib.error import HTTPError
        results, path, seen = [], '/v1/me/library/playlists?limit=100', set()
        deadline = self.clock() + 60
        for _ in range(30):
            if self.clock() >= deadline: raise BridgeError('Playlist collection timed out. Try again.', 504)
            if path in seen: raise BridgeError('Apple returned a repeated page.', 502)
            seen.add(path)
            try:
                with opener.open(Request(APPLE + path, headers=headers), timeout=20) as response:
                    raw = response.read(2000001)
                if len(raw) > 2000000: raise BridgeError('Apple metadata response too large.', 502)
                body = json.loads(raw)
            except HTTPError as e:
                if e.code in (401, 403):
                    with self.lock: self.connections.pop(user, None)
                    raise BridgeError('Apple session expired. Connect again.', 409)
                raise BridgeError('Apple metadata could not be read.', 502)
            data = body.get('data')
            if not isinstance(data, list): raise BridgeError('Apple returned invalid playlist data.', 502)
            for item in data:
                attrs = item.get('attributes') or {}
                results.append({'id': str(item.get('id', ''))[:150], 'name': str(attrs.get('name') or '')[:200], 'artwork': artwork(attrs)})
            if len(results) > 3000: raise BridgeError('Playlist collection exceeded 3000 entries.', 422)
            nxt = body.get('next')
            if not nxt: return {'playlists': results, 'complete': True}
            parsed = urlsplit(nxt)
            if (parsed.netloc and parsed.netloc != 'amp-api.music.apple.com') or parsed.scheme not in ('', 'https') or parsed.path != '/v1/me/library/playlists' or parsed.fragment:
                raise BridgeError('Apple returned an unexpected pagination link.', 502)
            path = parsed.path + ('?' + parsed.query if parsed.query else '')
        raise BridgeError('Playlist collection exceeded 30 pages.', 422)

    def shutdown(self):
        with self.lock:
            active = self.active
            if active: active['cancel'].set()
            self.connections.clear()
        if active: active['thread'].join(timeout=60)


class Handler(BaseHTTPRequestHandler):
    manager = None
    secret = None
    def log_message(self, *_): pass
    def reply(self, status, body):
        data = json.dumps(body).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers(); self.wfile.write(data)
    def handle_request(self):
        try:
            if not hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + self.secret): raise BridgeError('Unauthorized', 401)
            parts = urlsplit(self.path).path.strip('/').split('/')
            if len(parts) < 4 or parts[:2] != ['v1', 'users'] or not parts[2].isdecimal() or not 1 <= int(parts[2]) <= 2147483647: raise BridgeError('Not found', 404)
            user, action = str(int(parts[2])), parts[3:]
            body = {}
            if self.command == 'POST':
                size = int(self.headers.get('Content-Length', '0'))
                if not 0 < size <= 16000: raise BridgeError('Invalid request size', 413)
                body = json.loads(self.rfile.read(size))
            if action == ['status'] and self.command == 'GET': result = self.manager.status(user)
            elif action == ['connect'] and self.command == 'POST': result = self.manager.start(user)
            elif action == ['disconnect'] and self.command == 'POST': result = self.manager.cancel(user)
            elif action == ['playlists'] and self.command == 'GET': result = self.manager.inventory(user)
            elif len(action) in (2, 3) and action[0] == 'session' and len(action[1]) <= 80:
                sid = action[1]
                if len(action) == 2 and self.command == 'GET': result = self.manager.get(user, sid)
                elif action[2:] == ['input'] and self.command == 'POST': result = self.manager.input(user, sid, body.get('events'))
                elif action[2:] == ['cancel'] and self.command == 'POST': result = self.manager.cancel(user, sid)
                else: raise BridgeError('Not found', 404)
            else: raise BridgeError('Not found', 404)
            self.reply(200, result)
        except BridgeError as e: self.reply(e.status, {'error': str(e)})
        except (ValueError, TypeError): self.reply(400, {'error': 'Invalid request'})
        except Exception: self.reply(502, {'error': 'Apple browser request failed'})
    do_GET = do_POST = handle_request


def main():
    secret = Path(os.environ['APPLE_BROWSER_KEY_FILE']).read_text().strip()
    if len(secret) < 32: raise RuntimeError('Bridge key is too short')
    manager = Manager()
    Handler.manager, Handler.secret = manager, secret
    server = ThreadingHTTPServer((os.environ.get('APPLE_BROWSER_BIND', '0.0.0.0'), int(os.environ.get('APPLE_BROWSER_PORT', '3334'))), Handler)
    server.daemon_threads = True
    tls = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    tls.minimum_version = ssl.TLSVersion.TLSv1_2
    tls.load_cert_chain(os.environ['APPLE_BROWSER_CERT_FILE'], os.environ['APPLE_BROWSER_TLS_KEY_FILE'])
    server.socket = tls.wrap_socket(server.socket, server_side=True)
    def stop(*_): threading.Thread(target=server.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, stop); signal.signal(signal.SIGINT, stop)
    try: server.serve_forever()
    finally: manager.shutdown(); server.server_close()

if __name__ == '__main__': main()
