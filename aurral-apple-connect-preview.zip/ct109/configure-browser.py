#!/usr/bin/env python3
"""Pair Aurral with its dedicated browser service. Does not print credentials."""
import argparse
import json
import os
from pathlib import Path
import shutil
import ssl
import tempfile
import urllib.request
import urllib.parse

def configure(url, key_file, ca_file, database):
    parsed=urllib.parse.urlsplit(url)
    if parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ('','/'):
        raise RuntimeError('Use the HTTPS base URL of the Apple browser service.')
    if not database.is_file(): raise RuntimeError('Aurral database not found.')
    secret=key_file.read_text().strip()
    if len(secret)<32:raise RuntimeError('Browser service key is invalid.')
    context=ssl.create_default_context(cafile=str(ca_file))
    request=urllib.request.Request(url.rstrip('/')+'/v1/users/1/status',headers={'Authorization':'Bearer '+secret})
    with urllib.request.urlopen(request,context=context,timeout=10) as response:
        body=json.load(response)
    if body.get('configured') is not True:raise RuntimeError('Unexpected browser service response.')
    target=database.resolve().parent/'apple-browser'
    target.mkdir(mode=0o700,exist_ok=True)
    if target.is_symlink():raise RuntimeError('Refusing a symlinked configuration directory.')
    config={'url':url.rstrip('/')+'/', 'keyFile':str(target/'bridge.key'),'caFile':str(target/'server.crt')}
    current=target/'config.json'
    if current.exists():
        old=json.loads(current.read_text())
        if old!=config or (target/'bridge.key').read_text().strip()!=secret or (target/'server.crt').read_bytes()!=ca_file.read_bytes():
            raise RuntimeError('A different Apple browser pairing exists. Preserve it before replacing.')
        return
    for filename,data in [('bridge.key',(secret+'\n').encode()),('server.crt',ca_file.read_bytes()),('config.json',(json.dumps(config,indent=2)+'\n').encode())]:
        fd,tmp=tempfile.mkstemp(prefix='.pair-',dir=target)
        try:
            with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
            os.chmod(tmp,0o600);os.replace(tmp,target/filename)
        finally:
            if os.path.exists(tmp):os.unlink(tmp)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--url',required=True);p.add_argument('--key-file',required=True,type=Path);p.add_argument('--ca-file',required=True,type=Path)
    p.add_argument('--db',type=Path,default=Path('/opt/aurral_data/aurral.db'));a=p.parse_args()
    if os.geteuid()!=0:raise RuntimeError('Run inside CT109 as root.')
    configure(a.url,a.key_file,a.ca_file,a.db)
    print('PASS: HTTPS trust and service key verified. Apple browser pairing saved privately; no Apple credentials were copied.')

if __name__=='__main__':
    try:main()
    except Exception as e:raise SystemExit('STOPPED: '+str(e))
