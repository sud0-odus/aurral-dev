import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import io
s=importlib.util.spec_from_file_location('pairing',Path(__file__).with_name('configure-browser.py'))
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class PairingTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
        self.db=self.root/'aurral.db';self.db.write_bytes(b'original database')
        self.key=self.root/'key';self.key.write_text('a'*48)
        self.ca=self.root/'ca';self.ca.write_text('test CA')
    def pair(self):
        with patch.object(m.ssl,'create_default_context',return_value=object()),patch.object(m.urllib.request,'urlopen',return_value=io.BytesIO(b'{"configured":true,"connected":false}')):
            m.configure('https://127.0.0.1:3334/',self.key,self.ca,self.db)
    def test_pairing_is_private_and_does_not_modify_database(self):
        self.pair();folder=self.root/'apple-browser'
        self.assertEqual(folder.stat().st_mode&0o777,0o700)
        for p in folder.iterdir():self.assertEqual(p.stat().st_mode&0o777,0o600)
        self.assertEqual(self.db.read_bytes(),b'original database')
        cfg=json.loads((folder/'config.json').read_text());self.assertNotIn('a'*48,json.dumps(cfg))
    def test_repeated_identical_pairing_is_safe(self):self.pair();self.pair()
    def test_different_pairing_is_not_overwritten(self):
        self.pair();self.key.write_text('b'*48)
        with self.assertRaisesRegex(RuntimeError,'different'):self.pair()
        self.assertEqual((self.root/'apple-browser/bridge.key').read_text().strip(),'a'*48)
    def test_remote_http_and_embedded_credentials_are_rejected(self):
        for url in ['http://127.0.0.1:3334/','https://user:password@localhost/']:
            with self.assertRaises(RuntimeError):m.configure(url,self.key,self.ca,self.db)
        self.assertFalse((self.root/'apple-browser').exists())
if __name__=='__main__':unittest.main()
