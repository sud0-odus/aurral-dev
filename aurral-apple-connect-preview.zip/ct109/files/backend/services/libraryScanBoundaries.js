import path from "node:path";

export function isWithinLibraryPath(root, candidate) {
  const relative = path.relative(path.resolve(root), path.resolve(candidate));
  return relative === "" ||
    (relative !== ".." && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative));
}

export function normalizeLibraryScanExclusions(value, { strict = false } = {}) {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > 64) {
    if (strict) throw new Error("Library scan exclusions must be a list of at most 64 folder paths.");
    return [];
  }
  const roots = new Set();
  for (const entry of value) {
    if (typeof entry === "string" && !entry.trim()) continue;
    if (typeof entry !== "string" || entry.length > 4096 || /[\0\r\n]/.test(entry) || !path.isAbsolute(entry.trim())) {
      if (strict) throw new Error("Each library scan exclusion must be an absolute local folder path.");
      continue;
    }
    const normalized = path.normalize(entry.trim());
    if (normalized === path.parse(normalized).root) {
      if (strict) throw new Error("The filesystem root cannot be a library scan exclusion.");
      continue;
    }
    roots.add(normalized.replace(/[\\/]+$/, ""));
  }
  return [...roots].sort();
}

// Configuration is expressed in the local namespace, after any remote path
// mapping. Only the Lidarr view uses these exclusions; Aurral's own root keeps
// its existing behavior. This helper performs no filesystem I/O.
export function libraryScanExcludedRoots(source, roots = [], configured = []) {
  if (source !== "lidarr") return [];
  return normalizeLibraryScanExclusions(configured).filter((excluded) =>
    roots.some((root) => isWithinLibraryPath(root, excluded) || isWithinLibraryPath(excluded, root)));
}

export function isLibraryBoundaryExcluded(filePath, excludedRoots = []) {
  return excludedRoots.some((root) => isWithinLibraryPath(root, filePath));
}
