import fs from "node:fs";
import path from "node:path";
import https from "node:https";
import { resolveAurralDataDir } from "../config/data-dir.js";

export function loadAppleBrowserConfig() {
  let file = process.env.AURRAL_APPLE_BROWSER_CONFIG;
  if (!file) {
    const database = process.env.AURRAL_DB_PATH || path.join(resolveAurralDataDir(), "aurral.db");
    const dataDir = path.dirname(fs.realpathSync(database));
    file = path.join(dataDir, "apple-browser", "config.json");
  }
  if (!fs.existsSync(file)) return null;
  const raw = JSON.parse(fs.readFileSync(file, "utf8"));
  const url = new URL(raw.url);
  if (url.protocol !== "https:" || url.username || url.password || url.search || url.hash || url.pathname !== "/") {
    throw new Error("Invalid Apple browser service URL");
  }
  const key = fs.readFileSync(raw.keyFile, "utf8").trim();
  if (key.length < 32) throw new Error("Apple browser service key is invalid");
  return { url, key, ca: fs.readFileSync(raw.caFile) };
}

export function requestAppleBrowser(userId, action, body = null, { config = loadAppleBrowserConfig(), transport = https.request } = {}) {
  if (!config) return Promise.resolve({ status: 503, body: { error: "Apple Music connection is not configured." } });
  if (!Number.isSafeInteger(Number(userId)) || Number(userId) < 1 || !/^(status|connect|disconnect|playlists|session\/[A-Za-z0-9_-]{16,80}(\/(input|cancel))?)$/.test(action)) {
    throw new Error("Invalid Apple browser request");
  }
  const payload = body === null ? null : JSON.stringify(body);
  if (payload && Buffer.byteLength(payload) > 16000) return Promise.resolve({ status: 413, body: { error: "Sign-in input is too large." } });
  return new Promise((resolve, reject) => {
    const request = transport(new URL(`/v1/users/${Number(userId)}/${action}`, config.url), {
      method: payload === null ? "GET" : "POST", ca: config.ca,
      headers: { Authorization: `Bearer ${config.key}`, Accept: "application/json", ...(payload === null ? {} : { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(payload) }) },
    }, (response) => {
      const chunks = [];
      let size = 0;
      response.on("data", (chunk) => {
        size += chunk.length;
        if (size > 2100000) { request.destroy(new Error("Apple browser response too large")); return; }
        chunks.push(chunk);
      });
      response.on("end", () => {
        try { resolve({ status: response.statusCode || 502, body: JSON.parse(Buffer.concat(chunks).toString("utf8")) }); }
        catch { reject(new Error("Apple browser returned invalid data")); }
      });
      response.on("error", reject);
    });
    request.setTimeout(action === "playlists" ? 90000 : 10000, () => request.destroy(new Error("Apple browser request timed out")));
    request.on("error", reject);
    if (payload !== null) request.write(payload);
    request.end();
  });
}
