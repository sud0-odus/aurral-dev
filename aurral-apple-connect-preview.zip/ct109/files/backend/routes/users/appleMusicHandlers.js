import { requireAuth, requireUserAccount } from "../../middleware/requirePermission.js";
import { loadAppleBrowserConfig, requestAppleBrowser } from "../../services/appleBrowserClient.js";

export function registerAppleMusicConnection(router, { request = requestAppleBrowser, configured = () => Boolean(loadAppleBrowserConfig()) } = {}) {
  const forward = (action, { post = false } = {}) => async (req, res) => {
    res.set("Cache-Control", "no-store");
    try {
      if (action === "status" && !configured()) return res.json({ configured: false, connected: false });
      const target = typeof action === "function" ? action(req) : action;
      const body = post ? (target.endsWith("/input") ? { events: req.body?.events } : {}) : null;
      // User identity is ALWAYS taken from Aurral authentication, never the body.
      const result = await request(req.user.id, target, body);
      if (result.status === 401) return res.status(502).json({ error: "Apple Music service pairing needs to be checked by the administrator." });
      return res.status(result.status).json(result.body);
    } catch {
      return res.status(502).json({ error: "Apple Music connection service is unavailable." });
    }
  };
  const checkSession = (req, res, next) => /^[A-Za-z0-9_-]{16,80}$/.test(req.params.sid || "")
    ? next() : res.status(400).json({ error: "Invalid sign-in session" });
  const prefix = "/me/apple-music";
  router.get(`${prefix}/status`, requireAuth, requireUserAccount, forward("status"));
  router.post(`${prefix}/connect`, requireAuth, requireUserAccount, forward("connect", { post: true }));
  router.post(`${prefix}/disconnect`, requireAuth, requireUserAccount, forward("disconnect", { post: true }));
  router.get(`${prefix}/playlists`, requireAuth, requireUserAccount, forward("playlists"));
  router.get(`${prefix}/session/:sid`, requireAuth, requireUserAccount, checkSession, forward((req) => `session/${req.params.sid}`));
  router.post(`${prefix}/session/:sid/input`, requireAuth, requireUserAccount, checkSession, forward((req) => `session/${req.params.sid}/input`, { post: true }));
  router.post(`${prefix}/session/:sid/cancel`, requireAuth, requireUserAccount, checkSession, forward((req) => `session/${req.params.sid}/cancel`, { post: true }));
}
