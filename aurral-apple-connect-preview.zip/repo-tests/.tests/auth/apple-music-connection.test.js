import test from "node:test";
import assert from "node:assert/strict";
import express from "express";
import { setupIsolatedBackend, cleanupIsolatedState } from "../helpers/backendTestHarness.js";
const [state, { registerAppleMusicConnection }] = await setupIsolatedBackend("apple-music-connect", "backend/routes/users/appleMusicHandlers.js");
test.after(() => cleanupIsolatedState(state));
async function serverFor(t, dependencies) {
  const app = express(); app.use(express.json());
  app.use((req, _res, next) => { if (req.headers["x-test-user"]) req.user = { id: Number(req.headers["x-test-user"]), role: "user" }; next(); });
  registerAppleMusicConnection(app, dependencies);
  const server = app.listen(0, "127.0.0.1");
  await new Promise((resolve) => server.once("listening", resolve));
  t.after(() => new Promise((resolve) => { server.closeAllConnections(); server.close(resolve); }));
  return async (path, body, user = "2") => {
    const res = await fetch(`http://127.0.0.1:${server.address().port}/me/apple-music/${path}`, {
      method: body === undefined ? "GET" : "POST",
      headers: { Accept: "application/json", "Content-Type": "application/json", ...(user ? { "x-test-user": user } : {}) },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
    return { status: res.status, body: await res.json() };
  };
}
test("status reports an unconfigured optional integration", async (t) => {
  const get = await serverFor(t, { configured: () => false });
  assert.deepEqual(await get("status"), { status: 200, body: { configured: false, connected: false } });
});
test("sign-in uses authenticated identity and discards supplied user IDs and credentials", async (t) => {
  const calls = [];
  const get = await serverFor(t, { configured: () => true, request: async (...args) => { calls.push(args); return { status: 200, body: { id: "session" } }; } });
  await get("connect", { userId: 1, Authorization: "secret" }, "2");
  assert.deepEqual(calls, [[2, "connect", {}]]);
  await get("session/abcdefghijklmnop/input", { userId: 1, events: [{ kind: "key", key: "Enter" }], token: "secret" }, "3");
  assert.deepEqual(calls[1], [3, "session/abcdefghijklmnop/input", { events: [{ kind: "key", key: "Enter" }] }]);
});
test("anonymous and bypass identities cannot start sessions", async (t) => {
  let called = false;
  const get = await serverFor(t, { configured: () => true, request: async () => { called = true; } });
  assert.equal((await get("connect", {}, null)).status, 401);
  assert.equal((await get("connect", {}, "0")).status, 403);
  assert.equal(called, false);
});
test("invalid session paths fail before a bridge request", async (t) => {
  let called = false;
  const get = await serverFor(t, { request: async () => { called = true; } });
  assert.equal((await get("session/short")).status, 400); assert.equal(called, false);
});
test("transport errors do not expose service keys or URLs", async (t) => {
  const get = await serverFor(t, { configured: () => true, request: async () => { throw new Error("PRIVATE_KEY and PRIVATE_URL"); } });
  const res = await get("connect", {});
  assert.equal(res.status, 502); assert.ok(!JSON.stringify(res).includes("PRIVATE"));
});
test("playlist checks and disconnect remain user scoped", async (t) => {
  const calls = [];
  const get = await serverFor(t, { configured: () => true, request: async (...args) => { calls.push(args); return { status: 200, body: { ok: true } }; } });
  await get("playlists", undefined, "8"); await get("disconnect", {}, "9");
  assert.deepEqual(calls, [[8, "playlists", null], [9, "disconnect", {}]]);
});
