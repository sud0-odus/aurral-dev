import test from "node:test";
import assert from "node:assert/strict";
import https from "node:https";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { requestAppleBrowser, loadAppleBrowserConfig } from "../../backend/services/appleBrowserClient.js";

const root = fs.mkdtempSync(path.join(os.tmpdir(), "apple-browser-client-"));
const keyPath = path.join(root, "server.key"), certPath = path.join(root, "server.crt");
execFileSync("openssl", ["req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1", "-keyout", keyPath, "-out", certPath, "-subj", "/CN=localhost", "-addext", "subjectAltName=IP:127.0.0.1"], { stdio: "ignore" });
test.after(() => fs.rmSync(root, { recursive: true, force: true }));

test("real HTTPS transport pins trust, sends only server credentials and scopes paths", async (t) => {
  const calls = [];
  const server = https.createServer({ key: fs.readFileSync(keyPath), cert: fs.readFileSync(certPath) }, (req, res) => {
    calls.push({ url: req.url, auth: req.headers.authorization });
    res.setHeader("Content-Type", "application/json"); res.end(JSON.stringify({ connected: false }));
  });
  server.listen(0, "127.0.0.1"); await new Promise((r) => server.once("listening", r));
  t.after(() => new Promise((r) => { server.closeAllConnections(); server.close(r); }));
  const config = { url: new URL(`https://127.0.0.1:${server.address().port}/`), key: "server-only-key", ca: fs.readFileSync(certPath) };
  const response = await requestAppleBrowser(9, "connect", {}, { config });
  assert.deepEqual(calls, [{ url: "/v1/users/9/connect", auth: "Bearer server-only-key" }]);
  assert.deepEqual(response, { status: 200, body: { connected: false } });
  await assert.rejects(requestAppleBrowser(9, "status", null, { config: { ...config, ca: undefined } }), /self-signed|certificate/);
});
test("configuration rejects plain HTTP and URL credentials before opening a connection", () => {
  const file = path.join(root, "config.json");
  const old = process.env.AURRAL_APPLE_BROWSER_CONFIG;process.env.AURRAL_APPLE_BROWSER_CONFIG = file;
  try {
    for (const url of ["http://192.168.1.10:3334/", "https://user:password@example.invalid/", "https://example.invalid/?token=x"]) {
      fs.writeFileSync(file, JSON.stringify({ url })); assert.throws(loadAppleBrowserConfig, /Invalid/);
    }
  } finally { if (old === undefined) delete process.env.AURRAL_APPLE_BROWSER_CONFIG; else process.env.AURRAL_APPLE_BROWSER_CONFIG = old; }
});
test("invalid users, traversal and oversized inputs cannot reach the service", async () => {
  const config = { url: new URL("https://example.invalid/"), key: "private", ca: "unused" };
  assert.throws(() => requestAppleBrowser(0, "connect", {}, { config }), /Invalid/);
  assert.throws(() => requestAppleBrowser(1, "../other", {}, { config }), /Invalid/);
  assert.equal((await requestAppleBrowser(1, "connect", { text: "x".repeat(17000) }, { config })).status, 413);
});
