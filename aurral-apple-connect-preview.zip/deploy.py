#!/usr/bin/env python3
"""Deploy the Apple sign-in preview from the Proxmox host into the Aurral CT or an optional separate browser CT."""
import argparse
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import subprocess
import tempfile
import zipfile

KIT=Path(__file__).resolve().parent
STAGE='/tmp/aurral-apple-connect-preview'

def run(*args, capture=False):
    result=subprocess.run([str(x) for x in args],text=True,capture_output=True)
    with open('/root/aurral-apple-deploy.log','a',encoding='utf-8') as log:
        os.chmod(log.name,0o600);log.write(result.stdout);log.write(result.stderr)
    if result.returncode:raise RuntimeError('Command failed: '+str(args[0])+'. Details: /root/aurral-apple-deploy.log')
    return result.stdout.strip() if capture else None

def ct(vmid,*args,capture=False):return run('pct','exec',vmid,'--',*args,capture=capture)
def config(vmid):
    result={}
    for line in run('pct','config',vmid,capture=True).splitlines():
        if ':' in line:
            key,value=line.split(':',1);result[key]=value.strip()
    return result

def validate_targets(browser, app, browser_config):
    if browser<=0 or app<=0:raise RuntimeError('CT numbers must be positive.')
    memory=int(browser_config.get('memory','0'))
    if 0<memory<1800:raise RuntimeError('Give the browser CT 2 GB RAM before installing.')
    if browser_config.get('ostype') not in (None,'debian'):raise RuntimeError('Use a separate Debian 12 or 13 CT for this installer.')

def verify_kit():
    manifest=json.loads((KIT/'release-manifest.json').read_text())
    for relative,expected in manifest['files'].items():
        p=KIT/relative
        if not p.resolve().is_relative_to(KIT.resolve()) or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:
            raise RuntimeError('Release checksum mismatch: '+relative)

def stage(vmid,archive):
    run('pct','push',vmid,archive,STAGE+'.zip','--perms','0600')
    ct(vmid,'python3','-m','zipfile','-e',STAGE+'.zip',STAGE)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--browser-ct',type=int,help='Optional separate browser CT; default is the Aurral CT')
    p.add_argument('--aurral-ct',type=int,default=109)
    group=p.add_mutually_exclusive_group(required=True);group.add_argument('--check',action='store_true');group.add_argument('--install',action='store_true');group.add_argument('--rollback',action='store_true')
    a=p.parse_args()
    if a.browser_ct is None:a.browser_ct=a.aurral_ct
    if os.geteuid()!=0 or not Path('/etc/pve').is_dir():raise RuntimeError('Run on the Proxmox host as root.')
    verify_kit()
    # Target identity is checked before staging or any package/application changes.
    if not a.rollback:validate_targets(a.browser_ct,a.aurral_ct,config(a.browser_ct))
    for vmid in set([a.browser_ct,a.aurral_ct]):
        if 'running' not in run('pct','status',vmid,capture=True):raise RuntimeError('Both CTs must be running.')
    archive=KIT/'deployment-payload.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for relative in [*json.loads((KIT/'release-manifest.json').read_text())['files'], 'release-manifest.json']:
            z.write(KIT/relative,relative)
    free=int(ct(a.browser_ct,'df','-B1','--output=avail','/opt',capture=True).splitlines()[-1].strip())
    if not a.rollback and free<2*1024**3:raise RuntimeError('At least 2 GiB free disk is required in the browser CT.')
    print('Checking Aurral source compatibility...',flush=True)
    stage(a.aurral_ct,archive)
    if a.rollback:
        ct(a.browser_ct,'systemctl','stop','aurral-apple-browser')
        ct(a.aurral_ct,'python3',STAGE+'/ct109/apply-patch.py','--rollback')
        ct(a.aurral_ct,'systemctl','start','aurral')
        print('PASS: browser service stopped; prior Aurral code/UI restored and resumed. Current music/database work preserved.')
        return
    marker=ct(a.aurral_ct,'python3','-c',"import json,pathlib;p=pathlib.Path('/opt/aurral-apple-connect-patch.json');print(json.loads(p.read_text()).get('status','') if p.exists() else '')",capture=True)
    if marker in ('installed_paused','enabled'):
        ct(a.aurral_ct,'python3',STAGE+'/ct109/apply-patch.py','--verify-installed')
    else:
        ct(a.aurral_ct,'python3',STAGE+'/ct109/apply-patch.py','--check')
    if a.check:
        print('PASS: Debian container resources and Aurral source checked. No services or application files changed. Only /tmp staging was written.')
        return
    installed=ct(a.browser_ct,'sh','-c',"if test -f /opt/aurral-apple-browser/bridge.py; then echo installed; fi",capture=True)
    if installed:
        actual=ct(a.browser_ct,'sha256sum','/opt/aurral-apple-browser/bridge.py',capture=True).split()[0]
        if actual!=hashlib.sha256((KIT/'browser/bridge.py').read_bytes()).hexdigest():raise RuntimeError('A different Apple browser service is installed; refusing to overwrite it.')
        unit=ct(a.browser_ct,'sha256sum','/etc/systemd/system/aurral-apple-browser.service',capture=True).split()[0]
        if unit!=hashlib.sha256((KIT/'browser/aurral-apple-browser.service').read_bytes()).hexdigest():raise RuntimeError('The installed browser unit differs from the expected resource-limited service.')
    else:
        print('Installing browser dependencies in CT '+str(a.browser_ct)+'; Aurral stays running during this step...',flush=True)
        ct(a.browser_ct,'apt-get','update');ct(a.browser_ct,'apt-get','install','-y','python3')
        stage(a.browser_ct,archive)
        ct(a.browser_ct,'python3',STAGE+'/browser/install-browser.py','--install',*(['--listen-lan'] if a.browser_ct!=a.aurral_ct else []))
    ct(a.browser_ct,'systemctl','start','aurral-apple-browser')
    ct(a.browser_ct,'systemctl','is-active','--quiet','aurral-apple-browser')
    addresses=ct(a.browser_ct,'hostname','-I',capture=True).split()
    ips=[str(ipaddress.ip_address(x)) for x in addresses if ipaddress.ip_address(x).version==4 and not ipaddress.ip_address(x).is_loopback]
    if not ips:raise RuntimeError('The browser CT needs a reachable IPv4 LAN address.')
    url='https://'+('127.0.0.1' if a.browser_ct==a.aurral_ct else ips[0])+':3334/'
    print('Pairing the service privately with CT '+str(a.aurral_ct)+'...',flush=True)
    if a.browser_ct == a.aurral_ct:
        ct(a.aurral_ct,'python3',STAGE+'/ct109/configure-browser.py','--url',url,'--key-file','/opt/aurral-apple-browser/bridge.key','--ca-file','/opt/aurral-apple-browser/server.crt')
    else:
        with tempfile.TemporaryDirectory(prefix='aurral-apple-pair-',dir='/root') as tmp:
            os.chmod(tmp,0o700)
            remote=[]
            try:
                for name in ['bridge.key','server.crt']:
                    local=Path(tmp)/name
                    run('pct','pull',a.browser_ct,'/opt/aurral-apple-browser/'+name,local);os.chmod(local,0o600)
                    dest=STAGE+'/'+name;remote.append(dest);run('pct','push',a.aurral_ct,local,dest,'--perms','0600')
                ct(a.aurral_ct,'python3',STAGE+'/ct109/configure-browser.py','--url',url,'--key-file',STAGE+'/bridge.key','--ca-file',STAGE+'/server.crt')
            finally:
                if remote:ct(a.aurral_ct,'rm','-f',*remote)
    if marker not in ('installed_paused','enabled'):
        print('Installing the Profile connection preview; Aurral will stop briefly for its backup...',flush=True)
        ct(a.aurral_ct,'python3',STAGE+'/ct109/apply-patch.py','--install')
    ct(a.aurral_ct,'python3',STAGE+'/ct109/apply-patch.py','--enable')
    print('PASS: refresh Aurral, open Profile, then Connect Apple Music. No Apple browser is running until you click it.')
    print('Browser service: '+url+' ; setup log: /root/aurral-apple-deploy.log')

if __name__=='__main__':
    try:main()
    except Exception as e:raise SystemExit('STOPPED: '+str(e))
