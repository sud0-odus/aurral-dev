# Verified and remaining

- Real Chromium launched in the cloud in headless test mode. Remote pointer/keyboard insertion and screenshot output worked; graceful closure removed the temporary profile.
- 15 Python bridge tests passed: ownership isolation, one-browser admission, cancellation/capture race, timeouts, expiry, failure cleanup, memory-pressure refusal and input/network bounds.
- 9 Node API/TLS tests passed: authenticated identity binding, bypass/anonymous rejection, service-only credentials, certificate verification, user-scoped read/disconnect and generic error redaction. Actual local HTTPS transport was exercised.
- 56 auth/history/acquisition regression tests passed under the two-CPU resource guard, peak summed RSS 304.4 MiB (overlaps the focused API tests).
- Browser-based UI fixture passed popup/input/success/close, cancel, disconnect, metadata/artwork listing, unconfigured behavior and zero page errors. This uses mocked Apple connection responses, not real Apple credentials.
- 21 application installer/pairing tests passed, including source/frontend rollback, current database preservation, private service configuration and rejecting unexpected pairing replacement.
- Actual six-file source/guard and prebuilt frontend payload installed, enabled and rolled back in a temporary application tree with mocked service/health operations; new completed database work was retained.
- Four Proxmox target validation tests passed, including same-CT deployment. Proxmox package/service installation cannot be executed in this cloud workspace.
- Scoped ESLint and the frontend production build passed. Build peak summed RSS 807.5 MiB under two-CPU guard.

Not yet verified: Xvfb/headed Chromium and actual Apple interactive sign-in inside CT109; host-side deployment against Proxmox itself. A verified cloud control path is not proof that Apple will accept the hosted Linux browser. The live preview is intended to establish this specific checkpoint. The pre-existing Apple POC's actual multi-user imports are already user-verified.

No recommendation seeding, playlist imports/backfills or download scheduling changes are included.
