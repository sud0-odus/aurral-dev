import argparse,importlib.util,sqlite3,tempfile,types,shutil,json
from pathlib import Path
from unittest.mock import patch
root=Path('/workspace/ct109-connector-validation');spec=importlib.util.spec_from_file_location('installer',root/'apply-patch.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as directory:
 base=Path(directory);app=base/'app';app.mkdir()
 old=Path('/workspace/ct109-connector-preview/files')
 for item in m.MANIFEST['files']:
  target=app/item['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((old/item['path']).read_bytes())
 shutil.copytree('/workspace/ct109-connector-preview/frontend-dist',app/'frontend/dist');before=m.tree_digest(app/'frontend/dist')
 db=base/'aurral.db'
 with sqlite3.connect(db) as con:con.execute('CREATE TABLE settings(key TEXT,value TEXT)');con.execute("INSERT INTO settings VALUES ('browserConnectorV1','fixture-existing-pairings')")
 args=argparse.Namespace(app_dir=app,db=db,backup_dir=base/'backups',state=base/'state',health_url='http://unused')
 active=True
 def ctl(*commands):
  global active
  if commands[0]=='stop':active=False
  if commands[0]=='start':active=True
  return types.SimpleNamespace(returncode=(0 if active else 3) if commands[0]=='is-active' else 0)
 with patch.object(m,'systemctl',side_effect=ctl),patch.object(m,'healthy',return_value=True):m.install(args);m.enable(args);m.rollback(args)
 for item in m.MANIFEST['files']:assert (app/item['path']).read_bytes()==(old/item['path']).read_bytes()
 assert m.tree_digest(app/'frontend/dist')==before
 with sqlite3.connect(db) as con:assert con.execute('SELECT value FROM settings').fetchone()[0]=='fixture-existing-pairings'
 print('PASS: actual three-file/frontend install/enable/rollback preserves existing pairings and restores the prior UI.')
