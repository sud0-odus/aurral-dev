import {chromium} from '/workspace/aurral-dev/node_modules/playwright/index.mjs';import assert from 'node:assert/strict';
import {requestFromTab,deliver} from '/workspace/aurral-dev/connector-extension/bridge.js';
const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
try{
 const context=await browser.newContext();
 await context.route('**/api/users/me/connector**',async route=>{
  const path=new URL(route.request().url()).pathname;let status=200,body;
  if(path.endsWith('/intent'))body={protocol:'aurral-connector-v1',userId:'1',nonce:'fixture',kind:'capture',service:'apple',expires:Date.now()+300000};
  else if(path.endsWith('/capture')){status=400;body={error:'Apple returned HTTP 403 while Aurral was checking web authorization.',code:'APPLE_WEB_PAGE_HTTP',stage:'validation'};}
  else body={devices:[{id:'device-fixture-123456'}],services:[],available:[{id:'apple',name:'Apple Music'}]};
  await route.fulfill({status,contentType:'application/json',body:JSON.stringify(body)});
 });
 const page=await context.newPage();await page.goto('http://127.0.0.1:4175/connector-preview.html');
 await page.getByRole('button',{name:'Connect Apple Music',exact:true}).click();await page.locator('#aurral-connector-request').waitFor({state:'attached'});
 const api={scripting:{executeScript:async({func,args=[]})=>[{result:await page.evaluate(({code,args})=>(0,eval)(`(${code})`)(...args),{code:func.toString(),args})}]}};
 const request=await requestFromTab(api,1);
 await assert.rejects(deliver(api,1,request,{kind:'capture',service:'apple',deviceId:'device-fixture-123456',credential:{session:'PRIVATE_CREDENTIAL'}}));
 const alert=page.getByRole('alert');await alert.waitFor();assert.match(await alert.innerText(),/APPLE_WEB_PAGE_HTTP/);assert.match(await alert.innerText(),/403/);
 assert.ok(!(await page.locator('body').innerText()).includes('PRIVATE_CREDENTIAL'));
 assert.ok(await page.getByRole('button',{name:'Connect Apple Music',exact:true}).isEnabled());
 console.log('PASS: provider diagnostic visible in actual React UI, no credential rendered, pairing preserved, fresh retry available.');
}finally{await browser.close();}
