# Validation

This is a source-only patch for CT109's exact patch-5 v2.11 build. No live Proxmox/CT access was available from this cloud workspace; production installation and N100 resource stability still require the supplied install/profile commands.

- 903 backend tests passed, covering downloads, Honker scheduling, playlists and track matching. Two-CPU guard, peak summed test-process RSS 585.5 MiB, elapsed 186.7 s, no guard trigger.
- 60 additional history, background supervisor, settings and source-lane tests passed (overlap with the broader run).
- After adding persisted-attempt ownership to dispatcher selection, 82 focused dispatch/tracker/release/source tests passed (overlap).
- Final packaged source has 10 focused lane tests passing, including real queue workers advancing fresh YouTube requests while six delayed Soulseek transfers retain their slots; actual source-call concurrency stayed at one. The gate is also tested at two, including slot release on errors.
- Concurrent tracks in one playlist progress independently. Same-track duplicate claims serialize. Playlist mutations wait for both active tracks; a finishing source can import while mutation waits. Reader leases are removed after failures.
- Cancellation covers all persisted source/finalization lanes. Existing download ownership, manual selection, failed handoff, review and release grouping checks passed.
- 34 Python installer, collector and launcher tests passed. Rollback preserves new completed work, payloads and scheduled times while returning new-lane work to the legacy queue. Collector tests verify source/finalizer reporting and redaction.
- Actual 37-file payload installed, enabled and rolled back in a temporary application tree with mocked service/health operations. The new module was removed on rollback, old source hashes restored, new completed database work preserved, and an abandoned YouTube claim returned to the original queue.
- Scoped ESLint (unused variables), JavaScript payload syntax/checksum checks, Python tests and git diff whitespace checks passed.

No changes to duration tolerances, review approval rules, encoding/transcoding, external download client settings or user Library scan exclusions. Default YouTube acquisition concurrency is one; increasing it to two is optional and should follow resource measurements.
