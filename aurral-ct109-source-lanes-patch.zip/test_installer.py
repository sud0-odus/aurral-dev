import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sqlite3
import tempfile
import types
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('installer',Path(__file__).with_name('apply-patch.py'))
installer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.kit = root/'kit'
        self.app = root/'app'
        self.relative = 'backend/services/test.js'
        (self.app/'backend/services').mkdir(parents=True)
        (self.kit/'files/backend/services').mkdir(parents=True)
        self.old = b'export const version = "original";\n'
        self.new = b'export const version = "patched";\n'
        (self.app/self.relative).write_bytes(self.old)
        (self.kit/'files'/self.relative).write_bytes(self.new)
        self.database = root/'aurral.db'
        with sqlite3.connect(self.database) as con:
            con.execute('CREATE TABLE work (value TEXT)')
            con.execute('INSERT INTO work VALUES (?)',('existing queue',))
        manifest = {'patch':'test-patch','files':[{'path':self.relative,'before_sha256':hashlib.sha256(self.old).hexdigest(),
                                                'after_sha256':hashlib.sha256(self.new).hexdigest()}]}
        self.patch_kit = patch.object(installer,'KIT',self.kit)
        self.patch_manifest = patch.object(installer,'MANIFEST',manifest)
        self.patch_kit.start();self.patch_manifest.start()
        self.addCleanup(self.patch_kit.stop);self.addCleanup(self.patch_manifest.stop)
        self.args = argparse.Namespace(app_dir=self.app,db=self.database,backup_dir=root/'backups',
                                       state=root/'state.json',health_url='http://127.0.0.1:1/api/health')
        self.service_active = True
        self.calls = []
        def service(*args):
            self.calls.append(args)
            if args[0]=='stop': self.service_active = False
            if args[0]=='start': self.service_active = True
            return types.SimpleNamespace(returncode=(0 if self.service_active else 3) if args[0]=='is-active' else 0)
        self.service_mock = patch.object(installer,'systemctl',side_effect=service)
        self.service_mock.start();self.addCleanup(self.service_mock.stop)

    def test_install_enable_rollback_preserves_new_database_work(self):
        installer.install(self.args)
        self.assertFalse(self.service_active)
        self.assertEqual((self.app/self.relative).read_bytes(),self.new)
        state=installer.read_state(self.args.state)
        self.assertEqual(state['status'],'installed_paused')
        backup=Path(state['backup'])
        self.assertEqual((backup.stat().st_mode&0o777),0o700)
        self.assertEqual(((backup/'aurral.db').stat().st_mode&0o777),0o600)
        with sqlite3.connect(backup/'aurral.db') as con:
            self.assertEqual(con.execute('SELECT value FROM work').fetchall(),[('existing queue',)])
        with patch.object(installer,'healthy',return_value=True): installer.enable(self.args)
        self.assertTrue(self.service_active)
        with sqlite3.connect(self.database) as con: con.execute('INSERT INTO work VALUES (?)',('new completed download',))
        installer.rollback(self.args)
        self.assertFalse(self.service_active)
        self.assertEqual((self.app/self.relative).read_bytes(),self.old)
        with sqlite3.connect(self.database) as con: self.assertEqual(con.execute('SELECT count(*) FROM work').fetchone()[0],2)

    def test_unknown_original_is_rejected_before_stopping_service(self):
        (self.app/self.relative).write_text('user modification')
        with self.assertRaisesRegex(RuntimeError,'differs'): installer.install(self.args)
        self.assertTrue(self.service_active)
        self.assertNotIn(('stop',),self.calls)

    def test_payload_tampering_is_rejected(self):
        (self.kit/'files'/self.relative).write_text('unexpected payload')
        with self.assertRaisesRegex(RuntimeError,'checksum'): installer.install(self.args)
        self.assertTrue(self.service_active)

    def test_failed_health_check_stops_service_and_keeps_backup(self):
        installer.install(self.args)
        with patch.object(installer,'healthy',return_value=False),patch.object(installer.time,'sleep'):
            with self.assertRaisesRegex(RuntimeError,'Health check failed'): installer.enable(self.args)
        self.assertFalse(self.service_active)
        self.assertEqual(installer.read_state(self.args.state)['status'],'installed_paused')
        self.assertTrue((Path(installer.read_state(self.args.state)['backup'])/'aurral.db').is_file())

    def test_rollback_does_not_overwrite_later_user_edits(self):
        installer.install(self.args)
        (self.app/self.relative).write_text('later user edit')
        with self.assertRaisesRegex(RuntimeError,'differs'): installer.rollback(self.args)
        self.assertEqual((self.app/self.relative).read_text(),'later user edit')

    def test_failed_install_restores_original_files_and_stays_paused(self):
        other = 'backend/services/other.js'
        (self.app/other).write_bytes(self.old)
        (self.kit/'files'/other).write_bytes(self.new)
        installer.MANIFEST['files'].append({**installer.MANIFEST['files'][0], 'path':other})
        original=installer.atomic_copy
        copies=0
        def fail_after_copy(source,target):
            nonlocal copies
            copies+=1
            if copies == 2:
                raise OSError('simulated file write failure')
            return original(source,target)
        with patch.object(installer,'atomic_copy',side_effect=fail_after_copy):
            with self.assertRaisesRegex(OSError,'simulated'): installer.install(self.args)
        self.assertFalse(self.service_active)
        self.assertEqual((self.app/self.relative).read_bytes(),self.old)
        self.assertEqual((self.app/other).read_bytes(),self.old)
        self.assertEqual(installer.read_state(self.args.state)['status'],'rolled_back')

    def test_interrupted_install_marker_can_restore_known_original_or_patched_files(self):
        installer.install(self.args)
        state=installer.read_state(self.args.state)
        state['status']='prepared'
        installer.write_state(self.args.state,state)
        (self.app/self.relative).write_bytes(self.old)
        installer.rollback(self.args)
        self.assertEqual((self.app/self.relative).read_bytes(),self.old)
        self.assertFalse(self.service_active)

    def add_new_source(self):
        relative = 'backend/services/new-boundary.js'
        (self.kit/'files'/relative).write_bytes(self.new)
        installer.MANIFEST['files'].append({'path':relative, 'before_sha256':None,
            'after_sha256':hashlib.sha256(self.new).hexdigest()})
        return relative

    def test_new_source_install_and_rollback_removes_only_new_code(self):
        relative = self.add_new_source()
        installer.install(self.args)
        self.assertEqual((self.app/relative).read_bytes(), self.new)
        self.assertEqual((self.app/relative).stat().st_mode & 0o777, 0o644)
        with sqlite3.connect(self.database) as con: con.execute('INSERT INTO work VALUES (?)', ('new completed track',))
        installer.rollback(self.args)
        self.assertFalse((self.app/relative).exists())
        with sqlite3.connect(self.database) as con: self.assertEqual(con.execute('SELECT count(*) FROM work').fetchone()[0], 2)

    def test_existing_file_at_new_source_location_prevents_install_before_stop(self):
        relative = self.add_new_source()
        (self.app/relative).write_text('user source')
        with self.assertRaisesRegex(RuntimeError, 'absent'): installer.install(self.args)
        self.assertTrue(self.service_active)
        self.assertNotIn(('stop',), self.calls)

    def test_new_source_written_before_failure_is_removed_without_restoring_db(self):
        relative = self.add_new_source()
        original = installer.atomic_copy
        def fail_after_new_copy(source, target):
            original(source, target)
            if target == self.app/relative: raise OSError('failure after atomic rename')
        with patch.object(installer, 'atomic_copy', side_effect=fail_after_new_copy):
            with self.assertRaisesRegex(OSError, 'after atomic'): installer.install(self.args)
        self.assertFalse((self.app/relative).exists())
        self.assertEqual((self.app/self.relative).read_bytes(), self.old)
        self.assertFalse(self.service_active)

    def test_prepared_marker_accepts_absent_new_source_on_rollback(self):
        relative = self.add_new_source()
        installer.install(self.args)
        state = installer.read_state(self.args.state);state['status'] = 'prepared';installer.write_state(self.args.state,state)
        (self.app/relative).unlink()
        installer.rollback(self.args)
        self.assertFalse((self.app/relative).exists())
        self.assertEqual((self.app/self.relative).read_bytes(), self.old)

    def test_new_module_and_prebuilt_frontend_roundtrip_keeps_current_database(self):
        relative = self.add_new_source()
        self.with_frontend()
        installer.install(self.args)
        self.assertTrue((self.app/relative).is_file())
        self.assertEqual((self.app/'frontend/dist/index.html').read_text(), 'new UI')
        with sqlite3.connect(self.database) as con: con.execute('INSERT INTO work VALUES (?)', ('finished download',))
        installer.rollback(self.args)
        self.assertFalse((self.app/relative).exists())
        self.assertEqual((self.app/'frontend/dist/index.html').read_text(), 'old UI')
        with sqlite3.connect(self.database) as con: self.assertEqual(con.execute('SELECT count(*) FROM work').fetchone()[0], 2)

    def test_later_new_module_edits_prevent_rollback_before_service_stop(self):
        relative = self.add_new_source()
        installer.install(self.args)
        (self.app/relative).write_text('later user edit')
        self.service_active = True
        with self.assertRaisesRegex(RuntimeError, 'differs'): installer.rollback(self.args)
        self.assertTrue(self.service_active)
        self.assertEqual((self.app/relative).read_text(), 'later user edit')

    def with_frontend(self):
        for directory, html in [(self.app/'frontend/dist', 'old UI'), (self.kit/'frontend-dist', 'new UI')]:
            directory.mkdir(parents=True)
            (directory/'index.html').write_text(html)
            (directory/'asset.js').write_text(html)
        installer.MANIFEST['frontend_sha256'] = installer.tree_digest(self.kit/'frontend-dist')

    def test_prebuilt_frontend_install_and_rollback_keep_current_database(self):
        self.with_frontend()
        installer.install(self.args)
        self.assertEqual((self.app/'frontend/dist/index.html').read_text(), 'new UI')
        self.assertEqual((self.app/'frontend/dist').stat().st_mode & 0o777, 0o755)
        with sqlite3.connect(self.database) as con:
            con.execute('INSERT INTO work VALUES (?)', ('completed overnight',))
        installer.rollback(self.args)
        self.assertEqual((self.app/'frontend/dist/index.html').read_text(), 'old UI')
        with sqlite3.connect(self.database) as con:
            self.assertEqual(con.execute('SELECT count(*) FROM work').fetchone()[0], 2)

    def test_later_frontend_edit_prevents_rollback_without_stopping_service(self):
        self.with_frontend()
        installer.install(self.args)
        (self.app/'frontend/dist/index.html').write_text('later user edit')
        self.service_active = True
        with self.assertRaisesRegex(RuntimeError, 'Frontend differs'):
            installer.rollback(self.args)
        self.assertTrue(self.service_active)

    def test_bad_frontend_payload_is_rejected_before_stopping_service(self):
        self.with_frontend()
        (self.kit/'frontend-dist/asset.js').write_text('corrupt')
        with self.assertRaisesRegex(RuntimeError, 'checksum'):
            installer.install(self.args)
        self.assertTrue(self.service_active)

    def test_frontend_symlinks_are_rejected_before_stopping_service(self):
        self.with_frontend()
        (self.app/'frontend/dist/link').symlink_to(self.database)
        with self.assertRaisesRegex(RuntimeError, 'symlink'):
            installer.install(self.args)
        self.assertTrue(self.service_active)


class LaneRollbackTests(unittest.TestCase):
    def test_rehomes_all_lane_work_without_erasing_payloads_or_completed_work(self):
        with tempfile.TemporaryDirectory() as root:
            database = Path(root)/"test.db"
            with sqlite3.connect(database) as con:
                con.execute("CREATE TABLE _honker_live (id INTEGER, queue TEXT, state TEXT, attempts INTEGER, worker_id TEXT, claim_expires_at INTEGER, run_at INTEGER, payload TEXT)")
                con.execute("CREATE TABLE settings (key TEXT, value TEXT)")
                con.execute("CREATE TABLE completed (id TEXT)")
                con.execute("INSERT INTO completed VALUES ('new download')")
                con.execute("INSERT INTO settings VALUES ('downloadStepReader:old','lease')")
                con.execute("INSERT INTO settings VALUES ('playlistWorker','keep')")
                con.executemany("INSERT INTO _honker_live VALUES (?,?,?,?,?,?,?,?)", [
                    (1,'ytdlp-pipeline','processing',2,'worker',999,123,'yt payload'),
                    (2,'download-finalize','pending',3,None,None,456,'file payload'),
                    (3,'slskd-pipeline','pending',4,None,None,789,'slskd payload')])
            installer.restore_legacy_pipeline(database)
            with sqlite3.connect(database) as con:
                rows=con.execute("SELECT queue,state,attempts,worker_id,claim_expires_at,run_at,payload FROM _honker_live ORDER BY id").fetchall()
                self.assertEqual(rows,[('slskd-pipeline','pending',1,None,None,123,'yt payload'),('slskd-pipeline','pending',3,None,None,456,'file payload'),('slskd-pipeline','pending',4,None,None,789,'slskd payload')])
                self.assertEqual(con.execute("SELECT * FROM completed").fetchall(),[('new download',)])
                self.assertEqual(con.execute("SELECT * FROM settings").fetchall(),[('playlistWorker','keep')])


if __name__=='__main__': unittest.main(verbosity=2)
