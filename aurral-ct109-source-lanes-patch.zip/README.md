# CT109 Aurral v2.11 source lanes (patch 6)

Requires the exact patch-5 library-boundary source. Installer checks all previous guards and refuses unexpected edits. Source-only follow-up; existing built UI and configurable Library exclusions stay in place.

## Behavior

- Existing slskd/other-source lane remains bounded to six admitted jobs and the configured search admission limit (keep 2).
- Dedicated YouTube queue receives eligible fresh individual-track requests even when those six slots are occupied. It can prefer yt-dlp for these requests; this intentionally changes first-source assignment for a bounded subset, while fallback retains the enabled source ordering. It does not race both sources on one track.
- One active YouTube acquisition step by default. `playlistWorker.ytdlpConcurrency` accepts 1 or 2 through the existing admin `PUT /api/playlists/worker/settings` API. No need to change this for the first baseline.
- Two buffered YouTube attempts at the default setting (four at setting 2), with a global admission limit of 8 (10 at setting 2). Existing/manual admissions can already exceed this; automatic dispatch waits for capacity rather than discarding work.
- One shared finalization queue validates/tags/imports all sources. It does not start another Node process. Source steps and finalization remain separate persisted stages.
- Independent jobs in the same playlist may perform source steps together. Cross-process shared step leases keep playlist ownership mutations exclusive; per-job locks prevent concurrent source steps for a single track. Existing cancellation generations, attempt IDs and import locks remain active.
- Existing rows in the old queue route to the appropriate lane when claimed. Queue/history/task visibility, cancellation and ownership transfer cover all three lanes.
- No source validation tolerances, transcoding options, provider credentials or existing reviews are changed. Known incorrect duration references are a separate issue.

## Install from the Proxmox host

Download the immutable published ZIP into CT109, extract it under `/tmp/aurral-ct109-source-lanes-patch`, then run:

```bash
pct exec 109 -- python3 /tmp/aurral-ct109-source-lanes-patch/apply-patch.py --check
pct exec 109 -- python3 /tmp/aurral-ct109-source-lanes-patch/apply-patch.py --install
pct exec 109 -- python3 /tmp/aurral-ct109-source-lanes-patch/apply-patch.py --enable
```

Run individually; stop on any error. Install stops Aurral, backs up source and SQLite locally, installs checked files and leaves Aurral stopped. Enable requires active service and health/matcher success. Existing eligible work resumes; queue rows are not reset during installation.

## Profile

```bash
pct exec 109 -- python3 /tmp/aurral-ct109-source-lanes-patch/start-profile.py --hours 8 --output /tmp/aurral-source-lanes-109-overnight
```

Detached systemd unit `aurral-source-lanes-profile` continues after PuTTY closes. Read-only collector: 30-second samples, 384 MiB memory cap, no swap, CPUQuota20% of one CPU. Revision 1.5 includes all source/finalization lanes, source/phase counts and configured YouTube concurrency. Existing duration and metadata diagnostics remain.

```bash
pct exec 109 -- journalctl -u aurral-source-lanes-profile -n 10 --no-pager
pct pull 109 /tmp/aurral-source-lanes-109-overnight.json.gz /root/aurral-source-lanes-109-overnight.json.gz
```

Windows PowerShell after the report completes:

```powershell
scp root@192.168.1.141:/root/aurral-source-lanes-109-overnight.json.gz "$HOME\Downloads\"
```

Use a different output prefix if files already exist. To finish early and save the partial observation: `pct exec 109 -- systemctl stop aurral-source-lanes-profile`.

Evaluate source-attributed successful downloads per observation hour, yt-dlp stage activity while slskd transfers wait, review/failure rate, CPU, anonymous memory, swap and OOM events. A short cloud test cannot establish overnight resource stability on the N100.

## Rollback

```bash
pct exec 109 -- python3 /tmp/aurral-ct109-source-lanes-patch/apply-patch.py --rollback
pct exec 109 -- systemctl start aurral
```

Rollback verifies backups, stops Aurral, returns new-lane rows to the original queue, resets abandoned claims for those rows, removes expired step-lease records and restores prior source. Payloads, scheduled times, pending retry counts and newly completed work stay in the current database. The database backup is not restored. Aurral remains stopped until explicitly started.
