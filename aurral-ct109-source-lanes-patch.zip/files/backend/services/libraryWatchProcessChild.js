import fs from "node:fs";
import { libraryScanExcludedRoots } from "./libraryScanBoundaries.js";
import { createBoundaryAwareWatcher } from "./libraryWatchProcess.js";
import { resolveLocalPath } from "./pathMappings.js";

let watcher;

function stop() {
  watcher?.close();
  if (process.connected) process.disconnect();
}

function send(message) {
  if (!process.connected) return;
  process.send(message, (error) => {
    if (error) stop();
  });
}

function fail(error) {
  send({ type: "error", message: error.message, code: error.code });
  stop();
}

process.on("disconnect", stop);

try {
  const root = resolveLocalPath(process.argv[2], JSON.parse(process.argv[3] || "[]"));
  // Node.js 24+ can return an idle recursive watcher for a missing Linux root.
  fs.statSync(root);
  const options = JSON.parse(process.argv[4] || "{}");
  const excludedPaths = libraryScanExcludedRoots(options.source, [root], options.excludedPaths || []);
  const onChange = (eventType, filename) => {
    send({ type: "change", root, eventType, filename: filename == null ? null : String(filename) });
  };
  watcher = excludedPaths.length > 0
    ? createBoundaryAwareWatcher(root, { excludedPaths }, onChange)
    : fs.watch(root, { recursive: true }, onChange);
  watcher.on("error", fail);
  send({ type: "ready", root });
} catch (error) {
  fail(error);
}
