// Persisted queues stay in the existing downloads process; no extra Node processes.
export const PIPELINE_QUEUES = ["slskd-pipeline", "ytdlp-pipeline", "download-finalize"];

export function pipelineQueueName(payload) {
  if (payload?.phase === "finalize") return "download-finalize";
  if (payload?.source === "ytdlp" || (!payload?.source && payload?.preferredSource === "ytdlp")) return "ytdlp-pipeline";
  return "slskd-pipeline";
}

export function ytdlpConcurrency(value) {
  return Number(value) === 2 ? 2 : 1;
}

// A small buffer feeds the source worker without materializing the backlog.
export function pipelineAdmission(entries, youtubeLimit = 1) {
  const general = new Set();
  const searches = new Set();
  const youtube = new Set();
  for (const { payload } of entries) {
    if (!payload?.jobId) continue;
    const yt = payload.source === "ytdlp" || (!payload.source && payload.preferredSource === "ytdlp");
    (yt ? youtube : general).add(payload.jobId);
    if (!yt && payload.phase === "search") searches.add(payload.jobId);
  }
  return { general: general.size, searching: searches.size, youtube: youtube.size,
    youtubeCapacity: ytdlpConcurrency(youtubeLimit) * 2 };
}

// The second claimant waits outside playlist/job locks. All slots release on error.
export function createLaneGate(limit) {
  let active = 0;
  const waiting = [];
  function pump() {
    while (waiting.length && active < limit()) {
      active++;
      waiting.shift()();
    }
  }
  return async function run(operation) {
    await new Promise((resolve) => { waiting.push(resolve); pump(); });
    try { return await operation(); }
    finally { active--; pump(); }
  };
}
