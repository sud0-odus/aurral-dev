import fs from "fs";
import { PIPELINE_QUEUES, pipelineQueueName } from "./downloadLanePolicy.js";
import path from "path";
import honker from "@russellthehippo/honker-node";
import { resolveAurralDataDir } from "../config/data-dir.js";
import { dbOps } from "../db/helpers/index.js";
import { resolveDownloadRoot } from "./downloadPaths.js";
import { ISOLATED_QUEUE_GROUPS, shouldStartQueueHere } from "./backgroundWorkerQueues.js";

export const PLAYLIST_STARTUP_MIGRATION_VERSION = 1;
export const PLAYLIST_STARTUP_MIGRATION_SETTING = "playlistStartupMigration";
export const STORED_DATA_MIGRATION_VERSION = 1;
export const STORED_DATA_MIGRATION_SETTING = "storedDataMigration";
export const IDENTITY_MARKER_MIGRATION_VERSION = 2;
export const IDENTITY_MARKER_MIGRATION_SETTING = "identityMarkerMigration";

export const HONKER_QUEUE_NAMES = [
  "system-task",
  "playback",
  "release-metadata-refresh",
  "system-task-maintenance",
  "system-task-inbox",
  "weekly-flow-operation",
  ...PIPELINE_QUEUES,
  "playlist-mbid-enrichment",
  "library-scan",
  "library-files",
  "discovery-refresh",
  "discovery-user-refresh",
  "_outbox:notifications",
  "_outbox:play-events",
];

function resolveHonkerDbPath() {
  return process.env.AURRAL_DB_PATH
    ? path.resolve(process.env.AURRAL_DB_PATH)
    : path.join(resolveAurralDataDir(), "aurral.db");
}

let honkerDb = null;
let openedHonkerDbPath = null;
let notificationOutbox = null;
let playEventOutbox = null;
let honkerSchedulerStarted = false;
let honkerSchedulerAbort = null;
let honkerSchedulerPromise = null;
let queueWakeHandler = null;
const WORKER_ID = `aurral-${process.pid}`;
const DEFAULT_HONKER_WATCHER_POLL_MS = 25;
const MISSED_FIRE_GRACE_S = 300;

export function configureHonkerQueueWake(handler) {
  queueWakeHandler = typeof handler === "function" ? handler : null;
}

function wakeQueueOwner(name) {
  try {
    if (process.env.AURRAL_BACKGROUND_WORKER_GROUP && process.connected) {
      process.send({ type: "queue-wake", queue: name });
    } else {
      queueWakeHandler?.(name);
    }
  } catch (error) {
    console.warn("[Honker] Could not wake queued work:", error?.message || error);
  }
}

export function getHonkerOpenOptions() {
  const configured = Number(process.env.AURRAL_HONKER_WATCHER_POLL_MS);
  const watcherPollIntervalMs = Number.isFinite(configured) && configured > 0
    ? Math.min(1000, Math.max(1, Math.floor(configured)))
    : DEFAULT_HONKER_WATCHER_POLL_MS;
  return { watcherPollIntervalMs };
}

export const SCHEDULED_SYSTEM_TASKS = [
  {
    name: "weekly-flow-refresh",
    queue: "system-task-maintenance",
    schedule: "@every 1h",
    payload: { kind: "weekly-flow-refresh" },
  },
  {
    name: "session-cleanup",
    queue: "system-task-maintenance",
    schedule: "@every 1h",
    payload: { kind: "session-cleanup" },
  },
  {
    name: "weekly-flow-reuse-repair",
    queue: "system-task",
    schedule: "@every 30m",
    payload: { kind: "weekly-flow-reuse-repair" },
  },
  {
    name: "review-timeout",
    queue: "system-task",
    schedule: "@every 15m",
    payload: { kind: "review-timeout" },
  },
  {
    name: "quality-upgrade-check",
    queue: "system-task",
    schedule: "@every 1h",
    payload: { kind: "quality-upgrade-check" },
    priority: -10,
  },
  {
    name: "discovery-refresh-check",
    queue: "system-task",
    schedule: "@every 15m",
    payload: { kind: "discovery-refresh-check" },
  },
  {
    name: "inbox-refresh",
    queue: "system-task-inbox",
    schedule: "@every 24h",
    payload: { kind: "inbox-refresh" },
  },
  {
    name: "news-refresh",
    queue: "system-task-maintenance",
    schedule: "@every 15m",
    payload: { kind: "news-refresh" },
  },
  {
    name: "import-list-sync",
    queue: "system-task",
    schedule: "@every 30m",
    payload: { kind: "import-list-sync" },
  },
  {
    name: "release-metadata-refresh",
    queue: "release-metadata-refresh",
    schedule: "@every 24h",
    payload: { kind: "release-metadata-refresh" },
    priority: -5,
  },
  {
    name: "aurral-monitoring-reconcile",
    queue: "system-task",
    schedule: "@every 24h",
    payload: { kind: "aurral-monitoring-reconcile" },
  },
  {
    name: "aurral-missing-track-search",
    queue: "system-task",
    schedule: "@every 24h",
    payload: { kind: "aurral-missing-track-search" },
  },
  {
    name: "playlist-mbid-enrichment-sweep",
    queue: "playlist-mbid-enrichment",
    schedule: "@every 6h",
    payload: { kind: "playlist-mbid-enrichment-sweep", reason: "schedule" },
    maxAttempts: 4,
  },
];

const PIPELINE_PHASE_PRIORITY = {
  search: 0,
  poll: 10,
  download: 20,
  finalize: 30,
};

function getPipelinePriorityForPhase(phase) {
  return PIPELINE_PHASE_PRIORITY[String(phase || "").toLowerCase()] ?? 0;
}

export function getHonkerDb() {
  const dbPath = resolveHonkerDbPath();
  if (honkerDb && openedHonkerDbPath !== dbPath) {
    closeHonkerDb();
  }
  if (!honkerDb) {
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    honkerDb = honker.open(dbPath, getHonkerOpenOptions());
    openedHonkerDbPath = dbPath;
  }
  return honkerDb;
}

function resolveEnqueueRunAt(options) {
  if (options.runAt != null) return Math.floor(Number(options.runAt) / 1000);
  if (options.delaySeconds != null) return Math.floor(Date.now() / 1000) + Number(options.delaySeconds);
  return null;
}

export function parseHonkerPayload(value) {
  try {
    const payload = typeof value === "string" ? JSON.parse(value) : value;
    return payload && typeof payload === "object" && !Array.isArray(payload)
      ? payload
      : null;
  } catch {
    return null;
  }
}

export function listHonkerJobs(queueName) {
  const safeQueue = String(queueName || "").trim();
  if (!safeQueue) return [];
  return getHonkerDb()
    .query(
      `SELECT id, queue, payload, state, run_at, claim_expires_at, attempts
       FROM _honker_live
       WHERE queue IN (${(safeQueue === "slskd-pipeline" ? PIPELINE_QUEUES : [safeQueue]).map(() => "?").join(",")})
       ORDER BY id ASC`,
      safeQueue === "slskd-pipeline" ? PIPELINE_QUEUES : [safeQueue],
    )
    .map((row) => ({ ...row, payload: parseHonkerPayload(row.payload) }));
}

function createHonkerQueue({
  name,
  visibilityTimeoutS,
  maxAttempts,
  workerModule,
  workerStartFn,
  defaultPriorityFn = (payload, options) => Number(options.priority || 0),
  skipInTest = false,
  coalescePlaylistEnrichment = false,
}) {
  let queue = null;

  function getQueue() {
    if (!queue) {
      queue = getHonkerDb().queue(name, { visibilityTimeoutS, maxAttempts });
    }
    return queue;
  }

  function enqueueJob(payload, options = {}) {
    const q = getQueue();
    const runAt = resolveEnqueueRunAt(options);
    const priority = defaultPriorityFn(payload, options);
    let jobId;
    if (coalescePlaylistEnrichment && payload?.kind === "playlist-mbid-enrichment" && payload.playlistId) {
      const tx = getHonkerDb().transaction();
      try {
        const [pending] = tx.query(`SELECT id, payload FROM _honker_live
          WHERE queue = ? AND state = 'pending'
            AND json_extract(payload, '$.kind') = 'playlist-mbid-enrichment'
            AND json_extract(payload, '$.playlistId') = ? ORDER BY id LIMIT 1`,
        [name, String(payload.playlistId)]);
        if (pending) {
          const previous = parseHonkerPayload(pending.payload) || {};
          const merged = { ...previous,
            reconcileArtistMbids: previous.reconcileArtistMbids === true || payload.reconcileArtistMbids === true };
          tx.execute(`UPDATE _honker_live SET payload = ?, priority = MAX(priority, ?), run_at = MIN(run_at, ?)
            WHERE id = ? AND state = 'pending'`,
          [JSON.stringify(merged), priority, runAt ?? Math.floor(Date.now() / 1000), pending.id]);
          jobId = pending.id;
        } else {
          jobId = q.enqueueTx(tx, payload, { priority, runAt });
        }
        tx.commit();
      } catch (error) {
        try { tx.rollback(); } catch {}
        throw error;
      }
    } else {
      jobId = q.enqueue(payload, { priority, runAt });
    }
    if (shouldStartQueueHere(name) && !(skipInTest && process.env.NODE_ENV === "test")) {
      import(workerModule)
        .then((mod) => mod[workerStartFn]())
        .catch((err) => { console.warn(err); });
    } else {
      wakeQueueOwner(name);
    }
    return jobId;
  }

  function reset() {
    queue = null;
  }

  return { getQueue, enqueueJob, reset };
}

const queueByName = new Map();
const allQueues = [];

function registerQueue(config) {
  const { getQueue, enqueueJob, reset } = createHonkerQueue(config);
  queueByName.set(config.name, { getQueue, enqueueJob });
  allQueues.push(reset);
  return { getQueue, enqueueJob };
}

const pipeline = registerQueue({
  name: "slskd-pipeline",
  visibilityTimeoutS: 1200,
  maxAttempts: 5,
  workerModule: "./downloadPipelineWorker.js",
  workerStartFn: "startDownloadPipelineWorker",
  defaultPriorityFn: (payload) =>
    getPipelinePriorityForPhase(payload?.phase) - (payload?.upgrade ? 100 : 0),
});
export const getPipelineQueue = pipeline.getQueue;
const pipelineLanes = new Map([["slskd-pipeline", pipeline]]);
for (const name of PIPELINE_QUEUES.slice(1)) {
  pipelineLanes.set(name, registerQueue({
    name, visibilityTimeoutS: 1200, maxAttempts: 5,
    workerModule: "./downloadPipelineWorker.js", workerStartFn: "startDownloadPipelineWorker",
    defaultPriorityFn: (payload) => getPipelinePriorityForPhase(payload?.phase) - (payload?.upgrade ? 100 : 0),
  }));
}
export function enqueuePipelineJob(payload, options) {
  return pipelineLanes.get(pipelineQueueName(payload)).enqueueJob(payload, options);
}

const discoveryRefresh = registerQueue({
  name: "discovery-refresh",
  visibilityTimeoutS: 3600,
  maxAttempts: 4,
  workerModule: "./discoveryRefreshWorker.js",
  workerStartFn: "startDiscoveryRefreshWorker",
  skipInTest: true,
});
export const getDiscoveryRefreshQueue = discoveryRefresh.getQueue;
export const enqueueDiscoveryRefreshJob = discoveryRefresh.enqueueJob;

const discoveryUserRefresh = registerQueue({
  name: "discovery-user-refresh",
  visibilityTimeoutS: 3600,
  maxAttempts: 4,
  workerModule: "./discoveryUserRefreshWorker.js",
  workerStartFn: "startDiscoveryUserRefreshWorker",
  skipInTest: true,
});
export const getDiscoveryUserRefreshQueue = discoveryUserRefresh.getQueue;
export const enqueueDiscoveryUserRefreshJob = discoveryUserRefresh.enqueueJob;

const playlistOperation = registerQueue({
  name: "weekly-flow-operation",
  visibilityTimeoutS: 3600,
  maxAttempts: 3,
  workerModule: "./playlists/playlistOperationWorker.js",
  workerStartFn: "startPlaylistOperationWorker",
});

export const getPlaylistOperationQueue = playlistOperation.getQueue;
export const enqueuePlaylistOperationJob = playlistOperation.enqueueJob;

const playlistMbidEnrichment = registerQueue({
  name: "playlist-mbid-enrichment",
  visibilityTimeoutS: 3600,
  maxAttempts: 4,
  workerModule: "./playlistMbidEnrichmentWorker.js",
  workerStartFn: "startPlaylistMbidEnrichmentWorker",
  skipInTest: true,
  coalescePlaylistEnrichment: true,
});

export const getPlaylistMbidEnrichmentQueue = playlistMbidEnrichment.getQueue;
export const enqueuePlaylistMbidEnrichmentJob = playlistMbidEnrichment.enqueueJob;

const systemTask = registerQueue({
  name: "system-task",
  visibilityTimeoutS: 3600,
  maxAttempts: 3,
  workerModule: "./systemTaskWorker.js",
  workerStartFn: "startSystemTaskWorker",
});

export const getSystemTaskQueue = systemTask.getQueue;

const releaseMetadata = registerQueue({
  name: "release-metadata-refresh",
  visibilityTimeoutS: 3600,
  maxAttempts: 3,
  workerModule: "./releaseMetadataWorker.js",
  workerStartFn: "startReleaseMetadataWorker",
  skipInTest: true,
});
export const getReleaseMetadataQueue = releaseMetadata.getQueue;

const maintenanceTask = registerQueue({
  name: "system-task-maintenance",
  visibilityTimeoutS: 3600,
  maxAttempts: 3,
  workerModule: "./systemTaskWorker.js",
  workerStartFn: "startMaintenanceTaskWorker",
});
export const getMaintenanceTaskQueue = maintenanceTask.getQueue;

const inboxTask = registerQueue({
  name: "system-task-inbox",
  visibilityTimeoutS: 3600,
  maxAttempts: 3,
  workerModule: "./systemTaskWorker.js",
  workerStartFn: "startInboxTaskWorker",
});
export const getInboxTaskQueue = inboxTask.getQueue;

const playbackTask = registerQueue({
  name: "playback",
  visibilityTimeoutS: 3600,
  maxAttempts: 3,
  workerModule: "./systemTaskWorker.js",
  workerStartFn: "startPlaybackTaskWorker",
});
export const getPlaybackTaskQueue = playbackTask.getQueue;

const PLAYBACK_TASK_KINDS = ["playback-library-scan", "playback-playlist-sync"];

export function getSystemTaskQueueName(kind) {
  if (kind === "release-metadata-refresh") return "release-metadata-refresh";
  if (PLAYBACK_TASK_KINDS.includes(kind)) return "playback";
  if (kind === "inbox-refresh") return "system-task-inbox";
  if (kind === "session-cleanup" || kind === "news-refresh" ||
      kind === "weekly-flow-refresh") return "system-task-maintenance";
  return "system-task";
}

export function enqueueSystemTaskJob(payload, options) {
  switch (getSystemTaskQueueName(payload?.kind)) {
    case "release-metadata-refresh": return releaseMetadata.enqueueJob(payload, options);
    case "system-task-inbox": return inboxTask.enqueueJob(payload, options);
    case "system-task-maintenance": return maintenanceTask.enqueueJob(payload, options);
    case "playback": return playbackTask.enqueueJob(payload, options);
    default: return systemTask.enqueueJob(payload, options);
  }
}

const libraryScan = registerQueue({
  name: "library-scan",
  visibilityTimeoutS: 600,
  maxAttempts: 3,
  skipInTest: true,
  workerModule: "./libraryScanWorker.js",
  workerStartFn: "startLibraryScanWorker",
});

export const getLibraryScanQueue = libraryScan.getQueue;
export const enqueueLibraryScanJob = libraryScan.enqueueJob;

const libraryFiles = registerQueue({
  name: "library-files",
  visibilityTimeoutS: 600,
  maxAttempts: 5,
  skipInTest: true,
  workerModule: "./libraryFiles/libraryFileWorker.js",
  workerStartFn: "startLibraryFileWorker",
});

export const getLibraryFileQueue = libraryFiles.getQueue;
export const enqueueLibraryFileJob = libraryFiles.enqueueJob;

export function getNotificationOutbox() {
  if (!notificationOutbox) {
    notificationOutbox = getHonkerDb().outbox(
      "notifications",
      async (payload, job) => {
        const { deliverQueuedNotification } = await import("./notificationService.js");
        const { withJobHeartbeat } = await import("./honkerWorkerRuntime.js");
        const outbox = getNotificationOutbox();
        await withJobHeartbeat(job, outbox.queue, () => deliverQueuedNotification(payload));
      },
      {
        visibilityTimeoutS: 120,
        maxAttempts: 5,
        baseBackoffS: 30,
      },
    );
  }
  return notificationOutbox;
}

export function enqueueNotification(payload) {
  const jobId = getNotificationOutbox().enqueue(payload);
  if (shouldStartQueueHere("_outbox:notifications")) {
    import("./notificationOutboxWorker.js")
      .then(({ startNotificationOutboxWorker }) => startNotificationOutboxWorker())
      .catch((err) => { console.warn(err); });
  } else {
    wakeQueueOwner("_outbox:notifications");
  }
  return jobId;
}

export function getPlayEventOutbox() {
  if (!playEventOutbox) {
    playEventOutbox = getHonkerDb().outbox(
      "play-events",
      async (payload, job) => {
        const { deliverPlayEvent } = await import("./playEventService.js");
        const { withJobHeartbeat } = await import("./honkerWorkerRuntime.js");
        const outbox = getPlayEventOutbox();
        await withJobHeartbeat(job, outbox.queue, () => deliverPlayEvent(payload));
      },
      { visibilityTimeoutS: 120, maxAttempts: 5, baseBackoffS: 30 },
    );
  }
  return playEventOutbox;
}

export function enqueuePlayEventDelivery(payload) {
  const jobId = getPlayEventOutbox().enqueue(payload);
  if (shouldStartQueueHere("_outbox:play-events")) {
    import("./playEventOutboxWorker.js")
      .then(({ startPlayEventOutboxWorker }) => startPlayEventOutboxWorker())
      .catch((err) => { console.warn(err); });
  } else {
    wakeQueueOwner("_outbox:play-events");
  }
  return jobId;
}

function migrateMovedSystemTaskJobs() {
  const tx = getHonkerDb().transaction();
  try {
    tx.execute(`UPDATE _honker_live
      SET queue = ?, state = 'pending', worker_id = NULL, claim_expires_at = NULL
      WHERE queue = ? AND json_extract(payload, '$.kind') = ?
        AND (state = 'pending' OR (state = 'processing' AND claim_expires_at <= unixepoch()))`,
    ["release-metadata-refresh", "system-task", "release-metadata-refresh"]);
    tx.execute(`UPDATE _honker_live
      SET queue = ?, state = 'pending', worker_id = NULL, claim_expires_at = NULL
      WHERE queue = ? AND json_extract(payload, '$.kind') IN (?, ?) AND state IN ('pending', 'processing')`,
    ["playback", "system-task", ...PLAYBACK_TASK_KINDS]);
    tx.commit();
  } catch (error) {
    tx.rollback();
    throw error;
  }
}

export function bootstrapHonkerSchedules() {
  migrateMovedSystemTaskJobs();
  const scheduler = getHonkerDb().scheduler();
  const canonicalByName = new Map(SCHEDULED_SYSTEM_TASKS.map((task) => [task.name, task]));
  const existingByName = new Map(scheduler.list().map((row) => [row.name, row]));

  for (const row of existingByName.values()) {
    if (!canonicalByName.has(row.name)) {
      scheduler.remove(row.name);
    }
  }

  for (const task of SCHEDULED_SYSTEM_TASKS) {
    const existing = existingByName.get(task.name);
    if (!existing) {
      scheduler.add(task);
      continue;
    }

    const priority = Number(task.priority ?? 0);
    const expiresS = task.expiresS ?? null;
    const maxAttempts = Number(task.maxAttempts ?? 3);
    const payloadText = JSON.stringify(task.payload ?? null);

    if (existing.queue !== task.queue) {
      if (task.name === "release-metadata-refresh") {
        const tx = getHonkerDb().transaction();
        try {
          tx.execute("UPDATE _honker_scheduler_tasks SET queue = ? WHERE name = ?", [task.queue, task.name]);
          tx.commit();
        } catch (error) {
          tx.rollback();
          throw error;
        }
      } else {
        scheduler.remove(task.name);
        scheduler.add(task);
        continue;
      }
    }

    const updates = {};
    if (
      existing.cron_expr !== task.schedule ||
      (task.name !== "release-metadata-refresh" && Number(existing.next_fire_at || 0) <=
        Math.floor(Date.now() / 1000) - MISSED_FIRE_GRACE_S)
    ) {
      updates.schedule = task.schedule;
    }
    if (existing.payload !== payloadText) updates.payload = task.payload;
    if (Number(existing.priority) !== priority) updates.priority = priority;
    if ((existing.expires_s ?? null) !== expiresS) updates.expiresS = expiresS;
    if (Number(existing.max_attempts ?? 3) !== maxAttempts) {
      updates.maxAttempts = maxAttempts;
    }
    if (Object.keys(updates).length > 0) {
      scheduler.update(task.name, updates);
    }
    if (existing.enabled === false) {
      scheduler.resume(task.name);
    }
  }
}

export function enqueueHonkerStartupTasks() {
  const enqueueIfAbsent = (payload, options) => {
    const legacy = payload.kind === "release-metadata-refresh"
      ? findActiveHonkerJob("system-task", (candidate) => candidate?.kind === payload.kind, { recoverExpired: true })
      : null;
    const existing = legacy || findActiveHonkerJob(
      getSystemTaskQueueName(payload.kind),
      (candidate) => candidate?.kind === payload.kind,
      { recoverExpired: true },
    );
    return existing?.id || enqueueSystemTaskJob(payload, options);
  };
  const migration = dbOps.getJSONSetting(PLAYLIST_STARTUP_MIGRATION_SETTING);
  if (
    migration?.version !== PLAYLIST_STARTUP_MIGRATION_VERSION ||
    path.resolve(String(migration?.rootPath || "")) !== resolveDownloadRoot()
  ) {
    enqueueIfAbsent(
      { kind: "playlist-startup-migration" },
      { delaySeconds: 3, priority: 10 },
    );
  }
  const storedData = dbOps.getJSONSetting(STORED_DATA_MIGRATION_SETTING);
  if (storedData?.version !== STORED_DATA_MIGRATION_VERSION) {
    enqueueIfAbsent({ kind: "stored-data-migration" }, { delaySeconds: 3, priority: 10 });
  }
  const identityMarkers = dbOps.getJSONSetting(IDENTITY_MARKER_MIGRATION_SETTING);
  if (identityMarkers?.version !== IDENTITY_MARKER_MIGRATION_VERSION) {
    enqueueIfAbsent({ kind: "identity-marker-migration" }, { delaySeconds: 30, priority: -5 });
  }
  enqueueIfAbsent({ kind: "weekly-flow-startup-check" }, { delaySeconds: 5, priority: 5 });
  enqueueIfAbsent({ kind: "playlist-startup-publish" }, { delaySeconds: 10, priority: 0 });
  import("./libraryFiles/operations.js")
    .then(({ resumeLibraryFileOperations }) => resumeLibraryFileOperations())
    .catch((error) => console.warn("[LibraryFiles] Could not resume file operations:", error?.message || error));
  enqueueIfAbsent({ kind: "upgrade-readiness-check" }, { delaySeconds: 60, priority: -10 });
  enqueueIfAbsent({ kind: "discovery-bootstrap" }, { delaySeconds: 15, priority: 5 });
  enqueueIfAbsent({ kind: "library-index-bootstrap" }, { delaySeconds: 8, priority: 0 });
  enqueueIfAbsent({ kind: "release-metadata-refresh" }, { delaySeconds: 12, priority: -5 });
  enqueueIfAbsent({ kind: "news-refresh" }, { delaySeconds: 20, priority: -5 });
}

export function findActiveHonkerJob(
  queueName,
  predicate = () => true,
  { recoverExpired = false, payloadKind = "" } = {},
) {
  const safeQueue = String(queueName || "").trim();
  if (!safeQueue) return null;
  const safePayloadKind = String(payloadKind || "").trim();
  const queue = getHonkerQueueByName(safeQueue);
  if (recoverExpired) {
    try {
      queue?.sweepExpired();
    } catch {}
  }
  const now = Math.floor(Date.now() / 1000);
  const payloadKindFilter = safePayloadKind
    ? "AND json_extract(payload, '$.kind') = ?"
    : "";
  const parameters = safePayloadKind
    ? [safeQueue, safePayloadKind, now]
    : [safeQueue, now];
  const rows = getHonkerDb().query(
    `
      SELECT id, payload, state, run_at, claim_expires_at, attempts
      FROM _honker_live
      WHERE queue = ?
        ${payloadKindFilter}
        AND (
          state = 'pending'
          OR (state = 'processing' AND (claim_expires_at IS NULL OR claim_expires_at > ?))
        )
      ORDER BY id ASC
      LIMIT 100
    `,
    parameters,
  );
  for (const row of rows) {
    const payload = parseHonkerPayload(row.payload);
    if (predicate(payload, row)) return { ...row, payload };
  }
  return null;
}

export function startHonkerScheduler() {
  if (honkerSchedulerStarted || process.env.NODE_ENV === "test") return;
  honkerSchedulerStarted = true;
  const abort = new AbortController();
  honkerSchedulerAbort = abort;
  const runPromise = getHonkerDb()
    .scheduler()
    .run(WORKER_ID, abort.signal);
  honkerSchedulerPromise = runPromise;
  void runPromise
    .catch(async (error) => {
      console.error("[honkerScheduler] loop error:", error);
      honkerSchedulerStarted = false;
      honkerSchedulerAbort = null;
      const { scheduleHonkerComponentRestart } = await import("./honkerWorkerRuntime.js");
      scheduleHonkerComponentRestart("scheduler", startHonkerScheduler);
    })
    .finally(() => {
      if (honkerSchedulerPromise === runPromise) {
        honkerSchedulerPromise = null;
      }
    });
}

export function stopHonkerScheduler() {
  const running = honkerSchedulerPromise;
  honkerSchedulerAbort?.abort();
  honkerSchedulerAbort = null;
  honkerSchedulerStarted = false;
  return running || Promise.resolve();
}

export function closeHonkerDb() {
  stopHonkerScheduler();
  if (honkerDb) {
    try {
      honkerDb.close();
    } catch {}
  }
  honkerDb = null;
  openedHonkerDbPath = null;
  for (const reset of allQueues) {
    reset();
  }
  notificationOutbox = null;
  playEventOutbox = null;
}

export function isHonkerLockHeld(name) {
  const probeOwner = `probe-${WORKER_ID}-${Date.now()}`;
  const lock = getHonkerDb().tryLock(String(name || "").trim(), probeOwner, 1);
  if (lock) {
    try {
      lock.release();
    } catch {}
    return false;
  }
  return true;
}

const inProcessLockTails = new Map();

export async function withHonkerLock(
  name,
  fn,
  { ttlSeconds = 120, waitTimeoutMs = 300000, retryDelayMs = 250 } = {},
) {
  const safeName = String(name || "").trim();
  if (!safeName) {
    throw new Error("Honker lock name is required");
  }
  const deadline = Date.now() + Math.max(0, Number(waitTimeoutMs) || 0);

  const previousTail = inProcessLockTails.get(safeName) || Promise.resolve();
  let releaseGate;
  const gate = new Promise((resolve) => {
    releaseGate = resolve;
  });
  const tail = previousTail.then(() => gate);
  inProcessLockTails.set(safeName, tail);

  try {
    const gateAcquired = await Promise.race([
      previousTail.then(() => true),
      new Promise((resolve) => {
        const waitMs = Math.max(0, deadline - Date.now());
        const timer = setTimeout(() => resolve(false), waitMs);
        if (typeof timer.unref === "function") timer.unref();
      }),
    ]);
    if (!gateAcquired) {
      throw new Error(`Timed out waiting for Honker lock: ${safeName}`);
    }

    let lock = null;
    while (!lock) {
      lock = getHonkerDb().tryLock(safeName, WORKER_ID, ttlSeconds);
      if (lock) break;
      if (Date.now() >= deadline) {
        throw new Error(`Timed out waiting for Honker lock: ${safeName}`);
      }
      await new Promise((resolve) =>
        setTimeout(resolve, Math.max(50, Number(retryDelayMs) || 250)),
      );
    }

    const heartbeatMs = Math.max(1000, Math.floor((Number(ttlSeconds) || 120) * 1000 * 0.33));
    const heartbeat = setInterval(() => {
      try {
        lock.heartbeat(ttlSeconds);
      } catch {}
    }, heartbeatMs);

    try {
      return await fn();
    } finally {
      clearInterval(heartbeat);
      try {
        lock.release();
      } catch {}
    }
  } finally {
    releaseGate();
    if (inProcessLockTails.get(safeName) === tail) {
      inProcessLockTails.delete(safeName);
    }
  }
}

export function getWorkerId() {
  return WORKER_ID;
}

export function getHonkerQueueDepth(queueName) {
  const safeQueue = String(queueName || "").trim();
  if (!safeQueue) return 0;
  const now = Math.floor(Date.now() / 1000);
  const row = getHonkerDb().query(
    `SELECT COUNT(*) AS count
     FROM _honker_live
     WHERE queue = ?
       AND state = 'pending'
       AND run_at <= ?`,
    [safeQueue, now],
  )[0];
  return Number(row?.count) || 0;
}

export function hasClaimableHonkerJobs(queueName) {
  return Boolean(getHonkerDb().query(
    `SELECT 1 FROM _honker_live WHERE queue = ? AND run_at <= ?
     AND (state = 'pending' OR (state = 'processing' AND claim_expires_at <= ?)) LIMIT 1`,
    [queueName, Math.floor(Date.now() / 1000), Math.floor(Date.now() / 1000)],
  )[0]);
}

export function hasActiveHonkerJobs(queueName) {
  return Boolean(getHonkerDb().query(
    `SELECT 1 FROM _honker_live WHERE queue = ?
     AND (state = 'processing' OR (state = 'pending' AND run_at <= ?)) LIMIT 1`,
    [queueName, Math.floor(Date.now() / 1000)],
  )[0]);
}

export function isHonkerScheduleDue(nowMs = Date.now()) {
  return Boolean(getHonkerDb().query(
    "SELECT 1 FROM _honker_scheduler_tasks WHERE enabled = 1 AND next_fire_at <= ? LIMIT 1",
    [Math.floor(nowMs / 1000)],
  )[0]);
}

export function listBackgroundGroupsWithWork(nowMs = Date.now()) {
  const now = Math.floor(nowMs / 1000);
  const groups = new Set(getHonkerDb().query(
    `SELECT DISTINCT queue FROM _honker_live WHERE run_at <= ?
     AND (state = 'pending' OR (state = 'processing' AND claim_expires_at <= ?))`,
    [now, now],
  ).map((row) => ISOLATED_QUEUE_GROUPS[row.queue]).filter(Boolean));
  if (isHonkerScheduleDue(nowMs)) groups.add("scheduler");
  return [...groups];
}

export function getNextBackgroundWorkAt(nowMs = Date.now()) {
  const now = Math.floor(nowMs / 1000);
  const row = getHonkerDb().query(
    `SELECT MIN(due_at) AS next_at FROM (
       SELECT run_at AS due_at FROM _honker_live WHERE state = 'pending' AND run_at > ?
       UNION ALL
       SELECT MAX(run_at, claim_expires_at) AS due_at FROM _honker_live
         WHERE state = 'processing' AND MAX(run_at, claim_expires_at) > ?
       UNION ALL
       SELECT next_fire_at AS due_at FROM _honker_scheduler_tasks WHERE enabled = 1 AND next_fire_at > ?
     )`,
    [now, now, now],
  )[0];
  return row?.next_at == null ? null : Number(row.next_at) * 1000;
}

export function hasExpiredHonkerClaims(queueName) {
  return Boolean(getHonkerDb().query(
    "SELECT 1 FROM _honker_live WHERE queue = ? AND state = 'processing' AND claim_expires_at <= ? LIMIT 1",
    [queueName, Math.floor(Date.now() / 1000)],
  )[0]);
}

export function sweepAllHonkerQueues() {
  let swept = 0;
  for (const queueName of HONKER_QUEUE_NAMES) {
    const queue = getHonkerQueueByName(queueName);
    if (!queue) continue;
    try {
      swept += Number(queue.sweepExpired()) || 0;
    } catch {}
  }
  return swept;
}

export function getHonkerQueueByName(queueName) {
  if (queueName === "_outbox:notifications") {
    return getNotificationOutbox().queue;
  }
  if (queueName === "_outbox:play-events") {
    return getPlayEventOutbox().queue;
  }
  return queueByName.get(queueName)?.getQueue() ?? null;
}

export function getHonkerQueueNextClaimAt(queueName) {
  const safeQueue = String(queueName || "").trim();
  if (!safeQueue) return null;
  const queue = getHonkerQueueByName(safeQueue);
  const value = queue && typeof queue._nextClaimAt === "function" ? queue._nextClaimAt() : null;
  const timestamp = Number(value);
  return Number.isFinite(timestamp) && timestamp > 0 ? timestamp : null;
}

export function requeueInterruptedHonkerJob(job, queue, { refundAttempt = true } = {}) {
  const tx = getHonkerDb().transaction();
  try {
    tx.execute(`UPDATE _honker_live
      SET state = 'pending', worker_id = NULL, claim_expires_at = NULL,
          run_at = unixepoch() + 1, attempts = MAX(0, attempts - ?)
      WHERE id = ? AND queue = ? AND worker_id = ? AND state = 'processing'`,
    [refundAttempt ? 1 : 0, job.id, queue.name, getWorkerId()]);
    tx.commit();
  } catch (error) {
    tx.rollback();
    throw error;
  }
}

export function mergeIntoPendingHonkerJob(queueName, { payloadKind, matches = () => true, merge }) {
  const tx = getHonkerDb().transaction();
  try {
    const rows = tx.query(
      `SELECT id, payload FROM _honker_live
       WHERE queue = ? AND json_extract(payload, '$.kind') = ? AND state = 'pending' AND attempts = 0
       ORDER BY id ASC`,
      [queueName, payloadKind],
    );
    const target = rows
      .map((row) => ({ id: row.id, payload: parseHonkerPayload(row.payload) }))
      .find(({ payload }) => payload && matches(payload));
    if (target) {
      tx.execute("UPDATE _honker_live SET payload = ? WHERE id = ?", [
        JSON.stringify(merge(target.payload)),
        target.id,
      ]);
    }
    tx.commit();
    return target?.id ?? null;
  } catch (error) {
    tx.rollback();
    throw error;
  }
}

export function adjustHonkerClaimAttempts(job, queue, delta) {
  const tx = getHonkerDb().transaction();
  try {
    const changed = tx.execute(`UPDATE _honker_live SET attempts = MAX(0, attempts + ?)
      WHERE id = ? AND queue = ? AND worker_id = ? AND state = 'processing'`,
    [delta, job.id, queue.name, getWorkerId()]);
    tx.commit();
    return changed > 0;
  } catch (error) {
    tx.rollback();
    throw error;
  }
}

export function restoreReleaseMetadataQueueForRollback() {
  const tx = getHonkerDb().transaction();
  try {
    tx.execute(`UPDATE _honker_live SET state = 'pending', worker_id = NULL, claim_expires_at = NULL
      WHERE queue = ? AND state = 'processing' AND claim_expires_at <= unixepoch()`,
    ["release-metadata-refresh"]);
    const processing = tx.query("SELECT id FROM _honker_live WHERE queue = ? AND state = 'processing' LIMIT 1",
      ["release-metadata-refresh"]);
    if (processing.length) throw new Error("Stop and drain the metadata worker before rollback");
    const moved = tx.execute("UPDATE _honker_live SET queue = ? WHERE queue = ? AND state = 'pending'",
      ["system-task", "release-metadata-refresh"]);
    tx.execute("UPDATE _honker_scheduler_tasks SET queue = ? WHERE name = ?",
      ["system-task", "release-metadata-refresh"]);
    tx.commit();
    return moved;
  } catch (error) {
    tx.rollback();
    throw error;
  }
}
