import { fork } from "node:child_process";
import { EventEmitter } from "node:events";
import fs from "node:fs";
import path from "node:path";
import { isLibraryBoundaryExcluded, isWithinLibraryPath, normalizeLibraryScanExclusions } from "./libraryScanBoundaries.js";

// Recursive fs.watch setup can synchronously traverse a whole library. Keep all
// filesystem access in a child so even a stalled mount cannot block the API.
export function createIsolatedLibraryWatcher(root, { pathMappings = [], source = "aurral", excludedPaths = null } = {}, onChange, { forkImpl = fork } = {}) {
  const watcher = new EventEmitter();
  const child = forkImpl(new URL("./libraryWatchProcessChild.js", import.meta.url), [root, JSON.stringify(pathMappings), JSON.stringify({ source, excludedPaths })], {
    execArgv: [],
    stdio: ["ignore", "ignore", "ignore", "ipc"],
    windowsHide: true,
  });
  let closed = false;

  watcher.close = () => {
    if (closed) return;
    closed = true;
    // SIGTERM cannot interrupt a JS-blocked watcher setup on every platform.
    if (child.exitCode == null && child.signalCode == null) child.kill("SIGKILL");
    watcher.emit("close");
  };

  function fail(error) {
    if (closed) return;
    watcher.close();
    watcher.emit("error", error);
  }

  child.on("message", (message) => {
    if (closed) return;
    if (message?.type === "ready") {
      watcher.emit("ready", message.root);
    } else if (message?.type === "change") {
      onChange(message.eventType, message.filename, message.root);
    } else if (message?.type === "error") {
      fail(Object.assign(new Error(message.message), { code: message.code }));
    }
  });
  child.on("error", fail);
  child.on("exit", (code, signal) => {
    fail(new Error(`Library watcher exited unexpectedly (${signal || code})`));
  });
  child.unref();
  child.channel?.unref();
  return watcher;
}


// fs.watch's recursive setup has no exclusion option. Split the tree only
// along ancestors of excluded folders. Permitted branches remain recursive;
// no excluded subtree is traversed or registered. Runs only in the child.
export function createBoundaryAwareWatcher(root, {
  excludedPaths = [],
  maxChildren = 1024,
  fsImpl = fs,
} = {}, onChange) {
  const output = new EventEmitter();
  const watches = new Map();
  const excluded = normalizeLibraryScanExclusions(excludedPaths);
  let closed = false;

  output.close = () => {
    if (closed) return;
    closed = true;
    for (const { watcher } of watches.values()) watcher.close();
    watches.clear();
  };
  const fail = (error) => {
    if (closed) return;
    output.close();
    output.emit("error", error);
  };
  const allowed = (candidate) => !isLibraryBoundaryExcluded(candidate, excluded);
  let synchronize;
  const addWatch = (directory, recursive) => {
    const watcher = fsImpl.watch(directory, { recursive }, (eventType, filename) => {
      if (closed) return;
      try {
        if (!recursive && (eventType === "rename" || filename == null)) synchronize();
        const changed = filename == null ? directory : path.resolve(directory, String(filename));
        if (allowed(changed) && isWithinLibraryPath(root, changed)) {
          onChange(eventType, path.relative(root, changed) || null);
        }
      } catch (error) {
        fail(error);
      }
    });
    watcher.on("error", fail);
    watches.set(directory, { watcher, recursive });
  };
  synchronize = () => {
    if (closed) return;
    const wanted = new Map();
    const collect = (directory) => {
      if (!allowed(directory)) return;
      const recursive = !excluded.some((boundary) => isWithinLibraryPath(directory, boundary));
      wanted.set(directory, recursive);
      if (wanted.size > maxChildren) {
        throw Object.assign(new Error("Library exceeds bounded watcher limit; manual refresh remains available"), { code: "ENOSPC" });
      }
      if (recursive) return;
      let entries;
      try { entries = fsImpl.readdirSync(directory, { withFileTypes: true }); }
      catch (error) { if (error?.code === "ENOENT") return; throw error; }
      for (const entry of entries) {
        if (entry.isDirectory() && !entry.name.startsWith(".")) collect(path.join(directory, entry.name));
      }
    };
    collect(root);
    for (const [directory, entry] of watches) {
      if (!wanted.has(directory) || wanted.get(directory) !== entry.recursive) {
        entry.watcher.close(); watches.delete(directory);
      }
    }
    for (const [directory, recursive] of wanted) {
      if (watches.has(directory)) continue;
      try { addWatch(directory, recursive); }
      catch (error) { if (error?.code !== "ENOENT") throw error; }
    }
  };
  try {
    // Register the parent first so artists created during discovery are seen.
    if (allowed(root)) addWatch(root, false);
    synchronize();
  } catch (error) {
    output.close();
    throw error;
  }
  return output;
}
