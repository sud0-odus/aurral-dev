import {
  enqueueHonkerStartupTasks,
  configureHonkerQueueWake,
  getHonkerQueueByName,
  hasClaimableHonkerJobs,
  hasExpiredHonkerClaims,
  getHonkerQueueNextClaimAt,
  listBackgroundGroupsWithWork,
  getNextBackgroundWorkAt,
  startHonkerScheduler,
} from "./honkerDb.js";
import { recoverExitedWorkerJobs, recoverJobsClaimedBeforeStart } from "./backgroundJobRecovery.js";
import { createBackgroundProcessSupervisor } from "./backgroundProcessSupervisor.js";
import { ISOLATED_QUEUE_GROUPS, isQueueOwnedByGroup } from "./backgroundWorkerQueues.js";
import { getHonkerWorkerStatuses, isHonkerShuttingDown, registerHonkerShutdownHandler } from "./honkerWorkerRuntime.js";
import { HONKER_QUEUE_NAMES } from "./honkerDb.js";
import { configureDownloadOwnerClient } from "./downloadJobs/downloadOwnerClient.js";
import { getDatabaseRevision } from "../config/db-sqlite.js";
import { dbOps } from "../db/helpers/index.js";

let backgroundWorkersStarted = false;
let workerSupervisorStarted = false;
let workerSupervisorInterval = null;
let workerSupervisorTimer = null;
let workerSupervisorTimerAt = null;
let workerSweepInterval = null;
const startingQueues = new Set();
let supervisedGroup = null;
let backgroundProcessSupervisor = null;
let lastExpiredSweepAt = 0;
let stopLibraryFileWatcher = null;
let lastWorkerDatabaseRevision = null;

export function getIsolatedWorkerStatuses() {
  return backgroundProcessSupervisor?.getWorkerStatuses() || [];
}

const WORKER_SUPERVISOR_POLL_MS = Math.max(
  process.env.AURRAL_BACKGROUND_WORKER_GROUP ? 1000 : 15000,
  Math.floor(Number(process.env.AURRAL_WORKER_SUPERVISOR_POLL_MS) ||
    (process.env.AURRAL_BACKGROUND_WORKER_GROUP ? 2000 : 60000)),
);

const WORKER_STARTS = {
  "release-metadata-refresh": ["./releaseMetadataWorker.js", "startReleaseMetadataWorker"],
  "system-task": ["./systemTaskWorker.js", "startSystemTaskWorker"],
  "system-task-maintenance": ["./systemTaskWorker.js", "startMaintenanceTaskWorker"],
  "system-task-inbox": ["./systemTaskWorker.js", "startInboxTaskWorker"],
  "playback": ["./systemTaskWorker.js", "startPlaybackTaskWorker"],
  "library-scan": ["./libraryScanWorker.js", "startLibraryScanWorker"],
  "library-files": ["./libraryFiles/libraryFileWorker.js", "startLibraryFileWorker"],
  "_outbox:notifications": ["./notificationOutboxWorker.js", "startNotificationOutboxWorker"],
  "_outbox:play-events": ["./playEventOutboxWorker.js", "startPlayEventOutboxWorker"],
  "slskd-pipeline": ["./downloadPipelineWorker.js", "startDownloadPipelineWorker"],
  "ytdlp-pipeline": ["./downloadPipelineWorker.js", "startDownloadPipelineWorker"],
  "download-finalize": ["./downloadPipelineWorker.js", "startDownloadPipelineWorker"],
  "discovery-refresh": ["./discoveryRefreshWorker.js", "startDiscoveryRefreshWorker"],
  "discovery-user-refresh": ["./discoveryUserRefreshWorker.js", "startDiscoveryUserRefreshWorker"],
  "weekly-flow-operation": ["./playlists/playlistOperationWorker.js", "startPlaylistOperationWorker"],
  "playlist-mbid-enrichment": ["./playlistMbidEnrichmentWorker.js", "startPlaylistMbidEnrichmentWorker"],
};

const QUEUE_WORKERS = HONKER_QUEUE_NAMES.map((queue) => ({
  queue,
  start: WORKER_STARTS[queue],
})).filter((worker) => Array.isArray(worker.start));

function startQueueWorker([modulePath, startName], queueName) {
  if (startingQueues.has(queueName)) return;
  startingQueues.add(queueName);
  import(modulePath)
    .then((module) => {
      if (!isHonkerShuttingDown() && workerSupervisorStarted) module[startName]();
    })
    .catch((error) => {
      lastWorkerDatabaseRevision = null;
      console.warn(`[AppRuntime] Failed to start ${queueName}:`, error?.message || error);
    })
    .finally(() => startingQueues.delete(queueName));
}

function clearSupervisorWakeTimer() {
  if (!workerSupervisorTimer) return;
  clearTimeout(workerSupervisorTimer);
  workerSupervisorTimer = null;
  workerSupervisorTimerAt = null;
}

function scheduleSupervisorWake(nextClaimAt) {
  const timestamp = Number(nextClaimAt);
  if (!Number.isFinite(timestamp) || timestamp <= 0) {
    clearSupervisorWakeTimer();
    return;
  }
  const waitMs = timestamp * 1000 - Date.now();
  if (waitMs <= 0) return;
  const target = Date.now() + Math.max(1000, Math.min(waitMs, 2147483647));
  if (workerSupervisorTimer && workerSupervisorTimerAt <= target) return;
  clearSupervisorWakeTimer();
  workerSupervisorTimerAt = target;
  workerSupervisorTimer = setTimeout(
    () => {
      workerSupervisorTimer = null;
      workerSupervisorTimerAt = null;
      checkQueuedBackgroundWork(supervisedGroup);
    },
    target - Date.now(),
  );
  if (typeof workerSupervisorTimer.unref === "function") {
    workerSupervisorTimer.unref();
  }
}

function sweepExpiredWorkerQueues(group) {
  if (Date.now() - lastExpiredSweepAt < 30000) return 0;
  lastExpiredSweepAt = Date.now();
  let swept = 0;
  for (const worker of QUEUE_WORKERS) {
    if (!isQueueOwnedByGroup(worker.queue, group)) continue;
    try {
      swept += Number(getHonkerQueueByName(worker.queue)?.sweepExpired()) || 0;
      if (hasExpiredHonkerClaims(worker.queue)) swept++;
    } catch (error) {
      console.warn(`[AppRuntime] Failed to recover ${worker.queue}:`, error?.message || error);
    }
  }
  return swept;
}

function checkQueuedBackgroundWork(group = null) {
  if (process.env.AURRAL_TEST_SERVER === "1" || isHonkerShuttingDown()) return;
  let nextClaimAt = null;
  const previousRevision = lastWorkerDatabaseRevision;
  lastWorkerDatabaseRevision = null;
  const revision = getDatabaseRevision();
  if (revision !== previousRevision) dbOps.invalidateSettingsCache();
  let inspected = true;
  sweepExpiredWorkerQueues(group);
  const running = new Set(getHonkerWorkerStatuses().filter((worker) => worker.running).map((worker) => worker.name));
  for (const worker of QUEUE_WORKERS) {
    if (!isQueueOwnedByGroup(worker.queue, group)) continue;
    try {
      const workerName = worker.queue === "_outbox:notifications" ? "notification-outbox"
        : worker.queue === "_outbox:play-events" ? "play-event-outbox" : worker.queue;
      if (!running.has(workerName) && !startingQueues.has(worker.queue) && hasClaimableHonkerJobs(worker.queue)) {
        startQueueWorker(worker.start, worker.queue);
      }
      const queueNextClaimAt = getHonkerQueueNextClaimAt(worker.queue);
      if (queueNextClaimAt && (nextClaimAt == null || queueNextClaimAt < nextClaimAt)) {
        nextClaimAt = queueNextClaimAt;
      }
    } catch (error) {
      inspected = false;
      console.warn(
        `[AppRuntime] Failed to inspect ${worker.queue} queue:`,
        error?.message || error,
      );
    }
  }
  scheduleSupervisorWake(nextClaimAt);
  lastWorkerDatabaseRevision = inspected ? revision : null;
}

function checkWorkerDatabaseChanges(group) {
  try {
    if (getDatabaseRevision() !== lastWorkerDatabaseRevision) checkQueuedBackgroundWork(group);
  } catch (error) {
    console.warn("[AppRuntime] Failed to check database changes:", error?.message || error);
  }
}

export function startWorkerSupervisor({ group = null } = {}) {
  if (workerSupervisorStarted || process.env.AURRAL_TEST_SERVER === "1") {
    return;
  }
  workerSupervisorStarted = true;
  supervisedGroup = group;
  checkQueuedBackgroundWork(group);
  workerSupervisorInterval = setInterval(() => checkWorkerDatabaseChanges(group), WORKER_SUPERVISOR_POLL_MS);
  workerSweepInterval = setInterval(() => {
    if (sweepExpiredWorkerQueues(group) > 0) checkQueuedBackgroundWork(group);
  }, 30000);
  workerSweepInterval.unref?.();
  if (typeof workerSupervisorInterval.unref === "function") {
    workerSupervisorInterval.unref();
  }
}

function stopWorkerSupervisor() {
  workerSupervisorStarted = false;
  supervisedGroup = null;
  lastWorkerDatabaseRevision = null;
  clearSupervisorWakeTimer();
  clearInterval(workerSweepInterval);
  workerSweepInterval = null;
  if (workerSupervisorInterval) {
    clearInterval(workerSupervisorInterval);
    workerSupervisorInterval = null;
  }
}

registerHonkerShutdownHandler(() => {
  stopWorkerSupervisor();
  stopLibraryFileWatcher?.();
  return backgroundProcessSupervisor?.stop();
});

export async function forwardWorkerBroadcast(message) {
  if (message?.type !== "websocket-broadcast" || typeof message.channel !== "string") return;
  const { websocketService } = await import("./websocketService.js");
  const userId = message.userId ?? null;
  if (message.channel === "discovery" && userId != null) {
    const [{ dbOps }, { getUserDiscoveryNamespace }] = await Promise.all([
      import("../db/helpers/index.js"),
      import("./discovery/provider.js"),
    ]);
    dbOps.invalidateDiscoveryCache(getUserDiscoveryNamespace(userId));
  } else if (message.channel === "discovery") {
    try {
      const { synchronizeDiscoveryCacheFromWorker } = await import("./discovery/persistence.js");
      synchronizeDiscoveryCacheFromWorker(message.data);
    } catch (error) {
      console.warn("[AppRuntime] Could not refresh discovery state:", error?.message || error);
    }
  }
  if (message.channel === "library" && message.data?.type === "library_scan_completed") {
    const { invalidateLibraryQueryCache } = await import("./libraryQueryService.js");
    invalidateLibraryQueryCache({ persistedGenres: false });
    const { clearSearchContextCache } = await import("./unifiedSearchService.js");
    clearSearchContextCache();
  }
  websocketService.broadcast(message.channel, message.data, { userId });
}

export function wakeQueuedBackgroundWork(group = supervisedGroup) {
  checkQueuedBackgroundWork(group);
}

export function hasQueuedBackgroundWork(group = supervisedGroup) {
  if (startingQueues.size > 0) return true;
  if (getHonkerWorkerStatuses().some((worker) => worker.running)) return true;
  return QUEUE_WORKERS.some((worker) =>
    isQueueOwnedByGroup(worker.queue, group) && hasClaimableHonkerJobs(worker.queue));
}

export function startBackgroundWorkers({ logger = console } = {}) {
  if (backgroundWorkersStarted || process.env.AURRAL_TEST_SERVER === "1") {
    return false;
  }
  backgroundWorkersStarted = true;
  recoverJobsClaimedBeforeStart(logger).catch((error) => {
    logger.warn?.("[AppRuntime] Could not recover jobs from before the restart:", error?.message || error);
  });
  import("./honkerTaskStatus.js")
    .then(({ clearStaleHonkerJobs }) => clearStaleHonkerJobs())
    .then((result) => {
      if (Number(result?.cleared || 0) > 0) {
        logger.info?.(`[AppRuntime] Cleared ${result.cleared} stuck background job(s) on startup`);
      }
    })
    .catch((error) => {
      logger.warn?.(
        "[AppRuntime] Failed to clear stuck background jobs on startup:",
        error?.message || error,
      );
    });
  import("./aurralHistoryService.js")
    .then(({ syncProcessingActivityHistory }) => syncProcessingActivityHistory())
    .catch((error) => {
      logger.warn?.(
        "[AppRuntime] Failed to reconcile stuck activity history on startup:",
        error?.message || error,
      );
    });
  enqueueHonkerStartupTasks();
  if (HONKER_QUEUE_NAMES.some((queue) => isQueueOwnedByGroup(queue))) {
    startWorkerSupervisor();
  }
  backgroundProcessSupervisor = createBackgroundProcessSupervisor({
    logger,
    getWorkRevision: getDatabaseRevision,
    getNextWorkAt: getNextBackgroundWorkAt,
    findGroupsWithWork: (now) => (isHonkerShuttingDown() ? [] : listBackgroundGroupsWithWork(now)),
    onMessage(message, _group, child) {
      if (message?.type === "queue-wake") {
        const owner = ISOLATED_QUEUE_GROUPS[message.queue];
        if (owner) backgroundProcessSupervisor.wake(owner);
        else if (isQueueOwnedByGroup(message.queue)) checkQueuedBackgroundWork();
        return;
      }
      if (message?.type === "download-owner-client-request") {
        void backgroundProcessSupervisor.request("downloads", message.method, message.args, {
          timeoutMs: Math.min(30 * 60 * 1000, Number(message.timeoutMs) || 30000),
        }).then((result) => {
          if (child.connected) child.send({
            type: "download-owner-client-response", requestId: message.requestId, result,
          });
        }).catch((error) => {
          if (child.connected) child.send({
            type: "download-owner-client-response", requestId: message.requestId,
            error: error?.message || String(error),
          });
        });
        return;
      }
      if (message?.type === "cache-invalidate" && message.cache === "playlists") {
        void Promise.all([
          import("../db/helpers/index.js"),
          import("./playlists/flowPlaylistConfig.js"),
        ]).then(([{ dbOps }, { invalidateFlowPlaylistConfigCache }]) => {
          dbOps.invalidateSettingsCache();
          invalidateFlowPlaylistConfigCache();
        }).catch((error) => {
          logger.warn?.("[AppRuntime] Could not refresh flow cache:", error?.message || error);
        });
        return;
      }
      if (message?.type === "cache-invalidate" && message.cache === "lidarr-artists") {
        void import("./libraryManager.js").then(({ invalidateLidarrArtistCache }) => {
          invalidateLidarrArtistCache();
        }).catch((error) => {
          logger.warn?.("[AppRuntime] Could not refresh Lidarr artist cache:", error?.message || error);
        });
        return;
      }
      if (message?.type === "job-finished" && _group === "downloads") {
        void Promise.all([
          import("../db/helpers/index.js"),
          import("./playlists/flowPlaylistConfig.js"),
        ]).then(([{ dbOps }, { invalidateFlowPlaylistConfigCache }]) => {
          dbOps.invalidateSettingsCache();
          invalidateFlowPlaylistConfigCache();
        });
        return;
      }
      if (message?.type === "cache-invalidate" && message.cache === "news") {
        void import("./newsService.js").then(({ invalidateNewsResponseCache }) => {
          invalidateNewsResponseCache();
        }).catch((error) => {
          logger.warn?.("[AppRuntime] Could not refresh news cache:", error?.message || error);
        });
        return;
      }
      void forwardWorkerBroadcast(message).catch((error) => {
        logger.warn?.("[AppRuntime] Failed to forward worker update:", error?.message || error);
      });
    },
    onExit(group, _code, _signal, pid, reason, retired) {
      const recovery = recoverExitedWorkerJobs(group, pid, logger, reason).catch((error) => {
        logger.warn?.(`[AppRuntime] Could not recover ${group} jobs:`, error?.message || error);
      });
      if (retired) return recovery;
      if (group !== "discovery-refresh") return recovery;
      void import("./discovery/persistence.js")
        .then(({ markInterruptedDiscoveryRefresh }) => {
          markInterruptedDiscoveryRefresh("Discovery refresh stopped unexpectedly");
          return forwardWorkerBroadcast({
            type: "websocket-broadcast",
            channel: "discovery",
            data: {
              type: "discovery_update",
              isUpdating: false,
              phase: "error",
              progressMessage: "Discovery refresh stopped; queued jobs will retry",
            },
          });
        })
        .catch((error) => {
          logger.warn?.("[AppRuntime] Failed to report discovery restart:", error?.message || error);
        });
      return recovery;
    },
  });
  configureDownloadOwnerClient({
    request: (method, args, options) =>
      backgroundProcessSupervisor.request("downloads", method, args, options),
    getStatus: () => backgroundProcessSupervisor.getDownloadOwnerStatus(),
  });
  configureHonkerQueueWake((queue) => {
    if (isHonkerShuttingDown()) return;
    const owner = ISOLATED_QUEUE_GROUPS[queue];
    if (owner) backgroundProcessSupervisor.wake(owner);
    else checkQueuedBackgroundWork();
  });
  backgroundProcessSupervisor.start();
  void import("./libraryFileWatcher.js")
    .then((module) => {
      stopLibraryFileWatcher = module.stopLibraryFileWatcher;
      if (isHonkerShuttingDown()) return;
      return module.startLibraryFileWatcher({ logger });
    })
    .catch((error) => {
      logger.warn?.(
        "[AppRuntime] Failed to start library file watcher:",
        error?.message || error,
      );
    });
  return true;
}

export function initializeAppRuntime({ logger = console } = {}) {
  if (process.env.AURRAL_TEST_SERVER === "1") startHonkerScheduler();
  startBackgroundWorkers({ logger });
}
