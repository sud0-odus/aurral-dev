#!/usr/bin/env python3
"""Bounded read-only probe; stdout is a credential-redacted JSON inventory."""
import argparse
import configparser
import errno
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

SECRETS = set()
PATHS = set()
WARNINGS = []
MAX_FILE = 2 * 1024 * 1024
SECRET_KEY = re.compile(r'password|passwd|api.?key|token|secret|cookie|credential', re.I)


def remember(key, value):
    if SECRET_KEY.search(str(key)) and isinstance(value, str) and len(value) >= 6:
        SECRETS.add(value)


def scrub(value):
    if isinstance(value, dict):
        return {str(k): scrub(v) for k, v in value.items()}
    if isinstance(value, list):
        return [scrub(v) for v in value]
    if isinstance(value, str):
        for secret in sorted(SECRETS, key=len, reverse=True):
            value = value.replace(secret, '[redacted]')
        return value
    return value


def origin(raw):
    if not raw or not isinstance(raw, str):
        return None
    try:
        url = urllib.parse.urlsplit(raw if '://' in raw else 'http://' + raw)
        if not url.hostname:
            return None
        host = '[' + url.hostname + ']' if ':' in url.hostname else url.hostname
        return url.scheme + '://' + host + (':' + str(url.port) if url.port else '')
    except ValueError:
        return None


def path_value(value):
    if isinstance(value, str) and value.strip():
        value = value.strip()
        if value.startswith('/'):
            PATHS.add(value)
        return value
    return None


def run(args, timeout=5, cap=MAX_FILE):
    # Output stays local until selected fields have been extracted.
    try:
        with subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL) as proc:
            try:
                out = proc.communicate(timeout=timeout)[0]
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.communicate()
                return None
            return out.decode(errors='replace') if proc.returncode == 0 and len(out) <= cap else None
    except OSError:
        return None


def read_text(path):
    try:
        target = Path(path)
        if target.stat().st_size > MAX_FILE:
            return None
        return target.read_text(errors='replace')
    except OSError:
        return None


def json_value(value, default=None):
    try:
        return json.loads(value) if value is not None else default
    except (ValueError, TypeError):
        return default


def service(name):
    text = run(['systemctl', 'show', name, '--property=LoadState,ActiveState,SubState,MainPID,User,Group,Result,FragmentPath,WorkingDirectory'])
    if text is None:
        return {'query_failed': True}, None, []
    values = dict(line.split('=', 1) for line in text.splitlines() if '=' in line)
    pid = values.get('MainPID', '0')
    args = []
    if pid.isdigit() and int(pid) > 0:
        try:
            args = Path('/proc', pid, 'cmdline').read_bytes().decode(errors='replace').split('\0')
            status = Path('/proc', pid, 'status').read_text()
            values['effective_identity'] = {line.split(':', 1)[0].lower(): int(line.split()[2])
                for line in status.splitlines() if line.startswith(('Uid:', 'Gid:'))}
        except (OSError, IndexError, ValueError):
            pass
    return values, pid if pid.isdigit() and int(pid) > 0 else None, args


def environment(pid, keys):
    result = {}
    if pid:
        try:
            for item in Path('/proc', pid, 'environ').read_bytes().split(b'\0'):
                key, sep, value = item.partition(b'=')
                name = key.decode(errors='replace')
                if sep and name in keys:
                    result[name] = value.decode(errors='replace')
                    remember(name, result[name])
        except OSError:
            pass
    return result


def env_file(path, keys):
    result = {}
    for line in (read_text(path) or '').splitlines():
        key, sep, value = line.strip().removeprefix('export ').partition('=')
        key = key.strip()
        if sep and key in keys:
            value = value.strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
                value = value[1:-1]
            result[key] = value
            remember(key, value)
    return result


def config_candidates(args, defaults, flags=('-c', '-f', '--config', '--config-file')):
    candidates = []
    for i, arg in enumerate(args):
        if arg in flags and i + 1 < len(args):
            candidates.append(args[i + 1])
        elif any(arg.startswith(flag + '=') for flag in flags):
            candidates.append(arg.split('=', 1)[1])
    return list(dict.fromkeys(candidates + defaults))


def mount_options(raw):
    allowed = {'ro', 'rw', 'relatime', 'noatime', 'nosuid', 'nodev', 'noexec', 'vers', 'nfsvers',
               'sec', 'uid', 'gid', 'anonuid', 'anongid', 'file_mode', 'dir_mode', 'proto', 'hard', 'soft'}
    return ','.join(option for option in str(raw or '').split(',') if option.split('=', 1)[0] in allowed)


def safe_mount_source(raw):
    value = str(raw or '')
    value = re.sub(r'(?<=//)[^/@\s]+@', '[redacted]@', value)
    return value.split('?', 1)[0]


def flatten_mounts(records):
    output = []
    for entry in records or []:
        target = entry.get('target', '')
        fs = entry.get('fstype', '')
        if target == '/' or fs in {'nfs', 'nfs4', 'cifs', 'ext4', 'xfs', 'btrfs', 'zfs', 'overlay', '9p', 'virtiofs'} or target.startswith(('/music', '/downloads', '/data', '/mnt/', '/media/')):
            output.append({'target': target, 'source': safe_mount_source(entry.get('source')),
                           'fstype': fs, 'options': mount_options(entry.get('options'))})
        output.extend(flatten_mounts(entry.get('children', [])))
    return output[:256]


def path_stat(path):
    result = {'path': path}
    try:
        info = os.stat(path)
        result.update(exists=True, is_directory=Path(path).is_dir(), realpath=os.path.realpath(path),
                      device=info.st_dev, inode=info.st_ino, uid=info.st_uid, gid=info.st_gid,
                      mode=oct(info.st_mode & 0o7777), probe_can_read=os.access(path, os.R_OK),
                      probe_can_write=os.access(path, os.W_OK))
        fs = os.statvfs(path)
        result['available_bytes'] = fs.f_bavail * fs.f_frsize
    except OSError as error:
        result.update(exists=False if error.errno in {errno.ENOENT, errno.ENOTDIR} else None,
                      stat_error_errno=error.errno)
    return result


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def api_get(base, key, endpoint):
    if not key or key.startswith('AURRAL_ENC:'):
        return None, 'credential unavailable to this read-only probe'
    remember('apiKey', key)
    try:
        parsed = urllib.parse.urlsplit(base)
        if parsed.scheme not in {'http', 'https'} or not parsed.hostname:
            return None, 'invalid endpoint'
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect)
        request = urllib.request.Request(base.rstrip('/') + endpoint,
            headers={'X-Api-Key': key, 'Accept': 'application/json'})
        with opener.open(request, timeout=4) as response:
            data = response.read(MAX_FILE + 1)
            if len(data) > MAX_FILE:
                return None, 'response exceeds 2 MiB cap'
            return json.loads(data), None
    except urllib.error.HTTPError as error:
        return None, 'HTTP ' + str(error.code)
    except (OSError, ValueError):
        return None, 'request failed (network, TLS, or JSON)'


def arr_config(args, name):
    paths = []
    for i, arg in enumerate(args):
        if arg.lower().startswith(('-data=', '--data=')):
            paths.append(str(Path(arg.split('=', 1)[1]) / 'config.xml'))
        elif arg.lower() in {'-data', '--data'} and i + 1 < len(args):
            paths.append(str(Path(args[i + 1]) / 'config.xml'))
    paths += [f'/var/lib/{name}/config.xml', f'/root/.config/{name.capitalize()}/config.xml', '/config/config.xml']
    for path in dict.fromkeys(paths):
        text = read_text(path)
        if text is None:
            continue
        try:
            root = ET.fromstring(text)
            key = root.findtext('ApiKey') or ''
            remember('ApiKey', key)
            ssl = (root.findtext('EnableSsl') or '').lower() == 'true'
            port = root.findtext('SslPort' if ssl else 'Port') or ('6868' if ssl else '8686' if name == 'lidarr' else '9696')
            base = '/' + (root.findtext('UrlBase') or '').strip('/')
            return {'file': path, 'key_present': bool(key), 'bind_address': root.findtext('BindAddress'),
                    'port': port, 'ssl': ssl, 'url_base': base}, f"{'https' if ssl else 'http'}://127.0.0.1:{port}{base.rstrip('/')}", key
        except ET.ParseError:
            continue
    return {'config_not_found': True}, None, None


def field_summary(item):
    output = {key: item.get(key) for key in ['name', 'implementation', 'enable', 'protocol', 'priority']}
    fields = {}
    for field in item.get('fields') or []:
        if not isinstance(field, dict):
            continue
        name, value = str(field.get('name', '')), field.get('value')
        remember(name, value)
        if SECRET_KEY.search(name):
            fields[name + '_present'] = bool(value)
        elif name.lower() in {'host', 'server', 'url', 'baseurl', 'prowlarrurl', 'lidarrurl', 'sabnzbdurl', 'port', 'usessl', 'category', 'musiccategory', 'tvcategory', 'categories', 'synclevel', 'addpaused', 'removemetadata'}:
            if 'url' in name.lower() or name.lower() in {'host', 'server'}:
                fields[name] = origin(value) if isinstance(value, str) else None
            else:
                fields[name] = value
        elif name.lower() in {'directory', 'downloadpath', 'downloadclientpath', 'mappedpath', 'downloadfolder', 'completeddownloadfolder', 'localpath', 'remotepath'}:
            fields[name] = path_value(value)
    output['fields'] = fields
    return output


def arr_inventory(name, args):
    config, base, key = arr_config(args, name)
    output = {'config': config}
    if not base or not key:
        return output
    status, error = api_get(base, key, '/api/v1/system/status')
    if error or not isinstance(status, dict) or not status.get('version'):
        output['api_status'] = error or 'unexpected status response'
        return output
    output['version'] = status.get('version')
    output['api_status'] = 'reachable'
    endpoints = ['downloadclient', 'indexer', 'health']
    endpoints += ['rootfolder', 'remotepathmapping', 'qualityprofile', 'metadataprofile'] if name == 'lidarr' else ['applications']
    for endpoint in endpoints:
        data, error = api_get(base, key, '/api/v1/' + endpoint)
        if error or not isinstance(data, list):
            output[endpoint] = {'unavailable': error or 'unexpected response'}
            continue
        if len(data) > 200:
            WARNINGS.append(name + ' ' + endpoint + ' capped at 200 entries')
        safe = []
        for item in data[:200]:
            if not isinstance(item, dict):
                continue
            if endpoint in {'downloadclient', 'applications'}:
                safe.append(field_summary(item))
            elif endpoint == 'indexer':
                result = {k: item.get(k) for k in ['name', 'implementation', 'protocol', 'enable', 'enableRss', 'enableAutomaticSearch', 'enableInteractiveSearch', 'privacy', 'priority', 'syncProfileId', 'tags']}
                for field in item.get('fields') or []:
                    if isinstance(field, dict):
                        remember(field.get('name'), field.get('value'))
                safe.append(result)
            elif endpoint == 'rootfolder':
                safe.append({'path': path_value(item.get('path')), 'accessible': item.get('accessible'), 'free_space_bytes': item.get('freeSpace')})
            elif endpoint == 'remotepathmapping':
                safe.append({'host': origin(item.get('host')), 'remotePath': item.get('remotePath'), 'localPath': path_value(item.get('localPath'))})
            elif endpoint == 'health':
                safe.append({k: item.get(k) for k in ['source', 'type']})
            else:
                safe.append({k: item.get(k) for k in ['id', 'name', 'upgradeAllowed']})
        output[endpoint] = safe
    if name == 'lidarr':
        for endpoint in ['config/downloadclient', 'config/mediamanagement']:
            data, error = api_get(base, key, '/api/v1/' + endpoint)
            output[endpoint] = ({k: data.get(k) for k in ['enableCompletedDownloadHandling', 'autoRedownloadFailed', 'autoRedownloadFailedFromInteractiveSearch', 'copyUsingHardlinks', 'setPermissionsLinux', 'chmodFolder', 'chownGroup']}
                if isinstance(data, dict) else {'unavailable': error or 'unexpected response'})
    return output


def readonly_db(path):
    con = sqlite3.connect(Path(path).resolve().as_uri() + '?mode=ro', uri=True, timeout=2)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA query_only=ON')
    return con


def normalize_mode(raw):
    mode = str(raw or '').strip().lower()
    return 'download' if mode == 'download' else 'reuse'


def aurral_inventory(pid):
    keys = {'PLAYLIST_FOLDER', 'WEEKLY_FLOW_FOLDER', 'DOWNLOAD_FOLDER', 'PATH_MAPPINGS', 'AURRAL_DATA_DIR',
            'LIDARR_URL', 'LIDARR_API_KEY', 'SLSKD_URL', 'SLSKD_API_KEY', 'SABNZBD_URL', 'SABNZBD_API_KEY', 'PROWLARR_URL', 'PROWLARR_API_KEY',
            'NZBGET_URL', 'NZBGET_USER', 'NZBGET_PASS', 'LASTFM_API_KEY'}
    env = env_file('/opt/aurral/backend/.env', keys) | environment(pid, keys)
    output = {'env_file_checked': '/opt/aurral/backend/.env'}
    databases = ['/opt/aurral_data/aurral.db']
    if env.get('AURRAL_DATA_DIR'):
        databases.insert(0, str(Path(env['AURRAL_DATA_DIR']) / 'aurral.db'))
    rows = None
    for database in dict.fromkeys(databases):
        if not Path(database).is_file():
            continue
        try:
            with readonly_db(database) as con:
                rows = {row['key']: row['value'] for row in con.execute(
                    "SELECT key,value FROM settings WHERE key IN ('downloadFolderPath','rootFolderPath','playlistWorker','weeklyFlowWorker','pathMappings','integrations')")}
            output['database'] = database
            break
        except sqlite3.Error:
            WARNINGS.append('Could not read Aurral settings database')
    if rows is None:
        output['settings_unavailable'] = True
        return output
    stored = rows.get('downloadFolderPath')
    selected_env = next((name for name in ['PLAYLIST_FOLDER', 'WEEKLY_FLOW_FOLDER', 'DOWNLOAD_FOLDER'] if env.get(name)), None)
    default = '/data/downloads/aurral' if os.path.isdir('/data') and os.access('/data', os.W_OK) else '/opt/aurral_data/downloads/aurral'
    folder = stored or (env[selected_env] if selected_env else default)
    output['download_folder'] = {'path': path_value(folder), 'source': 'settings' if stored else selected_env or 'inferred_default',
                                 'runtime_path_verified': bool(stored)}
    output['stored_root_folder'] = path_value(rows.get('rootFolderPath'))
    worker = json_value(rows.get('playlistWorker') or rows.get('weeklyFlowWorker'), {}) or {}
    output['worker'] = {'concurrency': worker.get('concurrency', 2), 'existing_file_mode': normalize_mode(worker.get('existingFileMode'))}
    mappings = json_value(rows.get('pathMappings'), []) or []
    output['path_mappings'] = [{'source': m.get('source', 'all'), 'remote': m.get('remote'), 'local': path_value(m.get('local'))}
                              for m in mappings[:100] if isinstance(m, dict)]
    output['environment_path_mappings'] = []
    for segment in env.get('PATH_MAPPINGS', '').split(';'):
        pieces = segment.split('|')
        if len(pieces) in {2, 3}:
            output['environment_path_mappings'].append({'source': pieces[0] if len(pieces) == 3 else 'all',
                'remote': pieces[-2], 'local': path_value(pieces[-1])})
    integrations = json_value(rows.get('integrations'), {}) or {}
    output['integrations'] = {}
    for name in ['lidarr', 'slskd', 'sabnzbd', 'nzbget', 'prowlarr', 'ytdlp', 'navidrome']:
        data = integrations.get(name) or {}
        if not isinstance(data, dict):
            continue
        for k, v in data.items():
            remember(k, v)
        prefix = name.upper()
        credential = data.get('apiKey') or data.get('password') or env.get(prefix + '_API_KEY') or env.get(prefix + '_PASS')
        entry = {'enabled': data.get('enabled'), 'endpoint': origin(data.get('url') or env.get(prefix + '_URL')),
                 'credential_present': bool(credential), 'credential_encrypted': isinstance(credential, str) and credential.startswith('AURRAL_ENC:'),
                 'credential_validity_tested': False, 'priority': data.get('priority')}
        for field in ['rootFolderPath', 'stagingPath', 'downloadPath', 'downloadFolder', 'outputPath']:
            if data.get(field):
                entry[field] = path_value(data[field])
        if isinstance(data.get('rootFolderPaths'), list):
            entry['rootFolderPaths'] = [path_value(p) for p in data['rootFolderPaths'][:100] if isinstance(p, str)]
        output['integrations'][name] = entry
    # Probe known aliases and transfer roots without walking any media files.
    for path in ['/music', '/music/Aurral', '/music/Downloads', '/downloads/aurral', '/downloads/slskd', '/downloads/sabnzbd', '/opt/aurral_data/_staging']:
        PATHS.add(path)
    output['lastfm_key_present'] = bool((integrations.get('lastfm') or {}).get('apiKey') or env.get('LASTFM_API_KEY'))
    return output


def configobj_sections(text):
    """Subset needed for SAB's scalar folder/server/category settings; never executes config."""
    output = {}
    levels = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith(('#', ';')):
            continue
        match = re.fullmatch(r'(\[+)([^\[\]]+)(\]+)', line)
        if match and len(match[1]) == len(match[3]):
            depth = len(match[1])
            levels = levels[:depth - 1] + [match[2].strip()]
            continue
        key, sep, value = line.partition('=')
        if not sep:
            continue
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
            value = value[1:-1]
        remember(key, value)
        output.setdefault(tuple(levels), {})[key.strip()] = value
    return output


def sab_inventory(args):
    candidates = config_candidates(args, ['/root/.sabnzbd/sabnzbd.ini', '/var/lib/sabnzbd/sabnzbd.ini', '/opt/sabnzbd/sabnzbd.ini', '/etc/sabnzbd/sabnzbd.ini'])
    for candidate in candidates:
        text = read_text(candidate)
        if text is None:
            continue
        sections = configobj_sections(text)
        misc = sections.get(('misc',), {})
        if not misc:
            continue
        output = {'config_file': candidate, 'folders': {}, 'servers': [], 'categories': []}
        for key in ['download_dir', 'complete_dir', 'dirscan_dir', 'nzb_backup_dir', 'script_dir', 'admin_dir']:
            output['folders'][key] = path_value(misc.get(key))
        output['web'] = {'host': misc.get('host'), 'port': misc.get('port'), 'https_port': misc.get('https_port'),
                         'enable_https': misc.get('enable_https'), 'api_key_present': bool(misc.get('api_key'))}
        for section, values in sections.items():
            if len(section) == 2 and section[0] == 'servers':
                output['servers'].append({k: values.get(k) for k in ['name', 'host', 'port', 'ssl', 'connections', 'enable', 'required', 'optional', 'priority', 'retention']})
            elif len(section) == 2 and section[0] == 'categories':
                rawdir = values.get('dir', '')
                complete = misc.get('complete_dir', '')
                effective = rawdir if rawdir.startswith('/') else os.path.join(complete, rawdir) if complete else None
                output['categories'].append({'name': section[1], 'folder_setting': rawdir,
                                              'resolved_folder_if_absolute_base': path_value(effective), 'priority': values.get('priority')})
        return output
    return {'config_not_found': True}


def qb_inventory(args):
    candidates = ['/root/.config/qBittorrent/qBittorrent.conf', '/home/qbittorrent/.config/qBittorrent/qBittorrent.conf',
                  '/var/lib/qbittorrent/.config/qBittorrent/qBittorrent.conf', '/config/qBittorrent/qBittorrent.conf', '/opt/qbittorrent/config/qBittorrent.conf']
    for arg in args:
        if arg.startswith('--profile='):
            candidates.insert(0, str(Path(arg.split('=', 1)[1]) / 'qBittorrent' / 'config' / 'qBittorrent.conf'))
    output = {'configs': []}
    for candidate in dict.fromkeys(candidates):
        text = read_text(candidate)
        if text is None:
            continue
        parser = configparser.RawConfigParser(strict=False, interpolation=None)
        parser.optionxform = str
        try:
            parser.read_string(text)
        except configparser.Error:
            continue
        fields = {}
        for section in parser.sections():
            for key, value in parser.items(section):
                remember(key, value)
                if key in {'Downloads\\SavePath', 'Downloads\\TempPath', 'Downloads\\TempPathEnabled', 'Session\\DefaultSavePath', 'Session\\TempPath', 'Session\\TempPathEnabled', 'WebUI\\Address', 'WebUI\\Port', 'WebUI\\HTTPS\\Enabled', 'Connection\\Interface', 'Session\\Interface', 'Session\\InterfaceName'}:
                    fields[section + '/' + key] = path_value(value) if 'Path' in key and 'Enabled' not in key else value
        categories_file = str(Path(candidate).with_name('categories.json'))
        categories = json_value(read_text(categories_file), {})
        safe_categories = []
        if isinstance(categories, dict):
            for name, category in list(categories.items())[:100]:
                if isinstance(category, dict):
                    safe_categories.append({'name': name, 'save_path': path_value(category.get('save_path') or category.get('savePath'))})
        output['configs'].append({'file': candidate, 'fields': fields, 'categories': safe_categories})
    if not output['configs']:
        output['config_not_found'] = True
    return output


def rdt_inventory(args):
    candidates = ['/opt/rdtclient/db/rdtclient.db', '/opt/rdtclient/rdtclient.db', '/data/db/rdtclient.db',
                  '/data/rdtclient.db', '/config/rdtclient.db', '/opt/rdt-client/db/rdtclient.db']
    for arg in args:
        if arg.endswith('.dll') and arg.startswith('/'):
            candidates.insert(0, str(Path(arg).parent / 'db' / 'rdtclient.db'))
    for candidate in dict.fromkeys(candidates):
        if not Path(candidate).is_file():
            continue
        try:
            with readonly_db(candidate) as con:
                columns = {row['name'] for row in con.execute('PRAGMA table_info(Settings)')}
                if not {'SettingId', 'Value'} <= columns:
                    continue
                rows = con.execute('SELECT SettingId,Value FROM Settings LIMIT 500').fetchall()
            fields = {}
            for row in rows:
                key, value = row['SettingId'], row['Value']
                remember(key, value)
                if key in {'DownloadClient:DownloadPath', 'DownloadClient:MappedPath', 'DownloadClient:Client', 'DownloadClient:DownloadClientType',
                           'DownloadClient:AddCategoryToPath', 'DownloadClient:DeleteOnImport', 'Provider:Provider', 'Provider', 'DownloadPath', 'MappedPath'}:
                    fields[key] = path_value(value) if key.endswith('Path') else value
            return {'database': candidate, 'fields': fields, 'queue_and_provider_credentials_not_exported': True}
        except sqlite3.Error:
            continue
    return {'config_not_found': True}


def slskd_inventory(pid, args):
    env = environment(pid, {'SLSKD_APP_DIR', 'SLSKD_CONFIG', 'SLSKD_DOWNLOADS_DIR', 'SLSKD_INCOMPLETE_DIR'})
    candidates = config_candidates(args, ['/var/lib/slskd/slskd.yml', '/etc/slskd/slskd.yml', '/opt/slskd/slskd.yml',
                                          '/root/.local/share/slskd/slskd.yml', '/opt/slskd/config/slskd.yml', '/opt/slskd/data/slskd.yml'], ('--config',))
    if env.get('SLSKD_CONFIG'):
        candidates.insert(0, env['SLSKD_CONFIG'])
    if env.get('SLSKD_APP_DIR'):
        candidates.insert(0, str(Path(env['SLSKD_APP_DIR']) / 'slskd.yml'))
    output = {'directories': {key: path_value(value) for key, value in env.items() if key.endswith('_DIR')}}
    for candidate in dict.fromkeys(candidates):
        text = read_text(candidate)
        if text is None:
            continue
        output['config_file'] = candidate
        section = None
        for line in text.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                continue
            if not line[0].isspace():
                section = stripped.split(':', 1)[0]
            key, sep, value = stripped.partition(':')
            remember(key, value.strip())
            if section == 'directories' and key in {'downloads', 'incomplete'} and sep:
                output['directories'][key] = path_value(value.strip().strip('"\''))
        break
    if 'config_file' not in output:
        output['config_not_found'] = True
    return output


def nzbget_inventory(args):
    candidates = config_candidates(args, ['/usr/local/etc/nzbget.conf', '/etc/nzbget.conf', '/opt/nzbget/nzbget.conf', '/usr/local/nzbget/nzbget.conf', '/root/.nzbget'])
    for candidate in candidates:
        text = read_text(candidate)
        if text is None:
            continue
        paths, server_values, categories = {}, {}, {}
        for line in text.splitlines():
            key, sep, value = line.strip().partition('=')
            if not sep or key.startswith('#'):
                continue
            remember(key, value)
            if key in {'MainDir', 'DestDir', 'InterDir', 'TempDir', 'NzbDir', 'QueueDir', 'ScriptDir'}:
                paths[key] = value
            server = re.fullmatch(r'Server(\d+)\.(Host|Port|Encryption|Active|Connections|Level|Name)', key)
            category = re.fullmatch(r'Category(\d+)\.(Name|DestDir|Unpack)', key)
            if server:
                server_values.setdefault(server[1], {})[server[2]] = value
            elif category:
                categories.setdefault(category[1], {})[category[2]] = value
        main = paths.get('MainDir', '')
        paths = {key: path_value(value.replace('${MainDir}', main)) for key, value in paths.items()}
        for category in categories.values():
            if category.get('DestDir'):
                category['DestDir'] = path_value(category['DestDir'].replace('${MainDir}', main))
        return {'config_file': candidate, 'paths': paths, 'servers': list(server_values.values()), 'categories': list(categories.values())}
    return {'config_not_found': True}


def docker_inventory():
    if not shutil.which('docker'):
        return []
    text = run(['docker', 'ps', '-a', '--format', '{{.ID}}|{{.Names}}|{{.Status}}'], timeout=4)
    if text is None:
        return [{'unavailable': True}]
    output = []
    for line in text.splitlines()[:8]:
        parts = line.split('|', 2)
        if len(parts) != 3:
            continue
        cid, name, status = parts
        mounts = json_value(run(['docker', 'inspect', '--format', '{{json .Mounts}}', cid], timeout=3), [])
        output.append({'name': name, 'status': status, 'mounts': [
            {'source': path_value(m.get('Source')), 'destination': m.get('Destination'), 'rw': m.get('RW'), 'type': m.get('Type')}
            for m in mounts if isinstance(m, dict)]})
    return output


def inspect(role):
    expected = {'aurral': ['aurral.service'], 'lidarr': ['lidarr.service', 'Lidarr.service'], 'prowlarr': ['prowlarr.service', 'Prowlarr.service'],
                'sabnzbd': ['sabnzbd.service', 'sabnzbdplus.service'], 'nzbget': ['nzbget.service'],
                'rdtclient': ['rdtclient.service', 'rdt-client.service'], 'qbittorrent': ['qbittorrent.service', 'qbittorrent-nox.service'],
                'slskd': ['slskd.service']}
    services = {}; selected_pid = None; selected_args = []
    units = list(expected.get(role, []))
    listed = run(['systemctl', 'list-units', '--all', '--type=service', '--no-pager', '--no-legend', '--plain']) or ''
    patterns = {'qbittorrent': 'qbittorrent', 'rdtclient': 'rdt', 'sabnzbd': 'sabnzbd', 'lidarr': 'lidarr',
                'prowlarr': 'prowlarr', 'aurral': 'aurral', 'slskd': 'slskd', 'nzbget': 'nzbget'}
    for line in listed.splitlines():
        unit = line.split()[0] if line.split() else ''
        if unit.endswith('.service') and patterns.get(role, 'UNMATCHED') in unit.lower() and unit not in units:
            units.append(unit)
    for unit in units[:8]:
        status, pid, args = service(unit)
        if status.get('LoadState') == 'not-found':
            continue
        services[unit] = status
        if pid or not selected_args:
            selected_pid, selected_args = pid, args
    output = {'read_only': True, 'role': role, 'services': services}
    raw_mounts = json_value(run(['findmnt', '--json', '--output', 'TARGET,SOURCE,FSTYPE,OPTIONS']), {}) or {}
    output['mounts'] = flatten_mounts(raw_mounts.get('filesystems'))
    for mount in output['mounts']:
        if mount['target'] not in {'/'} and len(PATHS) < 40:
            path_value(mount['target'])
    output['addresses'] = []
    for interface in json_value(run(['ip', '-j', 'address']), []) or []:
        if interface.get('ifname') != 'lo':
            output['addresses'].append({'interface': interface.get('ifname'), 'addresses': [
                item.get('local') for item in interface.get('addr_info', []) if item.get('scope') == 'global']})
    output['routes'] = [{key: route.get(key) for key in ['dst', 'gateway', 'dev', 'prefsrc']} for route in (json_value(run(['ip', '-j', 'route']), []) or [])[:40]]
    listens = run(['ss', '-H', '-lnt']) or ''
    output['tcp_listeners'] = [line.split()[3] for line in listens.splitlines() if len(line.split()) > 3][:100]
    if role in {'lidarr', 'prowlarr'}:
        output['application'] = arr_inventory(role, selected_args)
    elif role == 'aurral':
        output['application'] = aurral_inventory(selected_pid)
    elif role == 'sabnzbd':
        output['application'] = sab_inventory(selected_args)
    elif role == 'qbittorrent':
        output['application'] = qb_inventory(selected_args)
    elif role == 'rdtclient':
        output['application'] = rdt_inventory(selected_args)
    elif role == 'slskd':
        output['application'] = slskd_inventory(selected_pid, selected_args)
    elif role == 'nzbget':
        output['application'] = nzbget_inventory(selected_args)
    output['docker'] = docker_inventory()
    for path in ['/downloads', '/music', '/data']:
        PATHS.add(path)
    if len(PATHS) > 80:
        WARNINGS.append('Directory checks capped at 80; no recursive media scan performed')
    output['paths'] = [path_stat(path) for path in sorted(PATHS)[:80]]
    if output.get('application', {}).get('config_not_found') or output.get('application', {}).get('settings_unavailable'):
        WARNINGS.append('Application configuration was not found in checked locations; inspect service/Docker mount records for a custom path')
    output['warnings'] = WARNINGS
    return scrub(output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--role', required=True)
    args = parser.parse_args()
    try:
        result = inspect(args.role)
    except Exception as error:
        # Never export exception text, which can include credentials/URLs.
        result = {'read_only': True, 'role': args.role, 'probe_failed': type(error).__name__}
    print(json.dumps(scrub(result), separators=(',', ':')))
