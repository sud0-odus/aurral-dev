# N100S music-stack inventory

Run n100s-music-inventory.py as root on the Proxmox host. It is standalone
Python 3 and embeds its container probe. No package installation is required.
The separate inventory.py/container-probe.py files provide readable source.

## Scope

- All local CTs: configured/current Proxmox root disks, bind mounts, UID mappings,
  CPU/RAM/swap, network interfaces/VLANs and state. Stopped CTs stay stopped.
- Application probes in CT102 SABnzbd, CT103 Lidarr, CT104 NZBGet, CT106
  RDT-Client, CT107 qBittorrent, CT109 Aurral, CT111 Prowlarr and CT117 slskd.
- Host root-disk/LVM usage and actual mounts, including remote NFS/CIFS sources.
- Inside target CTs: actual filesystem mounts, addresses/routes/listener ports,
  service identities, known config locations and Docker mount metadata.
- Selected download/library/staging/category paths, provider connection settings,
  existing-file reuse mode, enabled integrations, remote path mappings,
  Lidarr root folders/client definitions and Prowlarr application/indexer setup.
- Container-to-host path translation, same-host-directory aliases, runtime
  device/inode directory aliases and SAB-to-Lidarr category mapping comparison.

Configuration data is private to the generated report. API keys, passwords,
provider tokens, full environments, raw logs/configs and tracker URLs are not
exported. Credential presence/encryption flags are exported, not credentials.
Aurral's encryption key is not read and encrypted credentials are not decrypted.
URLs in exported connection fields are reduced to scheme, host and port.

## Safety and limits

The tool reads configuration and directory metadata. It makes only GET calls
to the local Lidarr/Prowlarr APIs, with four-second timeouts, no redirects and
2 MiB response caps. It does not invoke external provider/indexer tests.
It imports no application code and opens SQLite databases in read-only mode
with query_only enabled. It never starts/stops/reconfigures a service or CT,
mounts storage, changes permissions, moves/deletes music or launches searches,
downloads, imports, media scans, file hashing or profiling.

At most two container probes run concurrently. Each CT probe is limited to
110 seconds; host commands and network mount metadata checks have individual
timeouts. Findings mark potential configuration problems, not proven duplicate
files. A same-path match does not certify application-user write permissions.
No recursive walk of media folders is performed.

Known service/config paths and simple single-line environment values are
supported. Custom wrappers, nested Docker config locations or unusual config
formats can remain unknown and are reported as gaps. API and path failures,
stopped CTs and missing Python are reported. Directory checks use the probe's
identity, not impersonation of every app user. Configured/current mount records
and actual mount records are retained for comparison.

## Output

A unique mode-0700 directory is created under /root/n100s-music-inventory-*.
It contains a credential-redacted .json.gz report and README.md summary, both
private. Internal IPs, NAS paths, directory names and profile names remain so
paths can be diagnosed. Review before sharing outside this support session.
No production reports, configuration or credentials are published with the tool.

Run in the foreground and leave the terminal open until its final report path
appears. Download the .json.gz report from Proxmox via SCP and upload it in chat.

## Validation

31 synthetic checks pass across standalone and modular runners. Coverage
includes configuration credential allowlists, URL/mount credential stripping,
read-only databases and unchanged fixture files, encrypted Aurral credentials,
SAB/NZBGet/qBittorrent/RDT/slskd path parsing, API GET-only operation, response
caps, error redaction, stale handles, longest-prefix remote mappings,
wrong/double mappings, directory aliases, physical root overlap, stopped-CT
handling and private report permissions. No live access to N100S was made
from the cloud workspace.
