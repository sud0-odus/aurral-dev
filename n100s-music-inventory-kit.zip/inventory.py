#!/usr/bin/env python3
"""Run as root on N100S. Inventory configuration; never change app/service/storage settings."""
import concurrent.futures
import datetime
import gzip
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import posixpath
import re
import subprocess
import sys
import tempfile
import time
import urllib.parse

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('probe_helpers', ROOT / 'container-probe.py')
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)
ROLES = {'102': 'sabnzbd', '103': 'lidarr', '104': 'nzbget', '106': 'rdtclient',
         '107': 'qbittorrent', '109': 'aurral', '111': 'prowlarr', '117': 'slskd'}


def command(args, timeout=12):
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return result.stdout if result.returncode == 0 else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def config_fields(text):
    result = {}
    allowed = {'hostname', 'cores', 'memory', 'swap', 'rootfs', 'unprivileged', 'features', 'onboot', 'hookscript', 'lxc.idmap'}
    for line in (text or '').splitlines():
        key, sep, value = line.partition(':')
        if not sep or not (key in allowed or re.fullmatch(r'(mp|net)\d+', key)):
            continue
        if key in result:
            result[key] = [result[key], value.strip()] if not isinstance(result[key], list) else result[key] + [value.strip()]
        else:
            result[key] = value.strip()
    return result


def bind_mounts(config):
    output = []
    for key, text in config.items():
        if not re.fullmatch(r'mp\d+', key) or not isinstance(text, str):
            continue
        pieces = text.split(',')
        opts = dict(part.split('=', 1) for part in pieces[1:] if '=' in part)
        if pieces[0].startswith('/') and opts.get('mp', '').startswith('/'):
            output.append({'slot': key, 'host_path': posixpath.normpath(pieces[0]),
                           'ct_path': posixpath.normpath(opts['mp']), 'read_only': opts.get('ro') == '1'})
    return output


def within(root, candidate):
    if not isinstance(root, str) or not isinstance(candidate, str) or not root.startswith('/') or not candidate.startswith('/'):
        return False
    root = posixpath.normpath(root)
    candidate = posixpath.normpath(candidate)
    return candidate == root or candidate.startswith(root.rstrip('/') + '/')


def translate(path, mounts):
    if not isinstance(path, str) or not path.startswith('/'):
        return None
    eligible = [m for m in mounts if within(m['ct_path'], path)]
    if not eligible:
        return None
    winner = max(eligible, key=lambda m: len(m['ct_path']))
    return posixpath.normpath(posixpath.join(winner['host_path'], posixpath.relpath(path, winner['ct_path'])))


def apply_remote(path, host, mappings):
    matches = [m for m in mappings if isinstance(m, dict) and within(m.get('remotePath'), path)
               and hostname(m.get('host')) == hostname(host) and isinstance(m.get('localPath'), str)]
    if not matches:
        return path, False
    m = max(matches, key=lambda item: len(item['remotePath']))
    return posixpath.normpath(posixpath.join(m['localPath'], posixpath.relpath(path, m['remotePath']))), True


def hostname(value):
    if not value or not isinstance(value, str):
        return None
    try:
        return urllib.parse.urlsplit(value if '://' in str(value) else 'http://' + str(value)).hostname
    except ValueError:
        return None


def host_path_check(path):
    # Directory metadata only. timeout limits waiting on stale network mounts.
    raw = command(['timeout', '4', 'stat', '-L', '-c', '%F|%d|%i|%u|%g|%a', '--', path], timeout=5)
    if raw is None:
        return {'accessible': False, 'reason': 'stat failed or timed out; may be missing, inaccessible, or stale'}
    fields = raw.strip().split('|')
    if len(fields) != 6:
        return {'accessible': None}
    return {'accessible': True, 'type': fields[0], 'device': fields[1], 'inode': fields[2],
            'uid': fields[3], 'gid': fields[4], 'mode': fields[5]}


def ct_config(ctid):
    config = command(['pct', 'config', ctid])
    active = command(['pct', 'config', ctid, '--current', '1'])
    return {'configured': config_fields(config), 'current': config_fields(active) if active else None,
            'config_read_failed': config is None}


def inspect_ct(ctid, status, name, source):
    item = {'name': name, 'status': status, **ct_config(ctid)}
    item['bind_mounts'] = bind_mounts(item.get('current') or item['configured'])
    if ctid in ROLES:
        if status != 'running':
            item['probe'] = {'not_run': 'container is not running; it was left stopped'}
        else:
            print('Reading CT%s (%s)...' % (ctid, ROLES[ctid]), file=sys.stderr, flush=True)
            output = command(['pct', 'exec', ctid, '--', 'python3', '-c', source, '--role', ROLES[ctid]], timeout=110)
            item['probe'] = helpers.json_value(output, {'probe_unavailable': 'Python probe failed or exceeded its time limit; no raw output exported'})
    return ctid, item


def analyze(containers):
    findings = []; aliases = []; paths = []; runtime_groups = []
    binds = [(ctid, mount) for ctid, item in containers.items() for mount in item.get('bind_mounts', [])]
    for (aid, a), (bid, b) in itertools.combinations(binds, 2):
        overlap = b['host_path'] if within(a['host_path'], b['host_path']) else a['host_path'] if within(b['host_path'], a['host_path']) else None
        if overlap is None:
            continue
        apath = posixpath.normpath(posixpath.join(a['ct_path'], posixpath.relpath(overlap, a['host_path'])))
        bpath = posixpath.normpath(posixpath.join(b['ct_path'], posixpath.relpath(overlap, b['host_path'])))
        aliases.append({'host_path': overlap, 'a': {'ct': aid, 'path': apath}, 'b': {'ct': bid, 'path': bpath},
                        'same_container_alias': aid == bid and apath != bpath})
        if aid == bid and apath != bpath:
            findings.append({'kind': 'same_storage_multiple_paths', 'ct': aid,
                'paths': [apath, bpath], 'host_path': overlap,
                'meaning': 'Same host directory exposed at different paths; scanner exclusions need checking. This alone does not prove duplicate files.'})
    for ctid, item in containers.items():
        if item.get('configured') != item.get('current') and item.get('current'):
            findings.append({'kind': 'configured_current_differ', 'ct': ctid, 'meaning': 'Some desired configuration differs from the current configuration; compare both records.'})
        probe = item.get('probe') or {}
        if probe.get('probe_failed') or probe.get('probe_unavailable'):
            findings.append({'kind': 'probe_incomplete', 'ct': ctid})
        physical = {}
        for record in probe.get('paths', []):
            if record.get('exists') and record.get('is_directory'):
                physical.setdefault((record.get('device'), record.get('inode')), []).append(record['path'])
        runtime_groups.extend({'ct': ctid, 'paths': values, 'device': identity[0], 'inode': identity[1]}
                              for identity, values in physical.items() if len(values) > 1)
        for record in probe.get('paths', []):
            canonical = translate(record['path'], item['bind_mounts'])
            paths.append({'ct': ctid, 'path': record['path'], 'host_path_from_bind_config': canonical,
                          'exists': record.get('exists'), 'read_only_bind': next((m['read_only'] for m in sorted(item['bind_mounts'], key=lambda m: -len(m['ct_path'])) if within(m['ct_path'], record['path'])), None)})
            if record.get('stat_error_errno') == 116:
                findings.append({'kind': 'stale_file_handle', 'ct': ctid, 'path': record['path']})
    aurral = (containers.get('109', {}).get('probe') or {}).get('application') or {}
    if (aurral.get('worker') or {}).get('existing_file_mode') == 'download':
        findings.append({'kind': 'aurral_always_download_mode', 'ct': '109', 'meaning': 'Existing-library reuse is disabled; repeated acquisitions can create additional copies.'})
    root = aurral.get('download_folder') or {}
    local = translate(root.get('path'), containers.get('109', {}).get('bind_mounts', []))
    lidarr = (containers.get('103', {}).get('probe') or {}).get('application') or {}
    for folder in lidarr.get('rootfolder', []) if isinstance(lidarr.get('rootfolder'), list) else []:
        lidarr_host = translate(folder.get('path'), containers.get('103', {}).get('bind_mounts', []))
        if local and lidarr_host and (within(lidarr_host, local) or within(local, lidarr_host)):
            findings.append({'kind': 'aurral_lidarr_physical_root_overlap', 'aurral_path': root.get('path'),
                'aurral_host_path': local, 'lidarr_path': folder.get('path'), 'lidarr_host_path': lidarr_host,
                'aurral_path_source': root.get('source'),
                'meaning': 'App roots physically overlap. This requires consistent path naming/exclusions; it is not evidence of an extra physical copy.'})
    return {'findings': findings, 'shared_bind_paths': aliases[:150], 'runtime_same_directory_groups': runtime_groups[:100], 'path_translation_table': paths[:500],
            'shared_bind_paths_truncated': len(aliases) > 150, 'path_translation_table_truncated': len(paths) > 500,
            'sab_lidarr_checks': sab_mapping_checks(containers)}


def sab_mapping_checks(containers):
    lidarr_ct = containers.get('103', {}); sab_ct = containers.get('102', {})
    lidarr = (lidarr_ct.get('probe') or {}).get('application') or {}
    sab = (sab_ct.get('probe') or {}).get('application') or {}
    mappings = lidarr.get('remotepathmapping')
    clients = lidarr.get('downloadclient')
    if not isinstance(mappings, list) or not isinstance(clients, list):
        return [{'not_verified': 'Lidarr API inventory unavailable'}]
    results = []
    for client in clients:
        if str(client.get('implementation', '')).lower() != 'sabnzbd':
            continue
        fields = client.get('fields') or {}; host = fields.get('host')
        categories = [fields.get(k) for k in ['category', 'musicCategory'] if fields.get(k)]
        for category in sab.get('categories', []):
            if categories and category['name'] not in categories:
                continue
            remote = category.get('resolved_folder_if_absolute_base')
            if not remote or not remote.startswith('/'):
                continue
            mapped, applied = apply_remote(remote, host, mappings)
            source = translate(remote, sab_ct.get('bind_mounts', []))
            dest = translate(mapped, lidarr_ct.get('bind_mounts', []))
            results.append({'client': client.get('name'), 'host': host, 'category': category['name'],
                'sab_path': remote, 'lidarr_path_after_mapping': mapped, 'mapping_applied': applied,
                'sab_host_path': source, 'lidarr_host_path': dest,
                'same_host_path': source == dest if source and dest else None,
                'note': 'Configuration comparison only; no import or write-permission test performed.'})
    return results or [{'not_verified': 'No matching SAB client/category configuration found'}]


def markdown(report, json_path):
    lines = ['# N100S music-stack inventory', '', 'UTC capture: ' + report['captured_at_utc'], '',
             'Read-only configuration inventory. No service changes, acquisitions, scans, moves or deletions.', '',
             '## Containers', '', '| CT | Name | State | Detailed application probe |', '|---|---|---|---|']
    for ctid, item in sorted(report['containers'].items(), key=lambda p: int(p[0])):
        probe = item.get('probe') or {}
        state = 'not requested' if ctid not in ROLES else 'incomplete' if probe.get('probe_failed') or probe.get('probe_unavailable') or probe.get('not_run') else 'collected; see JSON for per-app gaps'
        lines.append('| %s | %s | %s | %s |' % (ctid, item['name'], item['status'], state))
    lines += ['', '## Findings', '']
    for finding in report['analysis']['findings']:
        lines.append('- ' + json.dumps(finding, sort_keys=True))
    lines += ['', '## SABnzbd to Lidarr path checks', '']
    for check in report['analysis']['sab_lidarr_checks']:
        lines.append('- ' + json.dumps(check, sort_keys=True))
    lines += ['', '## Scope and limits', '',
              '- Config/mount inventory covers all listed local CTs. App details cover CT102, 103, 104, 106, 107, 109, 111 and 117.',
              '- Credentials and raw configuration/logs are excluded. Internal IPs, directory names, profile names and mounts are retained.',
              '- No recursive media walk, file hashing, duplicate deletion, new baseline or profiling run.',
              '- A matching host path does not prove app-user write access. Directory checks run as the pct-exec probe user.',
              '- Known config locations, explicit CLI config paths and relevant environment values are checked. Custom wrappers or config paths can remain unknown.',
              '- Missing Python, stopped CTs, API/TLS failures and caps are recorded. This inventory does not certify that no duplicates exist.',
              '- Container directory checks can time out on stale network mounts; per-probe timeout is recorded as incomplete.',
              '- No routes/firewall/VPN settings are changed. No external indexer/provider tests are initiated.',
              '', 'Full redacted report: ' + str(json_path), '']
    return '\n'.join(lines)


def main():
    if os.geteuid() != 0:
        raise RuntimeError('Run as root on the Proxmox host.')
    started = time.monotonic()
    raw = command(['pct', 'list'])
    if raw is None:
        raise RuntimeError('Could not list containers with pct.')
    rows = []
    for line in raw.splitlines():
        parts = line.split()
        if len(parts) >= 3 and parts[0].isdigit():
            rows.append((parts[0], parts[1], parts[-1]))
    if not rows:
        raise RuntimeError('No local containers found.')
    source = (ROOT / 'container-probe.py').read_text()
    report = {'inventory_version': '1.0', 'read_only': True,
              'captured_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'host': {}, 'containers': {}}
    report['host']['hostname'] = os.uname().nodename
    report['host']['logical_cpus'] = os.cpu_count()
    report['host']['memory_kib'] = {}
    for line in (helpers.read_text('/proc/meminfo') or '').splitlines():
        key, _, value = line.partition(':')
        if key in {'MemTotal', 'MemAvailable', 'SwapTotal', 'SwapFree'}:
            report['host']['memory_kib'][key] = int(value.split()[0])
    report['host']['local_disk_usage'] = command(['df', '-Pk', '/', '/var/lib/vz'])
    report['host']['lvm'] = helpers.json_value(command(['lvs', '--reportformat', 'json', '--units', 'b', '-o', 'lv_name,lv_size,data_percent,metadata_percent']), {'unavailable': True})
    mounts = helpers.json_value(command(['findmnt', '--json', '--output', 'TARGET,SOURCE,FSTYPE,OPTIONS']), {}) or {}
    report['host']['mounts'] = helpers.flatten_mounts(mounts.get('filesystems'))
    report['host']['storage_status'] = command(['pvesm', 'status'], timeout=15)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(inspect_ct, ctid, state, name, source) for ctid, state, name in rows]
        for future in concurrent.futures.as_completed(futures):
            ctid, item = future.result()
            report['containers'][ctid] = item
    report['host']['bind_source_checks'] = {}
    sources = sorted({m['host_path'] for item in report['containers'].values() for m in item['bind_mounts']})
    for path in sources[:80]:
        report['host']['bind_source_checks'][path] = host_path_check(path)
    report['host']['bind_source_checks_truncated'] = len(sources) > 80
    report['analysis'] = analyze(report['containers'])
    for path, state in report['host']['bind_source_checks'].items():
        if state.get('accessible') is False:
            report['analysis']['findings'].append({'kind': 'host_bind_source_unavailable', 'host_path': path})
    report['duration_seconds'] = round(time.monotonic() - started, 1)
    os.umask(0o077)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S')
    directory = Path(tempfile.mkdtemp(prefix='n100s-music-inventory-' + stamp + '-', dir='/root'))
    target = directory / ('n100s-music-inventory-' + stamp + '.json.gz')
    with gzip.open(target, 'wt', encoding='utf-8') as output:
        json.dump(report, output, indent=2)
    summary = directory / 'README.md'
    summary.write_text(markdown(report, target))
    print('\nInventory complete in %.1f seconds.' % report['duration_seconds'])
    print('Private redacted report: ' + str(target))
    print('Readable summary: ' + str(summary))
    print('Containers: %d; detailed app targets: %d.' % (len(rows), sum(ctid in ROLES for ctid, _, _ in rows)))
    print('Findings: %d. These are configuration observations, not proof of duplicate files.' % len(report['analysis']['findings']))
    print('No production configuration was changed.')


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('Inventory stopped: ' + type(error).__name__ + '. No configuration changes made.', file=sys.stderr)
        sys.exit(1)
