import contextlib
import gzip
import importlib.util
import io
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).parent

def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

class ContainerTests(unittest.TestCase):
    def setUp(self):
        self.m = load('container-probe')

    def test_endpoints_remove_credentials_query_and_path(self):
        self.assertEqual(self.m.origin('https://username:SECRET_PASSWORD@server:1234/path?apikey=SECRET_QUERY'), 'https://server:1234')
        self.assertEqual(self.m.origin('192.168.1.98'), 'http://192.168.1.98')
        self.assertIsNone(self.m.origin(None))

    def test_mounts_keep_relevant_options_and_strip_credentials(self):
        result = self.m.flatten_mounts([{'target': '/music', 'source': '//user:SECRET@server/share', 'fstype': 'cifs',
            'options': 'rw,vers=3,username=user,password=SECRET,credentials=/private,key=SECRET,uid=1000'}])
        self.assertNotIn('SECRET', json.dumps(result))
        self.assertNotIn('/private', json.dumps(result))
        self.assertEqual(result[0]['options'], 'rw,vers=3,uid=1000')

    def test_sab_folders_categories_and_provider_fields_redacted(self):
        text = '''[misc]
download_dir = /downloads/incomplete
complete_dir = /downloads/complete
api_key = SECRET_SAB_KEY
host = 0.0.0.0
port = 7777
[servers]
[[news.newsdemon.com]]
host = news.newsdemon.com
username = PRIVATE_USERNAME
password = SECRET_PASSWORD
port = 563
ssl = 1
enable = 1
connections = 8
[categories]
[[music]]
dir = music
[[other]]
dir = /other/path
'''
        with patch.object(self.m, 'read_text', return_value=text):
            result = self.m.sab_inventory([])
        self.assertEqual(result['folders']['complete_dir'], '/downloads/complete')
        self.assertEqual(result['categories'][0]['resolved_folder_if_absolute_base'], '/downloads/complete/music')
        self.assertEqual(result['categories'][1]['resolved_folder_if_absolute_base'], '/other/path')
        self.assertEqual(result['servers'][0]['host'], 'news.newsdemon.com')
        for private in ['SECRET', 'PRIVATE_USERNAME']:
            self.assertNotIn(private, json.dumps(result))
        self.assertEqual(self.m.scrub('a SECRET_PASSWORD b'), 'a [redacted] b')

    def test_qb_paths_do_not_export_passwords_or_tracker_tokens(self):
        text = r'''[Preferences]
Downloads\SavePath=/downloads/torrents
Downloads\TempPath=/downloads/incomplete
WebUI\Port=8080
WebUI\Password_PBKDF2=SECRET_QB_HASH
[BitTorrent]
Session\DefaultSavePath=/downloads/torrents
'''
        def read(path):
            return text if str(path).endswith('qBittorrent.conf') else None
        with patch.object(self.m, 'read_text', side_effect=read):
            result = self.m.qb_inventory([])
        self.assertIn('/downloads/torrents', json.dumps(result))
        self.assertNotIn('SECRET', json.dumps(result))

    def test_nzbget_expands_main_dir_without_credentials(self):
        text = '''MainDir=/downloads
DestDir=${MainDir}/complete
InterDir=${MainDir}/incomplete
Server1.Host=news.test
Server1.Password=SECRET_NZB_PASSWORD
Server1.Port=563
Category1.Name=music
Category1.DestDir=${MainDir}/music
'''
        with patch.object(self.m, 'read_text', return_value=text):
            result = self.m.nzbget_inventory([])
        self.assertEqual(result['paths']['DestDir'], '/downloads/complete')
        self.assertEqual(result['categories'][0]['DestDir'], '/downloads/music')
        self.assertNotIn('SECRET', json.dumps(result))

    def test_rdt_reads_only_allowlisted_setting_values(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / 'rdt.db'
            with sqlite3.connect(db) as con:
                con.execute('CREATE TABLE Settings(SettingId TEXT, Value TEXT)')
                con.executemany('INSERT INTO Settings VALUES (?, ?)', [
                    ('DownloadClient:DownloadPath', '/downloads'), ('DownloadClient:MappedPath', '/downloads'),
                    ('Provider:ApiKey', 'SECRET_RDT_KEY'), ('Provider:Provider', 'RealDebrid')])
            before = db.read_bytes()
            original = self.m.readonly_db
            with patch.object(self.m.Path, 'is_file', return_value=True), \
                 patch.object(self.m, 'readonly_db', side_effect=lambda _: original(db)):
                result = self.m.rdt_inventory([])
            self.assertEqual(result['fields']['DownloadClient:DownloadPath'], '/downloads')
            self.assertEqual(result['fields']['Provider:Provider'], 'RealDebrid')
            self.assertNotIn('SECRET', json.dumps(result))
            self.assertEqual(db.read_bytes(), before)

    def test_aurral_read_only_settings_and_encrypted_credential_presence(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / 'aurral.db'
            with sqlite3.connect(db) as con:
                con.execute('CREATE TABLE settings(key TEXT,value TEXT)')
                con.executemany('INSERT INTO settings VALUES (?,?)', [
                    ('downloadFolderPath', '/downloads/aurral'),
                    ('playlistWorker', json.dumps({'concurrency': 2, 'existingFileMode': 'reuse'})),
                    ('integrations', json.dumps({'lidarr': {'enabled': True, 'url': 'http://lidarr:8686',
                     'apiKey': 'AURRAL_ENC:SECRET_ENCRYPTED', 'rootFolderPaths': ['/music']}})),
                    ('pathMappings', json.dumps([{'source': 'sabnzbd', 'remote': '/downloads', 'local': '/downloads/sabnzbd'}])),
                    ('_encryptionKey', 'SECRET_MASTER_KEY')])
            before = db.read_bytes()
            original = self.m.readonly_db
            with patch.object(self.m.Path, 'is_file', return_value=True), \
                 patch.object(self.m, 'readonly_db', side_effect=lambda _: original(db)), \
                 patch.object(self.m, 'env_file', return_value={}), patch.object(self.m, 'environment', return_value={}):
                result = self.m.aurral_inventory(None)
            self.assertEqual(result['download_folder']['path'], '/downloads/aurral')
            self.assertEqual(result['worker']['existing_file_mode'], 'reuse')
            self.assertTrue(result['integrations']['lidarr']['credential_encrypted'])
            self.assertFalse(result['integrations']['lidarr']['credential_validity_tested'])
            self.assertNotIn('SECRET', json.dumps(result))
            self.assertEqual(db.read_bytes(), before)

    def test_missing_database_is_not_created(self):
        with tempfile.TemporaryDirectory() as tmp:
            missing = Path(tmp) / 'missing.db'
            with self.assertRaises(sqlite3.OperationalError):
                self.m.readonly_db(missing)
            self.assertFalse(missing.exists())

    def test_slskd_reports_only_directory_settings(self):
        text = '''directories:
  downloads: /downloads/slskd
  incomplete: /downloads/incomplete
web:
  api_keys:
    fakekey: SECRET_SLSKD
'''
        with patch.object(self.m, 'environment', return_value={}), patch.object(self.m, 'read_text', return_value=text):
            result = self.m.slskd_inventory(None, [])
        self.assertEqual(result['directories']['downloads'], '/downloads/slskd')
        self.assertNotIn('SECRET', json.dumps(result))

    def test_http_requests_get_only_redaction_limits_redirects(self):
        calls = []
        payloads = {'/api/v1/system/status': {'version': '3.1', 'secret': 'SECRET_BODY'},
            '/api/v1/downloadclient': [{'name': 'RDT', 'implementation': 'QBittorrent', 'fields': [
                {'name': 'host', 'value': '192.168.30.20'}, {'name': 'password', 'value': 'SECRET_LOGIN'}]}],
            '/api/v1/indexer': [], '/api/v1/health': [{'source': 'TestHealth', 'type': 'warning', 'message': 'SECRET_HEALTH'}],
            '/api/v1/rootfolder': [{'path': '/music', 'freeSpace': 123}], '/api/v1/remotepathmapping': [],
            '/api/v1/qualityprofile': [], '/api/v1/metadataprofile': [],
            '/api/v1/config/downloadclient': {}, '/api/v1/config/mediamanagement': {}}
        class Response:
            def __init__(self, payload): self.payload = payload
            def __enter__(self): return self
            def __exit__(self, *args): pass
            def read(self, count): return json.dumps(self.payload).encode()
        class Opener:
            def open(self, request, timeout):
                if request.get_method() != 'GET': raise AssertionError('mutation')
                calls.append(request.full_url)
                path = request.full_url.split(':8686')[1]
                return Response(payloads[path])
        with patch.object(self.m, 'arr_config', return_value=({}, 'http://127.0.0.1:8686', 'SECRET_API')), \
             patch.object(self.m.urllib.request, 'build_opener', return_value=Opener()):
            result = self.m.arr_inventory('lidarr', [])
        self.assertEqual(len(calls), 10)
        self.assertNotIn('SECRET', json.dumps(result))
        self.assertIsNone(self.m.NoRedirect().redirect_request(None))

    def test_http_failure_does_not_export_exception_text(self):
        class Opener:
            def open(self, *args, **kwargs): raise OSError('SECRET_IN_EXCEPTION')
        with patch.object(self.m.urllib.request, 'build_opener', return_value=Opener()):
            result, error = self.m.api_get('http://server', 'SECRET_KEY', '/api/v1/status')
        self.assertIsNone(result)
        self.assertNotIn('SECRET', error)

    def test_stale_directory_is_recorded_without_exception_text(self):
        with patch.object(self.m.os, 'stat', side_effect=OSError(116, 'SECRET_STALE_CONTEXT')):
            result = self.m.path_stat('/downloads')
        self.assertEqual(result['stat_error_errno'], 116)
        self.assertIsNone(result['exists'])
        self.assertNotIn('SECRET', json.dumps(result))

    def test_api_response_cap(self):
        class Response:
            def __enter__(self): return self
            def __exit__(self, *args): pass
            def read(self, count): return b'x' * count
        class Opener:
            def open(self, *args, **kwargs): return Response()
        with patch.object(self.m.urllib.request, 'build_opener', return_value=Opener()):
            result, error = self.m.api_get('http://server', 'SECRET_KEY', '/api/v1/status')
        self.assertIsNone(result)
        self.assertIn('cap', error)


class HostTests(unittest.TestCase):
    def setUp(self):
        self.m = load('inventory')

    def test_config_allowlist_excludes_description_keys_and_environment(self):
        result = self.m.config_fields('hostname: aurral\nmp0: /host/music,mp=/music,ro=1\nnet0: name=eth0,tag=30\n'
             'description: SECRET\nssh-public-keys: SECRET\nlxc.environment: SECRET\nlxc.idmap: u 0 100000 65536\n')
        self.assertNotIn('SECRET', json.dumps(result))
        self.assertIn('lxc.idmap', result)

    def test_longest_bind_prefix_and_component_boundary(self):
        mounts = [{'ct_path': '/downloads', 'host_path': '/host/shared'},
                  {'ct_path': '/downloads/aurral', 'host_path': '/host/music/Aurral'}]
        self.assertEqual(self.m.translate('/downloads/aurral/Artist/Album', mounts), '/host/music/Aurral/Artist/Album')
        self.assertEqual(self.m.translate('/downloads/sabnzbd/a', mounts), '/host/shared/sabnzbd/a')
        self.assertIsNone(self.m.translate('/downloads-old/a', mounts))

    def test_remote_mapping_longest_prefix_host_and_boundary(self):
        mappings = [{'host': 'http://192.168.1.98', 'remotePath': '/downloads', 'localPath': '/downloads/sabnzbd'},
                    {'host': 'http://192.168.1.98', 'remotePath': '/downloads/special', 'localPath': '/special'}]
        self.assertEqual(self.m.apply_remote('/downloads/complete/music', '192.168.1.98', mappings),
                         ('/downloads/sabnzbd/complete/music', True))
        self.assertEqual(self.m.apply_remote('/downloads/special/a', '192.168.1.98', mappings), ('/special/a', True))
        self.assertEqual(self.m.apply_remote('/downloads-old/a', '192.168.1.98', mappings), ('/downloads-old/a', False))
        self.assertEqual(self.m.apply_remote('/downloads/a', 'other', mappings), ('/downloads/a', False))

    def fixture(self):
        return {
          '102': {'bind_mounts': [{'host_path': '/host/Music/Downloads/sabnzbd', 'ct_path': '/downloads', 'read_only': False}],
            'probe': {'application': {'categories': [{'name': 'music', 'resolved_folder_if_absolute_base': '/downloads/complete/music'}]}}},
          '103': {'bind_mounts': [{'host_path': '/host/Music/Downloads', 'ct_path': '/downloads', 'read_only': False},
                                 {'host_path': '/host/Music', 'ct_path': '/music', 'read_only': False}],
            'probe': {'application': {'rootfolder': [{'path': '/music'}], 'downloadclient': [
                {'name': 'SAB', 'implementation': 'Sabnzbd', 'fields': {'host': 'http://192.168.1.98', 'category': 'music'}}],
                'remotepathmapping': [{'host': 'http://192.168.1.98', 'remotePath': '/downloads', 'localPath': '/downloads/sabnzbd'}]}}},
          '109': {'bind_mounts': [{'host_path': '/host/Music', 'ct_path': '/music', 'read_only': True},
                                 {'host_path': '/host/Music/Aurral', 'ct_path': '/downloads/aurral', 'read_only': False}],
            'probe': {'application': {'download_folder': {'path': '/downloads/aurral', 'source': 'settings'},
                                      'worker': {'existing_file_mode': 'reuse'}}, 'paths': []}}}

    def test_same_physical_folder_alias_and_root_overlap_detected(self):
        result = self.m.analyze(self.fixture())
        kinds = [f['kind'] for f in result['findings']]
        self.assertIn('same_storage_multiple_paths', kinds)
        self.assertIn('aurral_lidarr_physical_root_overlap', kinds)
        check = result['sab_lidarr_checks'][0]
        self.assertTrue(check['same_host_path'])
        self.assertEqual(check['lidarr_path_after_mapping'], '/downloads/sabnzbd/complete/music')

    def test_wrong_and_double_mappings_detected(self):
        fixture = self.fixture()
        fixture['103']['probe']['application']['remotepathmapping'][0]['localPath'] = '/downloads'
        self.assertFalse(self.m.sab_mapping_checks(fixture)[0]['same_host_path'])
        fixture = self.fixture()
        fixture['102']['probe']['application']['categories'][0]['resolved_folder_if_absolute_base'] = '/downloads/sabnzbd/complete/music'
        check = self.m.sab_mapping_checks(fixture)[0]
        self.assertIn('/sabnzbd/sabnzbd/', check['lidarr_path_after_mapping'])

    def test_runtime_device_inode_confirms_directory_aliases(self):
        fixture = self.fixture()
        fixture['109']['probe']['paths'] = [
            {'path': '/music/Aurral', 'exists': True, 'is_directory': True, 'device': 1, 'inode': 123},
            {'path': '/downloads/aurral', 'exists': True, 'is_directory': True, 'device': 1, 'inode': 123}]
        groups = self.m.analyze(fixture)['runtime_same_directory_groups']
        self.assertEqual(len(groups), 1)
        self.assertEqual(groups[0]['ct'], '109')
        self.assertEqual(len(groups[0]['paths']), 2)

    def test_disabled_reuse_is_flagged(self):
        fixture = self.fixture();fixture['109']['probe']['application']['worker']['existing_file_mode'] = 'download'
        self.assertIn('aurral_always_download_mode', [f['kind'] for f in self.m.analyze(fixture)['findings']])

    def test_stopped_container_is_not_started_or_probed(self):
        calls = []
        def command(args, timeout=12):
            calls.append(args)
            if args[:2] == ['pct', 'config']: return 'hostname: test\n'
            raise AssertionError(args[:2])
        with patch.object(self.m, 'command', side_effect=command):
            _, result = self.m.inspect_ct('109', 'stopped', 'aurral', 'unused source')
        self.assertIn('not_run', result['probe'])
        self.assertEqual(len(calls), 2)

    def test_complete_host_run_writes_private_redacted_reports_only(self):
        calls = []
        def command(args, timeout=12):
            calls.append(args[:4])
            if args[:2] == ['pct', 'list']:
                return 'VMID Status Lock Name\n102 running sabnzbd\n109 running aurral\n119 stopped old-dev\n'
            if args[:2] == ['pct', 'config']:
                return 'hostname: test\nmp0: /host/Music,mp=/music\n'
            if args[:2] == ['pct', 'exec']:
                return '{"read_only":true,"services":{},"application":{},"paths":[]}'
            if args[:2] == ['findmnt', '--json']: return '{"filesystems":[]}'
            if args[0] == 'lvs': return '{"report":[]}'
            if args[0] == 'timeout': return 'directory|1|2|1000|1000|775\n'
            if args[:2] == ['pvesm', 'status']: return 'Name Type Status Total Used Available %\n'
            if args[0] == 'df': return 'Filesystem blocks Used Available Capacity Mounted on\n'
            raise AssertionError(args)
        with tempfile.TemporaryDirectory() as tmp:
            original = tempfile.mkdtemp
            def directory(*args, **kwargs):
                kwargs['dir'] = tmp
                return original(*args, **kwargs)
            original_umask = os.umask(0o077)
            try:
                with patch.object(self.m, 'command', side_effect=command), patch.object(self.m.os, 'geteuid', return_value=0), \
                     patch.object(self.m.tempfile, 'mkdtemp', side_effect=directory), contextlib.redirect_stdout(io.StringIO()):
                    self.m.main()
            finally:
                os.umask(original_umask)
            report_file = next(Path(tmp).glob('*/n100s-music-inventory-*.json.gz'))
            with gzip.open(report_file, 'rt') as stream: report = json.load(stream)
            self.assertEqual(set(report['containers']), {'102','109','119'})
            self.assertEqual(report_file.stat().st_mode & 0o777, 0o600)
            self.assertEqual(report_file.parent.stat().st_mode & 0o777, 0o700)
            self.assertFalse(any(args[:3] == ['pct','exec','119'] for args in calls))
            for args in calls:
                if args[0] == 'pct': self.assertIn(args[1], {'list','config','exec'})

class StandaloneTests(HostTests):
    def setUp(self):
        self.m = load('n100s-music-inventory')

if __name__ == '__main__':
    unittest.main()
