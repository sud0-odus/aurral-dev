import argparse,importlib.util,sqlite3,tempfile,types,shutil
from pathlib import Path
from unittest.mock import patch
root=Path('/workspace/ct109-remove-apple-viewer')
def module(file):
 s=importlib.util.spec_from_file_location('installer',file);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
for variant in ['preview','stream']:
 with tempfile.TemporaryDirectory() as directory:
  base=Path(directory);app=base/'app';app.mkdir();m=module(root/'app/apply-patch.py')
  for f in m.MANIFEST['files']:
   target=app/f['path'];target.parent.mkdir(parents=True,exist_ok=True)
   before=Path('/tmp/apple-viewer-removal-before')/f['path']
   if variant=='preview' and f['path'].endswith('AppleMusicSection.jsx'):before=Path('/tmp/AppleMusicSection-before-stream.jsx')
   target.write_bytes(before.read_bytes())
  old_ui='/workspace/apple-connect-release/ct109/frontend-dist' if variant=='preview' else '/workspace/ct109-apple-stream/ui/frontend-dist'
  shutil.copytree(old_ui,app/'frontend/dist');before_ui=m.tree_digest(app/'frontend/dist')
  db=base/'aurral.db'
  with sqlite3.connect(db) as con:con.execute('CREATE TABLE playlists (id TEXT)');con.execute("INSERT INTO playlists VALUES ('wife imported playlist')")
  args=argparse.Namespace(app_dir=app,db=db,backup_dir=base/'backups',state=base/'state',health_url='http://unused')
  active=True
  def ctl(*commands):
   global active
   if commands[0]=='stop':active=False
   if commands[0]=='start':active=True
   return types.SimpleNamespace(returncode=(0 if active else 3) if commands[0]=='is-active' else 0)
  m.select_input_versions(args)
  with patch.object(m,'systemctl',side_effect=ctl),patch.object(m,'healthy',return_value=True):m.install(args);m.enable(args)
  assert not (app/'frontend/src/pages/Settings/components/AppleMusicSection.jsx').exists()
  assert not (app/'backend/services/appleBrowserClient.js').exists()
  m=module(root/'app/apply-patch.py');m.select_input_versions(args)
  with patch.object(m,'systemctl',side_effect=ctl):m.rollback(args)
  assert m.tree_digest(app/'frontend/dist')==before_ui
  with sqlite3.connect(db) as con:assert con.execute('SELECT * FROM playlists').fetchall()==[('wife imported playlist',)]
  print('PASS: actual removal/enable/fresh-process rollback preserves playlists and restores '+variant+' UI.')
with tempfile.TemporaryDirectory() as directory:
 base=Path(directory);m=module(root/'remove-helper.py')
 paths={name:base/name for name in ['browser','unit','pairing','home']}
 for name in ['browser','pairing','home']:paths[name].mkdir()
 (paths['browser']/'bridge.py').write_bytes(Path('/workspace/ct109-apple-stream/browser/bridge.py').read_bytes())
 paths['unit'].write_bytes(Path('/workspace/apple-connect-release/browser/aurral-apple-browser.service').read_bytes())
 (paths['pairing']/'bridge.key').write_text('private fixture')
 args=argparse.Namespace(paths=paths,state=base/'state',backups=base/'backups')
 active=enabled=True;calls=[]
 def ctl(*commands):
  global active,enabled
  calls.append(commands)
  if commands[0]=='stop':active=False
  if commands[0]=='start':active=True
  if commands[0]=='disable':enabled=False
  if commands[0]=='enable':enabled=True
  return types.SimpleNamespace(returncode=(0 if active else 3) if commands[0]=='is-active' else (0 if enabled else 1) if commands[0]=='is-enabled' else 0)
 with patch.object(m,'ctl',side_effect=ctl),patch.object(m.subprocess,'run',return_value=types.SimpleNamespace(returncode=0)):
  m.remove(args)
  assert not active and not enabled and all(not p.exists() for p in paths.values())
  m.rollback(args)
  assert active and enabled and (paths['pairing']/'bridge.key').read_text()=='private fixture'
  calls.clear();(paths['browser']/'bridge.py').write_text('unknown custom code')
  try:m.check(args);raise AssertionError('must reject unknown helper')
  except RuntimeError:pass
  assert not calls
 print('PASS: helper stop/disable/archive/rollback preserves pairing, and unknown code blocks before service changes.')
