#!/usr/bin/env python3
"""Retire the dedicated Apple viewer service; keep a private rollback backup."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

KIT=Path(__file__).resolve().parent
MANIFEST=json.loads((KIT/'helper-manifest.json').read_text())
SERVICE='aurral-apple-browser.service'

def ctl(*args):return subprocess.run(['systemctl',*args,SERVICE],capture_output=True,timeout=90)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write_state(args,state):
 fd,name=tempfile.mkstemp(prefix='.retire-',dir=args.state.parent)
 try:
  with os.fdopen(fd,'w') as handle:json.dump(state,handle);handle.flush();os.fsync(handle.fileno())
  os.chmod(name,0o600);os.replace(name,args.state)
 finally:
  if os.path.exists(name):os.unlink(name)
def check(args):
 for name,path in args.paths.items():
  if path.is_symlink():raise RuntimeError('Refusing a symlink at the '+name+' location.')
 if args.paths['browser'].exists():
  file=args.paths['browser']/'bridge.py'
  if not file.is_file() or sha(file) not in MANIFEST['browser_hashes']:raise RuntimeError('Browser code differs from the known preview versions. Nothing removed.')
  if not args.paths['unit'].is_file():raise RuntimeError('Expected browser service unit missing. Nothing removed.')
 unit=args.paths['unit']
 if unit.exists() and (not unit.is_file() or sha(unit)!=MANIFEST['unit_sha256']):raise RuntimeError('Browser unit has custom edits. Nothing removed.')
 print('PASS: helper paths match known installed viewer versions; no changes made.')
def remove(args):
 check(args)
 if args.state.exists():raise RuntimeError('Removal marker already exists. Do not repeat this step.')
 args.backups.mkdir(mode=0o700,parents=True,exist_ok=True)
 backup=Path(tempfile.mkdtemp(prefix='retired-apple-viewer-',dir=args.backups));os.chmod(backup,0o700)
 has_unit=args.paths['unit'].exists()
 state={'patch':MANIFEST['patch'],'backup':str(backup),'paths':{k:str(v) for k,v in args.paths.items()},'moved':[],
        'status':'prepared','was_active':False,'was_enabled':False}
 if has_unit:
  state['was_active']=ctl('is-active','--quiet').returncode==0
  state['was_enabled']=ctl('is-enabled','--quiet').returncode==0
 write_state(args,state)
 if has_unit:
  print('Stopping the old Apple viewer (its previous stop limit is 65 seconds)...',flush=True)
  if ctl('stop').returncode or ctl('is-active','--quiet').returncode==0:raise RuntimeError('Apple helper could not be stopped. No runtime files moved.')
  if ctl('disable').returncode:raise RuntimeError('Apple helper could not be disabled. No runtime files moved.')
 for name,path in args.paths.items():
  if path.exists():
   shutil.move(str(path),str(backup/name));state['moved'].append(name);write_state(args,state)
 subprocess.run(['systemctl','daemon-reload'],check=True,capture_output=True,timeout=30)
 state['status']='removed';write_state(args,state)
 print('PASS: Apple viewer service stopped, disabled and removed from its installed paths.')
 print('Private rollback backup: '+str(backup))
 print('Chromium/Xvfb packages were left installed; no package removals were attempted.')
def rollback(args):
 state=json.loads(args.state.read_text())
 if state.get('patch')!=MANIFEST['patch'] or state['status']=='rolled_back':raise RuntimeError('No matching removal to roll back.')
 backup=Path(state['backup'])
 for name in state['moved']:
  target=Path(state['paths'][name])
  if target.exists() or target.is_symlink():raise RuntimeError('Runtime path already exists; refusing to overwrite it.')
  if not (backup/name).exists():raise RuntimeError('Rollback backup is missing.')
 for name in state['moved']:
  target=Path(state['paths'][name]);target.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(backup/name),str(target))
 subprocess.run(['systemctl','daemon-reload'],check=True,capture_output=True,timeout=30)
 if state['was_enabled'] and ctl('enable').returncode:raise RuntimeError('Could not restore helper enable state.')
 if state['was_active'] and ctl('start').returncode:raise RuntimeError('Could not restart restored helper.')
 state['status']='rolled_back';write_state(args,state)
 print('PASS: prior helper files and service state restored.')
def main():
 parser=argparse.ArgumentParser(description=__doc__)
 action=parser.add_mutually_exclusive_group(required=True)
 for flag in ['check','remove','rollback']:action.add_argument('--'+flag,action='store_true')
 parser.add_argument('--state',type=Path,default=Path('/opt/aurral-remove-apple-helper.json'))
 parser.add_argument('--backups',type=Path,default=Path('/opt/aurral-patch-backups'))
 args=parser.parse_args()
 args.paths={'browser':Path('/opt/aurral-apple-browser'),'unit':Path('/etc/systemd/system/aurral-apple-browser.service'),
             'pairing':Path('/opt/aurral_data/apple-browser'),'home':Path('/var/lib/aurral-apple-browser')}
 if args.check:check(args);return
 if os.geteuid()!=0:raise RuntimeError('Run inside CT109 as root.')
 if args.remove:remove(args)
 else:rollback(args)
if __name__=='__main__':
 try:main()
 except Exception as error:
  print('STOPPED: '+(str(error) if isinstance(error,RuntimeError) else type(error).__name__),file=sys.stderr);sys.exit(1)
