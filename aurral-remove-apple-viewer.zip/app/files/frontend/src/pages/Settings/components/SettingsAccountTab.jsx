import { useEffect, useState } from "react";
import { resetDiscoveryFeedback } from "../../../utils/api/endpoints/discovery.js";
import { SettingsInput, SettingsSelect } from "./SettingsField";
import PillToggle from "../../../components/PillToggle";
import { PlexSelfLinkSection } from "./PlexSelfLinkSection";
import { ConnectedAccountsSection } from "./ConnectedAccountsSection";
import { SharedLinksSection } from "./SharedLinksSection";
import { ThemeSettings } from "./ThemeSettings";

import { Link } from "react-router";
import { RotateCcw } from "lucide-react";
import { DotLoader } from "../../../components/DotLoader";
export function SettingsAccountTab({
  listenHistoryProvider,
  setListenHistoryProvider,
  listenHistoryUsername,
  setListenHistoryUsername,
  listenHistoryUrl,
  setListenHistoryUrl,
  lidarrConfigured,
  lidarrRootFolders,
  lidarrQualityProfiles,
  lidarrRootFolderPath,
  setLidarrRootFolderPath,
  lidarrQualityProfileId,
  setLidarrQualityProfileId,
  loading,
  handleSave,
  hidePanelHeader = false,
  showSuccess,
  showError,
  profileVariant = false,
  showSidebarArt = false,
  sidebarArtEnabled = true,
  setSidebarArtEnabled,
}) {
  const [resettingTastes, setResettingTastes] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("connected") === "google") {
      showSuccess?.("Connected your Google account.");
      params.delete("connected");
      const query = params.toString();
      window.history.replaceState(
        null,
        "",
        `${window.location.pathname}${query ? `?${query}` : ""}`,
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleResetDiscoveryTastes = async () => {
    if (resettingTastes) return;
    const confirmed = window.confirm(
      "Reset all More like this and Less like this preferences? Blocked artists will be kept.",
    );
    if (!confirmed) return;
    setResettingTastes(true);
    try {
      await resetDiscoveryFeedback();
      showSuccess?.("Discovery tastes reset");
    } catch (error) {
      showError?.(error.response?.data?.message || "Failed to reset discovery tastes");
    } finally {
      setResettingTastes(false);
    }
  };

  if (loading) {
    return (
      <div className={profileVariant ? "profile-settings" : "settings-page__panel"}>
        <p className="settings-page__muted-copy">
          <DotLoader size="sm" label={null} /> Loading…
        </p>
      </div>
    );
  }

  const profileSummary = (() => {
    if (listenHistoryProvider === "local") return "Local only";
    if (listenHistoryProvider === "koito" && listenHistoryUrl) {
      return `Koito: ${listenHistoryUrl}`;
    }
    if (listenHistoryProvider === "listenbrainz" && listenHistoryUsername) {
      return `ListenBrainz: ${listenHistoryUsername}`;
    }
    if (listenHistoryProvider === "lastfm" && listenHistoryUsername) {
      return `Last.fm: ${listenHistoryUsername}`;
    }
    return null;
  })();

  return (
    <div className={profileVariant ? "profile-settings" : "settings-page__panel"}>
      {!hidePanelHeader && <h2 className="settings-page__panel-title">Profile</h2>}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSave();
        }}
        className="settings-page__form"
        autoComplete="off"
      >
        <div className="settings-page__section profile-settings__section">
          <div className="settings-page__section-intro">
            <h3 className="settings-page__section-title">Appearance</h3>
          </div>
          <ThemeSettings showSuccess={showSuccess} showError={showError} />
          {profileVariant && showSidebarArt ? (
            <fieldset className="settings-page__fields profile-settings__fields">
              <div className="profile-settings__field">
                <label className="profile-settings__label" htmlFor="profile-sidebar-art">
                  Environment art
                </label>
                <PillToggle
                  id="profile-sidebar-art"
                  checked={sidebarArtEnabled}
                  onChange={(event) => setSidebarArtEnabled(event.target.checked)}
                  aria-label="Show sidebar environment art"
                />
              </div>
            </fieldset>
          ) : null}
        </div>

        <div className="settings-page__section profile-settings__section">
          <div className="settings-page__section-header">
            <div className="settings-page__section-intro">
              <h3 className="settings-page__section-title">Listening history</h3>
              <p className="settings-page__section-note">
                Connect a service to personalize discovery.
              </p>
            </div>
            {profileSummary ? (
              <span className="profile-settings__section-status">{profileSummary}</span>
            ) : null}
          </div>
          <fieldset className="settings-page__fields profile-settings__fields">
            <div className="profile-settings__field">
              <label className="profile-settings__label" htmlFor="profile-history-provider">
                Provider
              </label>
              <SettingsSelect
                id="profile-history-provider"
                value={listenHistoryProvider}
                onChange={(e) => {
                  const provider = e.target.value;
                  setListenHistoryProvider(provider);
                  if (provider === "local") {
                    setListenHistoryUsername("");
                    setListenHistoryUrl("");
                  }
                }}
              >
                <option value="local">Local only</option>
                <option value="lastfm">Last.fm</option>
                <option value="listenbrainz">ListenBrainz</option>
                <option value="koito">Koito</option>
              </SettingsSelect>
              <p className="settings-page__hint">
                Choose the listening history used for recommendations.
              </p>
            </div>
            {listenHistoryProvider === "local" ? (
              <div className="profile-settings__field">
                <p className="settings-page__hint">
                  Uses Aurral play events only.
                </p>
              </div>
            ) : listenHistoryProvider === "koito" ? (
              <div className="profile-settings__field">
                <label className="profile-settings__label" htmlFor="profile-history-url">
                  Koito URL
                </label>
                <SettingsInput
                  id="profile-history-url"
                  type="url"
                  required
                  placeholder="https://koito.example.com:4110"
                  autoComplete="off"
                  value={listenHistoryUrl}
                  onChange={(e) => setListenHistoryUrl(e.target.value)}
                />
              </div>
            ) : (
              <div className="profile-settings__field">
                <label className="profile-settings__label" htmlFor="profile-history-username">
                  Username
                </label>
                <SettingsInput
                  id="profile-history-username"
                  type="text"
                  placeholder={
                    listenHistoryProvider === "listenbrainz"
                      ? "Your ListenBrainz username"
                      : "Your Last.fm username"
                  }
                  autoComplete="off"
                  value={listenHistoryUsername}
                  onChange={(e) => setListenHistoryUsername(e.target.value)}
                />
                <p className="settings-page__hint">
                  Aurral uses this profile for personalized discovery. Configure API credentials in{" "}
                  <Link to="/settings/connect" className="settings-page__link">
                    Settings → Connect
                  </Link>
                  .
                </p>
              </div>
            )}
          </fieldset>
        </div>

        <ConnectedAccountsSection
          className={profileVariant ? "profile-settings__section" : ""}
          showSuccess={showSuccess}
          showError={showError}
        />

        <PlexSelfLinkSection
          className={profileVariant ? "profile-settings__section" : ""}
          showSuccess={showSuccess}
          showError={showError}
        />

        <SharedLinksSection
          className={profileVariant ? "profile-settings__section" : ""}
          showSuccess={showSuccess}
          showError={showError}
        />

        {lidarrConfigured && (
          <div className="settings-page__section profile-settings__section">
            <div className="settings-page__section-intro">
              <h3 className="settings-page__section-title">Library defaults</h3>
              <p className="settings-page__section-note">
                Defaults for artist adds. Profile values take priority.
              </p>
            </div>

            <fieldset className="settings-page__field-stack--lg settings-page__fields profile-settings__fields">
              <div className="profile-settings__field">
                <label className="profile-settings__label" htmlFor="profile-root-folder">
                  Default root folder
                </label>
                <SettingsSelect
                  id="profile-root-folder"
                  value={lidarrRootFolderPath}
                  onChange={(e) => setLidarrRootFolderPath(e.target.value)}
                >
                  <option value="">Use automatic default</option>
                  {lidarrRootFolders.map((folder) => (
                    <option key={folder.path} value={folder.path}>
                      {folder.path}
                    </option>
                  ))}
                </SettingsSelect>
              </div>

              <div className="profile-settings__field">
                <label className="profile-settings__label" htmlFor="profile-quality-profile">
                  Default quality profile
                </label>
                <SettingsSelect
                  id="profile-quality-profile"
                  value={lidarrQualityProfileId}
                  onChange={(e) => setLidarrQualityProfileId(e.target.value)}
                >
                  <option value="">Use automatic default</option>
                  {lidarrQualityProfiles.map((profile) => (
                    <option key={profile.id} value={String(profile.id)}>
                      {profile.name}
                    </option>
                  ))}
                </SettingsSelect>
              </div>
            </fieldset>
          </div>
        )}

        <div className="settings-page__section profile-settings__section profile-settings__section--action">
          <div className="settings-page__section-intro">
            <h3 className="settings-page__section-title">Discovery tastes</h3>
            <p className="settings-page__section-note">
              Resets More like this and Less like this. Blocked artists stay.
              {" "}<Link to="/blocklist" className="settings-page__link">Blocked artists</Link>
            </p>
          </div>
          <div className="profile-settings__action">
            <button
              type="button"
              onClick={handleResetDiscoveryTastes}
              disabled={resettingTastes}
              className="btn btn-secondary btn-sm"
            >
              {resettingTastes ? (
                <DotLoader size="xs" label={null} />
              ) : (
                <RotateCcw className="artist-icon-xs" aria-hidden />
              )}
              {resettingTastes ? "Resetting…" : "Reset discovery tastes"}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
