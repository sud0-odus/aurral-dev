#!/usr/bin/env python3
import argparse
from pathlib import Path
import subprocess
import sys

def main():
 parser=argparse.ArgumentParser(description='Remove the custom Apple viewer and retire its dedicated service.')
 parser.add_argument('--install',action='store_true',required=True);parser.parse_args()
 root=Path(__file__).resolve().parent
 def run(path,flag):subprocess.run([sys.executable,str(root/path),flag],check=True)
 run('app/apply-patch.py','--check');run('remove-helper.py','--check')
 run('app/apply-patch.py','--install');run('app/apply-patch.py','--enable')
 run('remove-helper.py','--remove')
 print('PASS: custom Apple viewer removed. Refresh Aurral with Ctrl+F5.')
 print('Your imported playlists and download scheduler were preserved. Plex connection is unchanged.')
if __name__=='__main__':
 try:main()
 except subprocess.CalledProcessError:
  print('STOPPED at the failed step. Share its output; do not repeat the complete launcher after a partial install.',file=sys.stderr);sys.exit(1)
