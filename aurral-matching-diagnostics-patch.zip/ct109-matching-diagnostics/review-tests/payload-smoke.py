import argparse,importlib.util,sqlite3,tempfile,types,json
from pathlib import Path
from unittest.mock import patch
root=Path('/workspace/ct109-matching-diagnostics');spec=importlib.util.spec_from_file_location('installer',root/'apply-patch.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as folder:
 base=Path(folder);app=base/'app';app.mkdir();before=Path('/tmp/matching-diagnostics-before')
 for item in m.MANIFEST['files']:
  if item['before_sha256'] is None:continue
  target=app/item['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((before/item['path']).read_bytes())
 db=base/'db'
 with sqlite3.connect(db) as c:c.execute('CREATE TABLE work(value TEXT)');c.execute("INSERT INTO work VALUES ('existing')")
 args=argparse.Namespace(app_dir=app,db=db,backup_dir=base/'backups',state=base/'state',health_url='http://unused')
 active=True
 def ctl(*commands):
  global active
  if commands[0]=='stop':active=False
  if commands[0]=='start':active=True
  return types.SimpleNamespace(returncode=(0 if active else 3)if commands[0]=='is-active'else 0)
 with patch.object(m,'systemctl',side_effect=ctl),patch.object(m,'healthy',return_value=True):
  m.install(args);state=m.read_state(args.state);assert not(Path(state['backup'])/'aurral.db').exists();m.enable(args)
  with sqlite3.connect(db)as c:c.execute("INSERT INTO work VALUES ('new-completion')");c.execute('CREATE TABLE matching_diagnostics_v1(payload TEXT)');c.execute("INSERT INTO matching_diagnostics_v1 VALUES ('retained evidence')")
  m.rollback(args)
 for item in m.MANIFEST['files']:
  target=app/item['path']
  if item['before_sha256'] is None:assert not target.exists()
  else:assert target.read_bytes()==(before/item['path']).read_bytes()
 with sqlite3.connect(db)as c:assert c.execute('SELECT count(*) FROM work').fetchone()[0]==2;assert c.execute('SELECT payload FROM matching_diagnostics_v1').fetchone()[0]=='retained evidence'
 print('PASS: source-only install/enable/rollback creates no database snapshot and preserves new work/evidence.')
