import test from 'node:test';import assert from 'node:assert/strict';
import {setupIsolatedBackend,cleanupIsolatedState,resetDatabase} from '../helpers/backendTestHarness.js';
const[state,{db},{dbOps},diagnostics,{buildActualFileCandidate}]=await setupIsolatedBackend('matching-diagnostics','backend/config/db-sqlite.js','backend/db/helpers/index.js','backend/services/trackMatching/matchingDiagnostics.js','backend/services/trackMatching/postDownloadValidator.js');
test.beforeEach(()=>{resetDatabase(db);dbOps.invalidateSettingsCache();delete process.env.AURRAL_MATCHING_DIAGNOSTICS;});test.after(()=>cleanupIsolatedState(state));
const job={id:'private-job',playlistId:'p',artistName:'Primary & M. Example',trackName:'Song',durationMs:180000};
const validation={valid:false,decision:'AMBIGUOUS',actualDurationMs:180010,contradictions:[],native:{evidence:['title','duration'],artistSimilarity:.6},parsedTags:{title:'Song (ft. Morgan Example)',artists:['Primary'],filename:'Song.flac',recordingMbid:'11111111-1111-4111-8111-111111111111',originalIdentityTags:{artist:'Primary',artists:['Primary'],title:'Song (ft. Morgan Example)',trackMbid:'11111111-1111-4111-8111-111111111111'}}};
const read=()=>JSON.parse(db.prepare('SELECT payload FROM matching_diagnostics_v1 ORDER BY id DESC LIMIT 1').get().payload);
test('captures original tags and imported/queued/effective reference differences without secrets or paths',()=>{
 dbOps.updateSettings({sharedPlaylists:[{id:'p',sourceName:'Apple Music',importSource:{provider:'apple-playlist',apiKey:'private-key'},tracks:[{artistName:job.artistName,trackName:'Song',durationMs:159000,sourceTrackId:'private-source-id'}]}]});
 const candidate={raw:{user:'private-peer',file:'\\private-peer\\private-folder\\Song.flac'},apiKey:'private-key'};
 assert.equal(diagnostics.recordValidationDiagnostic({job,request:{...job,durationMs:213000},candidate,validation}),true);
 const r=read();assert.equal(r.storedPlaylist.durationMs,159000);assert.equal(r.queued.durationMs,180000);assert.equal(r.effective.durationMs,213000);assert.equal(r.observed.originalTags.artist,'Primary');
 assert.equal(r.storedPlaylist.sourceTrackId,'private-source-id');
 assert.equal(r.observed.recordingMbid,'11111111-1111-4111-8111-111111111111');
 const serialized=JSON.stringify(r);for(const privateValue of ['private-job','private-peer','private-folder','private-key'])assert.equal(serialized.includes(privateValue),false);
 assert.equal(job.durationMs,180000);assert.equal(validation.valid,false);
});
test('search diagnostics preserve rejection counts and only a bounded sample',()=>{
 const evaluations=Array.from({length:50},()=>({decision:'reject',reason:'contradiction',contradictions:['artist'],candidate:{title:'Song',artists:['Wrong Artist'],raw:{file:'C:\\private\\Song.flac',user:'private-peer'}}}));
 assert.equal(diagnostics.recordEmptySearchDiagnostic({job,request:job,evaluation:{evaluations},counts:{queryCount:3,rawResultCount:60,eligibleCount:0}}),true);
 const r=read();assert.equal(r.counts.raw,60);assert.equal(r.reasons.artist,50);assert.equal(r.samples.length,3);assert.equal(r.samples[0].filename,'Song.flac');assert.equal(JSON.stringify(r).includes('private-peer'),false);
});
test('capture is capped at 1000 records, prunes old evidence and fails open on write failure',()=>{
 for(let i=0;i<1002;i++)diagnostics.recordValidationDiagnostic({job,request:job,validation});
 assert.equal(db.prepare('SELECT count(*) n FROM matching_diagnostics_v1').get().n,1000);
 db.prepare('UPDATE matching_diagnostics_v1 SET created_at=0').run();diagnostics.recordValidationDiagnostic({job,request:job,validation});
 assert.equal(db.prepare('SELECT count(*) n FROM matching_diagnostics_v1').get().n,1);
 db.pragma('query_only=ON');try{assert.equal(diagnostics.recordValidationDiagnostic({job,request:job,validation}),false);}finally{db.pragma('query_only=OFF');}
});
test('capture can be disabled and verified sampling is deterministic',()=>{
 process.env.AURRAL_MATCHING_DIAGNOSTICS='0';assert.equal(diagnostics.recordValidationDiagnostic({job,request:job,validation}),false);delete process.env.AURRAL_MATCHING_DIAGNOSTICS;
 const results=Array.from({length:10},()=>diagnostics.recordValidationDiagnostic({job,request:job,validation:{...validation,valid:true,decision:'VERIFIED'}}));
 assert.ok(results.every(value=>value===results[0]));
});

test('capture restores SQLite busy timeout and bounds oversized metadata',()=>{
 const longName='A'.repeat(400),longAliases=Array(10).fill(longName);
 const timeout=db.pragma('busy_timeout',{simple:true});
 assert.equal(diagnostics.recordValidationDiagnostic({job:{...job,artistName:longName,trackName:longName,albumName:longName,artistAliases:longAliases},request:{...job,artistName:longName,trackName:longName,albumName:longName,artistAliases:longAliases},validation:{...validation,parsedTags:{...validation.parsedTags,artists:longAliases,originalIdentityTags:{artist:longName,title:longName,artists:longAliases,albumArtist:longName}}}}),true);
 assert.equal(db.pragma('busy_timeout',{simple:true}),timeout);
 assert.ok(Buffer.byteLength(db.prepare('SELECT payload FROM matching_diagnostics_v1 ORDER BY id DESC LIMIT 1').get().payload)<=8192);
});

test('original embedded tag values survive separately from the normalized recording claim',()=>{
 const a='11111111-1111-4111-8111-111111111111',b='22222222-2222-4222-8222-222222222222';
 const actual=buildActualFileCandidate({common:{artist:'Original Artist',artists:['Original Artist','Guest'],albumartist:'Compilation Credit',title:'Original Title',musicbrainz_recordingid:a,musicbrainz_trackid:b},format:{duration:180}},'/private/folder/Claim.flac','soulseek');
 assert.equal(actual.recordingMbid,a);assert.equal(actual.originalIdentityTags.trackMbid,b);assert.equal(actual.originalIdentityTags.albumArtist,'Compilation Credit');
 assert.equal(diagnostics.recordValidationDiagnostic({job,request:job,validation:{...validation,parsedTags:actual}}),true);
 assert.equal(read().observed.originalTags.artist,'Original Artist');assert.equal(read().effective.artist,job.artistName);
 assert.equal(JSON.stringify(read()).includes('/private/folder'),false);
});
