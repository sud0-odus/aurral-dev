import importlib.util,tempfile,sqlite3,json,gzip,time,unittest,os
from pathlib import Path
spec=importlib.util.spec_from_file_location('exporter','/workspace/aurral-dev/scripts/export-matching-diagnostics.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class ExportTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name);self.db=self.root/'db'
  with sqlite3.connect(self.db)as c:
   c.execute('CREATE TABLE matching_diagnostics_v1(id INTEGER PRIMARY KEY,created_at INTEGER,payload TEXT)')
   self.record={'stage':'post-download','effective':{'artist':'Private Artist','artistAliases':['Private Artist'],'title':'Private Song','sourceTrackId':'private-source-id'},'result':{'decision':'AMBIGUOUS'},'observed':{'title':'Private Song','filename':'Private Song.flac'}}
   c.execute('INSERT INTO matching_diagnostics_v1 VALUES(1,?,?)',(int(time.time()*1000),json.dumps(self.record)))
 def test_default_export_hides_names_and_preserves_correlations(self):
  before=self.db.read_bytes();out=self.root/'redacted.gz';self.assertEqual(m.export(self.db,out),1);r=json.load(gzip.open(out,'rt'));data=json.dumps(r)
  for value in ['Private Artist','Private Song','private-source-id']:self.assertNotIn(value,data)
  e=r['records'][0];self.assertEqual(e['effective']['artist'],e['effective']['artistAliases'][0]);self.assertEqual(e['effective']['title'],e['observed']['title']);self.assertEqual(self.db.read_bytes(),before);self.assertEqual(out.stat().st_mode&0o777,0o600)
 def test_explicit_names_and_no_overwrite(self):
  out=self.root/'exact.gz';m.export(self.db,out,include_names=True);self.assertIn('Private Artist',gzip.open(out,'rt').read())
  with self.assertRaises(FileExistsError):m.export(self.db,out)
 def test_window_and_limit(self):
  with sqlite3.connect(self.db)as c:c.execute('UPDATE matching_diagnostics_v1 SET created_at=0')
  out=self.root/'empty.gz';self.assertEqual(m.export(self.db,out),0)
  with self.assertRaises(ValueError):m.export(self.db,self.root/'bad.gz',hours=169)
 def test_missing_db_is_not_created(self):
  path=self.root/'missing'
  with self.assertRaises(sqlite3.OperationalError):m.export(path,self.root/'missing.gz')
  self.assertFalse(path.exists())
unittest.main()
