#!/usr/bin/env python3
"""Export bounded matching evidence locally. Never uploads to GitHub."""
import argparse,collections,datetime,gzip,json,os
from pathlib import Path
import sqlite3

def redact_names(value, mapping=None, key=''):
    mapping = {} if mapping is None else mapping
    fields={'artist':'artist','artists':'artist','artistAliases':'artist','albumArtist':'artist','title':'title','album':'album','filename':'file','sourceTrackId':'source-id'}
    if isinstance(value,dict):
        return {k:redact_names(v,mapping,k) for k,v in value.items()}
    if isinstance(value,list):
        return [redact_names(v,mapping,key) for v in value]
    if key in fields and isinstance(value,str) and value:
        identity=(fields[key],value)
        if identity not in mapping:mapping[identity]=f'{fields[key]}-{len(mapping)+1}'
        return mapping[identity]
    return value

def export(db_path, output, hours=24, include_names=False):
    if not 0<hours<=168:raise ValueError('Use 0 < hours <= 168')
    cutoff=int((datetime.datetime.now(datetime.timezone.utc).timestamp()-hours*3600)*1000)
    connection=sqlite3.connect(Path(db_path).resolve().as_uri()+'?mode=ro',uri=True,timeout=5)
    connection.execute('PRAGMA query_only=ON')
    try:
        if not connection.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='matching_diagnostics_v1'").fetchone():
            raise ValueError('No matching diagnostics captured yet. Install/enable the evidence patch first.')
        rows=connection.execute('SELECT created_at,payload FROM matching_diagnostics_v1 WHERE created_at>=? ORDER BY id DESC LIMIT 1000',(cutoff,)).fetchall()
    finally:connection.close()
    records=[{'captured_at_ms':timestamp,**json.loads(payload)} for timestamp,payload in rows]
    counts=collections.Counter((r.get('stage'),r.get('result',{}).get('decision','search')) for r in records)
    if not include_names:records=redact_names(records)
    report={'format':'aurral-matching-diagnostics-v1','generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'track_names_included':include_names,'hours':hours,'records':records,
        'summary':[{'stage':k[0],'decision':k[1],'count':v}for k,v in sorted(counts.items())],
        'limits':{'max_records':1000,'max_payload_bytes':8192,'retention_days_on_capture':7},
        'notes':['Rejections and deterministic 5% verified sample; not a success-rate denominator.',
                 'Evidence captured before file cleanup; absence of imported reference is explicitly unknown.',
                 'No audio, paths, peer names, account names, credentials or provider response dumps.',
                 'No automatic upload. Review before sharing; included track names can identify listening preferences.']}
    output=Path(output)
    with output.open('xb') as raw:
        os.chmod(output,0o600)
        with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as compressed:
            compressed.write(json.dumps(report,ensure_ascii=False).encode())
    return len(records)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db',default='/opt/aurral_data/aurral.db')
    parser.add_argument('--hours',type=float,default=24)
    parser.add_argument('--include-track-names',action='store_true')
    parser.add_argument('--output',default='/tmp/aurral-matching-diagnostics-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'.json.gz')
    args=parser.parse_args()
    count=export(args.db,args.output,args.hours,args.include_track_names)
    print(f'Exported {count} retained records: {args.output}')
    print('Track names '+('included; review before sharing.'if args.include_track_names else 'replaced with stable labels within this export.'))
if __name__=='__main__':
    try:main()
    except (OSError,ValueError,sqlite3.Error) as error:raise SystemExit(str(error))
