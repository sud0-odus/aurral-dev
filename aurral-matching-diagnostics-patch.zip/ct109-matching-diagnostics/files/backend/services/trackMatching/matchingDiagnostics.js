// Bounded local evidence, captured before rejected files are cleaned up.
// This module never changes a matching decision or initiates provider work.
import crypto from "node:crypto";
import { db } from "../../config/db-sqlite.js";
import { dbOps } from "../../db/helpers/index.js";
const LIMIT = 1000, MAX_BYTES = 8192, AGE_MS = 7 * 86400000;
const hash = value => crypto.createHash("sha256").update(String(value || "")).digest("hex").slice(0, 20);
const text = value => String(value || "").replace(/https?:\/\/\S+|\b(?:Bearer|Basic)\s+\S+/gi, "[redacted]")
  .replace(/[\x00-\x1f\x7f]/g, " ").trim().slice(0, 180);
const names = value => (Array.isArray(value) ? value : value ? [value] : []).slice(0, 10).map(text);
const number = value => Number.isFinite(Number(value)) && value != null ? Number(value) : null;
const uuid = value => /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(String(value || "")) ? String(value).toLowerCase() : null;
const sourceId = value => /^[a-z0-9._-]{1,120}$/i.test(String(value || "")) ? String(value) : null;
const basename = value => text(String(value || "").replaceAll("\\", "/").split("/").at(-1));
const tokens = values => (Array.isArray(values) ? values : []).slice(0, 12)
  .map(value => String(value)).filter(value => /^[a-z0-9 _-]{1,60}$/i.test(value));
const requestSnapshot = request => ({ artist:text(request?.artistName), title:text(request?.trackName), album:text(request?.albumName),
  artistAliases:names(request?.artistAliases), durationMs:number(request?.durationMs),
  recordingMbid:uuid(request?.recordingMbid || request?.trackMbid),
  recordingMbidAliases:names(request?.recordingMbidAliases).map(uuid).filter(Boolean),
  releaseMbid:uuid(request?.releaseMbid), albumMbid:uuid(request?.albumMbid) });
function importedSnapshot(job) {
  const playlist = dbOps.getSettings()?.sharedPlaylists?.find(item => item.id === job?.playlistId);
  if (!playlist) return null;
  const candidates = (playlist.tracks || []).filter(track =>
    String(track.artistName || "").trim().toLowerCase() === String(job.artistName || "").trim().toLowerCase()
    && String(track.trackName || "").trim().toLowerCase() === String(job.trackName || "").trim().toLowerCase());
  const track = candidates.length === 1 ? candidates[0] : null;
  return { referenceStage:"current-stored-playlist", provider:text(playlist.importSource?.provider || playlist.sourceName), matchingTracks:candidates.length,
    ...(track ? { ...requestSnapshot(track), hasSourceTrackId:Boolean(track.sourceTrackId), sourceTrackId:sourceId(track.sourceTrackId), sourceService:text(track.sourceService) } : {}) };
}
let initialized = false, lastWarning = 0;
function insert(record, now = Date.now()) {
  let json = JSON.stringify(record);
  if (Buffer.byteLength(json) > MAX_BYTES) {
    record.truncated = true;
    for (const key of ["queued","effective","storedPlaylist"]) if (record[key]) {
      record[key].artistAliases = record[key].artistAliases?.slice(0,2);
      record[key].recordingMbidAliases = record[key].recordingMbidAliases?.slice(0,2);
    }
    if(record.samples)record.samples=record.samples.slice(0,1);
    if(record.observed?.originalTags?.artists)record.observed.originalTags.artists=record.observed.originalTags.artists.slice(0,2);
    json=JSON.stringify(record);
    if(Buffer.byteLength(json)>MAX_BYTES)return false;
  }
  if (!initialized) {
    db.exec(`CREATE TABLE IF NOT EXISTS matching_diagnostics_v1 (
      id INTEGER PRIMARY KEY, created_at INTEGER NOT NULL, payload TEXT NOT NULL);
      CREATE INDEX IF NOT EXISTS matching_diagnostics_v1_created ON matching_diagnostics_v1(created_at);`);
    initialized = true;
  }
  db.transaction(() => {
    db.prepare("INSERT INTO matching_diagnostics_v1(created_at,payload) VALUES (?,?)").run(now,json);
    db.prepare("DELETE FROM matching_diagnostics_v1 WHERE created_at < ?").run(now - AGE_MS);
    db.prepare("DELETE FROM matching_diagnostics_v1 WHERE id IN (SELECT id FROM matching_diagnostics_v1 ORDER BY id DESC LIMIT -1 OFFSET ?)").run(LIMIT);
  })();
  return true;
}
function capture(build) {
  if (process.env.AURRAL_MATCHING_DIAGNOSTICS === "0") return false;
  let previousTimeout;
  try {
    previousTimeout = db.pragma("busy_timeout", { simple:true });
    // Diagnostics must not hold up matching while another process writes.
    db.pragma("busy_timeout = 0");
    return insert(build());
  } catch {
    if (Date.now() - lastWarning > 1800000) {
      lastWarning = Date.now();console.warn("[matcher diagnostics] Evidence capture unavailable; matching continues unchanged.");
    }
    return false;
  } finally {
    if (previousTimeout !== undefined) {
      try { db.pragma(`busy_timeout = ${Number(previousTimeout) || 0}`); } catch { /* Do not disrupt matching during shutdown. */ }
    }
  }
}
export function recordValidationDiagnostic({ job, request, candidate, validation } = {}) {
  // Every rejection; deterministic 5% sample of verified cases for comparison.
  if (validation?.valid && parseInt(hash(job?.id).slice(0, 4), 16) % 20 !== 0) return false;
  return capture(() => {
    const observed = validation?.parsedTags || validation?.actual?.tags || {};
    const tags = observed.originalIdentityTags || {};
    const native = validation?.native || {};
    return { version:1, source:"slskd", stage:"post-download", job:hash(job?.id),
      storedPlaylist:importedSnapshot(job), queued:requestSnapshot(job), effective:requestSnapshot(request),
      candidateDecision:text(candidate?.evaluation?.decision),
      observed:{ title:text(observed.title), artists:names(observed.artists), album:text(observed.album),
        filename:basename(observed.filename || candidate?.raw?.file), durationMs:number(validation?.actualDurationMs),
        recordingMbid:uuid(observed.recordingMbid),
        originalTags:{ title:text(tags.title), artist:text(tags.artist), artists:names(tags.artists), albumArtist:text(tags.albumArtist),
          recordingMbid:uuid(tags.recordingMbid), trackMbid:uuid(tags.trackMbid), releaseTrackMbid:uuid(tags.releaseTrackMbid) } },
      result:{ decision:text(validation?.decision), reason:text(validation?.reason), contradictions:tokens(validation?.contradictions), evidence:tokens(native.evidence),
        titleSimilarity:number(native.titleSimilarity), artistSimilarity:number(native.artistSimilarity), durationGapMs:number(native.durationGapMs),
        policyVersion:text(native.policyVersion), strict:Boolean(validation?.strict) } };
  });
}
export function recordEmptySearchDiagnostic({ job, request, evaluation, counts } = {}) {
  return capture(() => {
    const rows = evaluation?.evaluations || [], decisions = {}, reasons = {};
    for (const entry of rows) {
      const decision = ["accept","verify","review","reject"].includes(entry.decision) ? entry.decision : "unknown";
      decisions[decision] = (decisions[decision] || 0) + 1;
      for (const reason of tokens([entry.reason, ...(entry.contradictions || []), ...(entry.reasons || [])].filter(Boolean))) reasons[reason] = (reasons[reason] || 0) + 1;
    }
    return {version:1,source:"slskd",stage:"search-no-candidate",job:hash(job?.id),storedPlaylist:importedSnapshot(job),queued:requestSnapshot(job),effective:requestSnapshot(request),
      counts:{queries:number(counts?.queryCount),raw:number(counts?.rawResultCount),evaluated:rows.length,eligible:number(counts?.eligibleCount)},decisions,
      reasons:Object.fromEntries(Object.entries(reasons).sort((a,b)=>b[1]-a[1]).slice(0,15)),
      samples:rows.slice(0,3).map(entry=>({decision:text(entry.decision),contradictions:tokens(entry.contradictions),
        title:text(entry.candidate?.title),artists:names(entry.candidate?.artists),filename:basename(entry.candidate?.raw?.file),
        durationMs:number(entry.candidate?.durationMs),recordingMbid:uuid(entry.candidate?.recordingMbid),distance:number(entry.distance)}))};
  });
}
