import { createHash } from "node:crypto";
// Ported from the proven Apple POC compare/inventory flow. A possible match is
// never offered for automatic restore, and local additions are never removed.
const normalized = value => String(value || "").normalize("NFKC").toLowerCase().replace(/\s+/g, " ").trim();
const artist = track => normalized(track?.artistName || track?.artist);
const title = track => normalized(track?.trackName || track?.title);
const core = track => `${artist(track)}\u0001${title(track)}`;
const album = track => normalized(track?.albumName || track?.album);
export function sourceFingerprint({source, tracks}) {
  return createHash("sha256").update(JSON.stringify([source.service,source.kind,source.id,tracks])).digest("hex");
}
export function importedMatches(owned, source) {
  const linked = owned.filter(p => p.importSource?.provider === "apple-playlist" && p.importSource.externalId === `${source.kind}:${source.id}`);
  if (linked.length) return linked;
  // Unnamed Apple resources cannot be safely matched to a legacy playlist.
  if (!source.name || source.name === "Apple Music playlist") return [];
  return owned.filter(p => normalized(p.sourceName) === "apple music" && normalized(p.name) === normalized(source.name));
}
export function playlistSummary(playlist) {
  return {id:playlist.id,name:playlist.name,externalId:playlist.importSource?.provider === "apple-playlist" ? playlist.importSource.externalId : null,trackCount:Array.isArray(playlist.tracks)?playlist.tracks.length:0};
}
export function comparePlaylist(target, tracks) {
  const existing = (Array.isArray(target.tracks) ? target.tracks : []).filter(t => artist(t) && title(t));
  const used = new Set();let matched=0,probable=0,missing=0,ambiguous=0;
  const details = tracks.map((track,index) => {
    const candidates = existing.map((entry,i)=>({entry,i})).filter(({entry,i})=>!used.has(i)&&core(entry)===core(track));
    const exact = candidates.filter(({entry})=>album(entry)&&album(entry)===album(track));
    const chosen = exact.length===1?exact[0]:(exact.length===0&&candidates.length===1?candidates[0]:null);
    let status;
    if (!artist(track)||!title(track)) {status="needs-review";ambiguous++;}
    else if (chosen) {used.add(chosen.i);status=exact.length===1?"matched":"possible-match";if(status==="matched")matched++;else probable++;}
    else if (candidates.length || existing.some(entry=>core(entry)===core(track))) {status="needs-review";ambiguous++;}
    else {status="missing";missing++;}
    return {index,artist:track.artistName||track.artist,title:track.trackName||track.title,status};
  });
  return {playlistId:target.id,appleTracks:tracks.length,aurralTracks:existing.length,matched,probable,missing,ambiguous,localOnly:existing.length-used.size,details};
}
