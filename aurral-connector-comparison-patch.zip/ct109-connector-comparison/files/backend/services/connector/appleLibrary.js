import { readSession } from "./store.js";
import { appleWebJSON, ConnectorValidationError } from "./adapters.js";
import { appleArtwork, appleTrack, sourceText } from "./metadata.js";
const ORIGIN = "https://amp-api.music.apple.com";
const active = new Set();let activeCount = 0;
const validId = id => typeof id === "string" && /^[A-Za-z0-9][A-Za-z0-9._-]{0,119}$/.test(id);
const failure = (code, message) => new ConnectorValidationError(code, message);
export function librarySession(userId) {
  const credentials = readSession(userId, "apple");
  if (!credentials?.session) throw failure("APPLE_RECONNECT_REQUIRED", "Reconnect Apple Music before reading your library.");
  const deadline=Date.now()+60000;
  return { session: credentials.session,
    assertCurrent() { if(Date.now()>deadline)throw failure("APPLE_LIBRARY_TIMEOUT","The library scan exceeded its time limit. Nothing was imported."); if (readSession(userId, "apple")?.session !== credentials.session) throw failure("APPLE_SESSION_CHANGED", "Apple connection changed. Open the source again."); } };
}
export async function withAppleRead(userId, operation) {
  if (active.has(String(userId)) || activeCount >= 2) throw failure("APPLE_LIBRARY_BUSY", "Another library request is running. Wait for it to finish.");
  active.add(String(userId));activeCount++;
  try { return await operation(); } finally { active.delete(String(userId));activeCount--; }
}
export async function applePages(path, context, { request = appleWebJSON, maximum = 3000 } = {}) {
  const expectedPath = new URL(path, ORIGIN).pathname;const seen = new Set();const items = [];
  for (let page = 0; page < 40; page++) {
    const url = new URL(path, ORIGIN);
    if (url.origin !== ORIGIN || url.username || url.password || url.hash || url.pathname !== expectedPath || seen.has(url.href)) throw failure("APPLE_PAGINATION_INVALID", "Apple returned unexpected or repeated pagination. Nothing was imported.");
    seen.add(url.href);context.assertCurrent();
    const result = await request(url.pathname + url.search, context.session);
    if (!Array.isArray(result?.data)) throw failure("APPLE_LIBRARY_FORMAT", "Apple returned an incomplete library page. Nothing was imported.");
    items.push(...result.data);
    if (items.length > maximum) throw failure("APPLE_LIBRARY_LIMIT", "This source exceeds the import limit. Nothing was imported.");
    if (!result.next) { context.assertCurrent();return items; }
    if (typeof result.next !== "string") throw failure("APPLE_PAGINATION_INVALID", "Apple returned an invalid next page. Nothing was imported.");
    path = result.next;
  }
  throw failure("APPLE_LIBRARY_LIMIT", "This source has too many pages. Nothing was imported.");
}
export function playlistMetadata(item, kind) {
  if (!validId(item?.id)) throw failure("APPLE_SOURCE_INVALID", "Apple returned an invalid playlist identifier.");
  return { service: "apple", kind, id: item.id, name: sourceText(item.attributes?.name) || sourceText(item.attributes?.title) || "Apple Music playlist", artworkUrl: appleArtwork(item.attributes?.artwork) };
}
export function createAppleLibrary(userId, { request = appleWebJSON } = {}) {
  const context = librarySession(userId);
  return {
    context,
    async list() { return (await applePages("/v1/me/library/playlists?limit=50", context, { request, maximum: 2000 })).map(item => playlistMetadata(item, "library")); },
    async groups() { return (await applePages("/v1/me/recommendations?platform=web&limit=25",context,{request,maximum:200})).map(item=>({id:item.id,name:sourceText(item.attributes?.title)||sourceText(item.attributes?.name)||"Recommendations"})).filter(item=>/^[A-Za-z0-9_-]{1,100}$/.test(item.id)); },
    async group(id) {
      if (!/^[A-Za-z0-9_-]{1,100}$/.test(id)) throw failure("APPLE_SOURCE_INVALID","Invalid recommendation group.");
      return (await applePages(`/v1/me/recommendations/${id}/contents?platform=web&limit=100`,context,{request,maximum:1000})).filter(item=>item.type==="playlists").map(item=>playlistMetadata(item,"catalog"));
    },
    async playlist(kind, id) {
      if (!validId(id) || !["library","catalog"].includes(kind) || (kind==="catalog" && !id.startsWith("pl."))) throw failure("APPLE_SOURCE_INVALID", "Invalid Apple playlist selection.");
      let base = `/v1/me/library/playlists/${encodeURIComponent(id)}`;
      if (kind==="catalog") {
        const storefront = await request("/v1/me/storefront",context.session);const region=storefront?.data?.[0]?.id;
        if (!/^[a-z]{2}$/.test(region || "")) throw failure("APPLE_STOREFRONT_INVALID","Apple did not return your storefront.");
        base=`/v1/catalog/${region}/playlists/${encodeURIComponent(id)}`;
      }
      const result = await request(base, context.session);const resource=result?.data?.[0];
      if (resource?.id !== id) throw failure("APPLE_SOURCE_INVALID", "Apple did not return the selected playlist.");
      const source = playlistMetadata(resource,kind);
      const raw = await applePages(`${base}/tracks?limit=100`,context,{request});
      const tracks = raw.map(appleTrack);
      if (!tracks.length || tracks.some(track=>!track)) throw failure("APPLE_TRACK_METADATA_INVALID","Some tracks lack artist/title metadata. Nothing was imported.");
      if (!source.artworkUrl) { source.artworkUrl=tracks.find(track=>track.artworkUrl)?.artworkUrl || null;source.artworkKind="track-fallback"; }
      else source.artworkKind="playlist";
      context.assertCurrent();return { source, tracks };
    },
  };
}
