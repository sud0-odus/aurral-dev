import { createHash } from "node:crypto";
import { requireAuth, requireUserAccount } from "../../middleware/requirePermission.js";
import { createAppleLibrary, withAppleRead } from "../../services/connector/appleLibrary.js";
import { publicTasteProfile, upsertTasteSource, removeTasteSource, TasteSourceError } from "../../services/connector/tasteSources.js";
import { ConnectorValidationError } from "../../services/connector/adapters.js";
import { requestUserDiscoveryRefresh } from "../../services/discovery/provider.js";
import { flowPlaylistConfig } from "../../services/playlists/flowPlaylistConfig.js";
import { playlistOperationQueue } from "../../services/playlists/playlistOperationQueue.js";
import { importedMatches, playlistSummary, comparePlaylist, sourceFingerprint } from "../../services/connector/playlistComparison.js";
import { playlistManager } from "../../services/playlists/playlistManager.js";
import { fetchAppleArtwork } from "../../services/connector/sourceArtwork.js";
const adapters = new Map([["apple", { create: createAppleLibrary, read: withAppleRead }]]);
function playlistId(userId, source) {
  const hex=createHash("sha256").update(`${userId}:${source.service}:${source.kind}:${source.id}`).digest("hex").slice(0,32);
  return `${hex.slice(0,8)}-${hex.slice(8,12)}-5${hex.slice(13,16)}-a${hex.slice(17,20)}-${hex.slice(20)}`;
}
export function registerConnectorLibrary(router, { adapterRegistry = adapters, refresh = requestUserDiscoveryRefresh, queue = playlistOperationQueue, artwork = { fetch: fetchAppleArtwork, save: (...args) => playlistManager.saveArtworkUpload(...args) } } = {}) {
  const guard=[requireAuth, requireUserAccount];
  const enqueueRefresh=userId=>{try{return refresh(userId,{reason:"imported-taste-updated"});}catch{return{enqueued:false,reason:"refresh_will_retry"};}};
  const wrap=fn=>async(req,res)=>{res.set("Cache-Control","no-store");try{await fn(req,res);}catch(error){res.status(400).json({error:error instanceof ConnectorValidationError||error instanceof TasteSourceError?error.message:"The library action could not complete. No partial source was imported.",code:error instanceof ConnectorValidationError?error.code:"CONNECTOR_LIBRARY_FAILED"});}};
  const read=(req,operation)=>{
    const adapter=adapterRegistry.get(req.params.service);
    if(!adapter)throw new ConnectorValidationError("CONNECTOR_LIBRARY_UNSUPPORTED","This service does not yet support library browsing.");
    return adapter.read(req.user.id,()=>operation(adapter.create(req.user.id)));
  };
  const root="/me/connector";
  const owned = req => flowPlaylistConfig.getStaticPlaylistsOwnedByUser(req.user.id);
  const preview = (req,data) => {
    const matches = importedMatches(owned(req),data.source);
    return {...data,fingerprint:sourceFingerprint(data),matches:matches.map(playlistSummary),comparison:matches.length===1?comparePlaylist(matches[0],data.tracks):null};
  };
  const requireTarget = (req,data) => {
    if(req.body?.fingerprint!==sourceFingerprint(data))throw new ConnectorValidationError("APPLE_SOURCE_CHANGED","Apple playlist changed. Compare it again before making changes.");
    const matches=importedMatches(owned(req),data.source);
    if(matches.length!==1||matches[0].id!==req.body?.playlistId)throw new ConnectorValidationError("APPLE_PLAYLIST_UNVERIFIED","A single matching playlist owned by you is required. Compare again.");
    return matches[0];
  };
  router.get(`${root}/services/:service/inventory`,...guard,wrap((req,res)=>res.json({items:owned(req).filter(p=>p.importSource?.provider===`${req.params.service}-playlist`||(req.params.service==="apple"&&String(p.sourceName).toLowerCase()==="apple music")).map(playlistSummary)})));
  router.post(`${root}/services/:service/compare`,...guard,wrap(async(req,res)=>res.json(await read(req,async client=>preview(req,await client.playlist(req.body?.kind,req.body?.id))))));
  router.post(`${root}/services/:service/restore-missing`,...guard,wrap(async(req,res)=>{
    const indexes=req.body?.selectedIndexes;
    if(req.body?.downloadMissing!==true||!Array.isArray(indexes)||!indexes.length||indexes.length>50||indexes.some(i=>!Number.isSafeInteger(i)||i<0)||new Set(indexes).size!==indexes.length)throw new ConnectorValidationError("APPLE_RESTORE_SELECTION","Choose 1–50 missing tracks and explicitly request their download.");
    const result=await read(req,async client=>{
      const data=await client.playlist(req.body?.kind,req.body?.id);client.context.assertCurrent();
      const target=requireTarget(req,data),comparison=comparePlaylist(target,data.tracks);
      if(indexes.some(i=>comparison.details[i]?.status!=="missing"))throw new ConnectorValidationError("APPLE_RESTORE_CHANGED","Some selected tracks already exist or need review. Compare again.");
      const tracks=indexes.map(i=>data.tracks[i]);
      if(new Set(tracks.map(t=>`${t.artistName.toLowerCase().trim()}\u0001${t.trackName.toLowerCase().trim()}`)).size!==tracks.length)throw new ConnectorValidationError("APPLE_RESTORE_DUPLICATE","Duplicate selections need review. Compare again.");
      const operation=await queue.enqueuePayload({kind:"shared-playlist-append-tracks",label:`shared-playlist:${target.id}:apple-restore`,playlistId:target.id,tracks,ownerUserId:req.user.id});
      return{queued:true,count:tracks.length,operationId:operation.operationId};
    });res.json(result);
  }));
  router.post(`${root}/services/:service/artwork`,...guard,wrap(async(req,res)=>{
    if(req.body?.replaceArtwork!==true)throw new ConnectorValidationError("APPLE_ARTWORK_CONSENT","Confirm replacing the current playlist cover.");
    await read(req,async client=>{
      const data=await client.playlist(req.body?.kind,req.body?.id);client.context.assertCurrent();requireTarget(req,data);
      if(!data.source.artworkUrl||data.source.artworkKind!=="playlist")throw new ConnectorValidationError("APPLE_ARTWORK_UNAVAILABLE","Apple did not provide a playlist cover. Existing artwork was preserved.");
      const image=await artwork.fetch(data.source.artworkUrl);
      if(!image)throw new ConnectorValidationError("APPLE_ARTWORK_UNAVAILABLE","The Apple playlist cover could not be loaded.");
      client.context.assertCurrent();const target=requireTarget(req,data);await artwork.save(target.id,image);
    });res.json({updated:true});
  }));
  router.get(`${root}/preferences`,...guard,wrap((req,res)=>res.json(publicTasteProfile(req.user.id))));
  router.delete(`${root}/preferences/:key`,...guard,wrap((req,res)=>{const changed=removeTasteSource(req.user.id,req.params.key);if(changed)enqueueRefresh(req.user.id);res.json({changed,...publicTasteProfile(req.user.id)});}));
  router.get(`${root}/services/:service/library`,...guard,wrap(async(req,res)=>res.json({playlists:await read(req,client=>client.list())})));
  router.get(`${root}/services/:service/groups`,...guard,wrap(async(req,res)=>res.json({groups:await read(req,client=>client.groups())})));
  router.get(`${root}/services/:service/groups/:id`,...guard,wrap(async(req,res)=>res.json({playlists:await read(req,client=>client.group(req.params.id))})));
  router.get(`${root}/services/:service/playlists/:kind/:id`,...guard,wrap(async(req,res)=>res.json(await read(req,async client=>preview(req,await client.playlist(req.params.kind,req.params.id))))));
  router.post(`${root}/services/:service/preferences`,...guard,wrap(async(req,res)=>{
    const result=await read(req,async client=>{const data=await client.playlist(req.body?.kind,req.body?.id);client.context.assertCurrent();return upsertTasteSource(req.user.id,data.source,data.tracks);});
    if(result.tasteChanged)enqueueRefresh(req.user.id);
    res.json({changed:result.changed,preferences:publicTasteProfile(req.user.id)});
  }));
  router.post(`${root}/services/:service/import-playlist`,...guard,wrap(async(req,res)=>{
    if(req.body?.downloadMissing!==true)return res.status(400).json({error:"Adding a playlist requires explicitly requesting its download queue."});
    const result=await read(req,async client=>{
      const {source,tracks}=await client.playlist(req.body?.kind,req.body?.id);client.context.assertCurrent();
      const own=flowPlaylistConfig.getStaticPlaylistsOwnedByUser(req.user.id);
      const matches=importedMatches(own,source);
      if(matches.length>1)throw new ConnectorValidationError("APPLE_PLAYLIST_AMBIGUOUS","Multiple existing playlists match. Review them before importing.");
      if(matches.length)return{alreadyImported:true,playlistId:matches[0].id};
      if(source.name==="Apple Music playlist")throw new ConnectorValidationError("APPLE_PLAYLIST_NAME_MISSING","Apple did not provide a playlist name. Import is blocked to avoid creating an unidentified duplicate.");
      const conflict=[...own,...flowPlaylistConfig.getFlowsOwnedByUser(req.user.id)].some(item=>item.name.toLocaleLowerCase()===source.name.toLocaleLowerCase());
      if(conflict)throw new ConnectorValidationError("APPLE_PLAYLIST_NAME_CONFLICT","A different playlist or flow already uses this name. Rename it before importing this source.");
      const id=playlistId(req.user.id,source);
      const operation=await queue.enqueuePayload({kind:"shared-playlist-create",label:`shared-playlist:${id}:apple-import`,playlistId:id,name:source.name,sourceName:"Apple Music",ownerUserId:req.user.id,tracks,
        importSource:{provider:"apple-playlist",externalId:`${source.kind}:${source.id}`,externalName:source.name,artworkUrl:source.artworkUrl,syncEnabled:false},description:"Imported from Apple Music"});
      return{playlistId:id,queued:true,operationId:operation.operationId};
    });res.json(result);
  }));
}
