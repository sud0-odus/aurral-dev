import { useRef, useState } from "react";
import { getData, postData } from "../../../utils/api/core.js";
const ROOT = "/users/me/connector";
const normalize = value => String(value || "").trim().toLocaleLowerCase();
const errorText = error => typeof error.response?.data?.error === "string" ? error.response.data.error : "Could not complete the library action.";
const key = item => `${item.kind}:${item.id}`;
const findMatches = (owned, item) => {
  const linked = owned.filter(p => p.externalId === key(item));
  return linked.length ? linked : owned.filter(p => item.name !== "Apple Music playlist" && normalize(p.name) === normalize(item.name));
};
const comparisonText = comparison => `${comparison.matched} matched · ${comparison.probable} possible · ${comparison.missing} missing · ${comparison.ambiguous} review · ${comparison.localOnly} local additions`;
const imageStyle = { width: 64, height: 64, objectFit: "cover", borderRadius: 6 };
export function ConnectedLibrarySection({ service, onPreferencesChanged }) {
  const [open, setOpen] = useState(false), [playlists, setPlaylists] = useState([]), [groups, setGroups] = useState([]), [selected, setSelected] = useState(null);
  const [busy, setBusy] = useState(false), [message, setMessage] = useState(""), [query, setQuery] = useState("");
  const [inventory, setInventory] = useState([]), [comparisons, setComparisons] = useState({}), [restoreSelected, setRestoreSelected] = useState({});
  const stopScan = useRef(false), running = useRef(false);
  const base = `${ROOT}/services/${encodeURIComponent(service.id)}`;
  const get = path => getData(base + path, { timeout: 90000 });
  const post = (path, body) => postData(base + path, body, { timeout: 120000 });
  const run = async operation => {
    if (running.current) return;
    running.current = true; setBusy(true); setMessage("");
    try { await operation(); } catch (error) { setMessage(errorText(error)); }
    finally { running.current = false; setBusy(false); }
  };
  const loadLibrary = () => run(async () => {
    setOpen(true); setSelected(null); setGroups([]); setComparisons({}); setQuery("");
    const own = await get("/inventory"); setInventory(own.items);
    setPlaylists((await get("/library")).playlists);
  });
  const loadGroups = () => run(async () => {
    setOpen(true); setSelected(null); setPlaylists([]); setQuery("");
    const own = await get("/inventory"); setInventory(own.items);
    setGroups((await get("/groups")).groups);
  });
  // Keep the POC's distinction between a name match and compared tracks.
  const matchesFor = item => findMatches(inventory, item);
  const choose = item => run(async () => {
    const result = await get(`/playlists/${item.kind}/${encodeURIComponent(item.id)}`);
    setSelected(result); setRestoreSelected({});
    setComparisons(previous => ({ ...previous, [key(item)]: result }));
  });
  const scanInventory = () => run(async () => {
    stopScan.current = false; setOpen(true); setSelected(null); setComparisons({}); setQuery("");
    const own = (await get("/inventory")).items; setInventory(own);
    let failures = 0, compared = 0, personal = [], availableGroups = [];
    try { personal = (await get("/library")).playlists; } catch { failures++; }
    const all = new Map(personal.map(item => [key(item), item]));
    const personalNames = new Set(personal.filter(item => item.name !== "Apple Music playlist").map(item => normalize(item.name)));
    try { availableGroups = (await get("/groups")).groups; } catch { failures++; }
    setGroups(availableGroups);
    for (const group of availableGroups.slice(0, 20)) {
      if (stopScan.current) break;
      setMessage(`Scanning Apple recommendation groups… ${all.size} playlists found`);
      try {
        for (const item of (await get(`/groups/${encodeURIComponent(group.id)}`)).playlists) {
          if (!personalNames.has(normalize(item.name))) all.set(key(item), item);
        }
      } catch { failures++; }
    }
    const rows = [...all.values()].sort((a, b) => a.name.localeCompare(b.name)); setPlaylists(rows);
    const imported = rows.filter(item => findMatches(own, item).length);
    for (const item of imported.slice(0, 50)) {
      if (stopScan.current) break;
      setMessage(`Comparing ${compared + 1} of ${Math.min(imported.length, 50)} imported playlists…`);
      try {
        const result = await post("/compare", { kind: item.kind, id: item.id });
        setComparisons(previous => ({ ...previous, [key(item)]: result }));
      } catch { failures++; setComparisons(previous => ({ ...previous, [key(item)]: { failed: true } })); }
      compared++;
    }
    setMessage(`${stopScan.current ? "Scan stopped." : "Scan complete."} ${rows.length} discovered · ${imported.length} name matches · ${compared} compared. ${failures ? `${failures} requests failed; those results remain unverified.` : "No downloads were queued."}${availableGroups.length > 20 || imported.length > 50 ? " Scan limited to 20 groups and 50 imported playlists; open other playlists individually to compare them." : ""}`);
  });
  const seed = () => run(async () => {
    await post("/preferences", { kind: selected.source.kind, id: selected.source.id });
    setMessage("Saved as your recommendation source. No downloads were queued. Discovery refresh will use these artists."); onPreferencesChanged();
  });
  const addPlaylist = () => run(async () => {
    const result = await post("/import-playlist", { kind: selected.source.kind, id: selected.source.id, downloadMissing: true });
    setMessage(result.alreadyImported ? "This playlist is already in your Aurral library. Existing tracks and covers were preserved." : "Playlist import queued. Missing tracks will enter Aurral’s normal download pipeline.");
    setInventory((await get("/inventory")).items);
  });
  const changeExisting = (action, extra) => run(async () => {
    const count = Object.values(restoreSelected).filter(Boolean).length;
    if (!window.confirm(action === "artwork" ? "Replace this Aurral playlist’s current cover with the Apple playlist artwork?" : `Import ${count} selected missing tracks? This may queue downloads. Existing tracks and local additions will be preserved.`)) return;
    const result = await post(`/${action}`, { kind: selected.source.kind, id: selected.source.id, playlistId: selected.matches[0].id, fingerprint: selected.fingerprint, ...extra });
    setMessage(action === "artwork" ? "Apple playlist cover applied. No tracks changed or downloads queued." : `${result.count} missing tracks queued. Existing tracks and local additions were preserved.`);
    if (action !== "artwork") { setSelected(null); setRestoreSelected({}); setComparisons({}); }
  });
  const visible = playlists.filter(item => normalize(item.name).includes(normalize(query))).slice(0, 200);
  const indexes = Object.keys(restoreSelected).filter(index => restoreSelected[index]).map(Number);
  return <div>
    <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
      <button type="button" className="btn btn-secondary btn-sm" disabled={busy} onClick={loadLibrary}>Browse {service.name} playlists</button>
      <button type="button" className="btn btn-secondary btn-sm" disabled={busy} onClick={loadGroups}>Browse {service.name} recommendations</button>
      <button type="button" className="btn btn-secondary btn-sm" disabled={busy} onClick={scanInventory}>Scan &amp; Compare</button>
      {busy && <button type="button" className="btn btn-secondary btn-sm" onClick={() => { stopScan.current = true; }}>Stop scan after current request</button>}
    </div>
    {open && <div>
      <button type="button" className="btn btn-secondary btn-sm" disabled={busy} onClick={() => setOpen(false)}>Close browser</button>
      <p>Scan &amp; Compare checks your Apple playlists and recommendations against playlists in your Aurral account. Local additions stay untouched. A name match alone does not mean its tracks match.</p>
      <p>Use for recommendations saves the artists as your personal taste without downloading tracks. Adding or restoring playlist tracks is separate.</p>
      {groups.map(group => <button type="button" className="btn btn-secondary btn-sm" disabled={busy} key={group.id} onClick={() => run(async () => { setPlaylists((await get(`/groups/${encodeURIComponent(group.id)}`)).playlists); setSelected(null); setQuery(""); })}>{group.name}</button>)}
      {!!playlists.length && <label>Find a playlist <input className="arr-input" value={query} onChange={event => setQuery(event.target.value)} /></label>}
      <ul style={{ listStyle: "none", padding: 0 }}>{visible.map(item => {
        const result = comparisons[key(item)], matches = result?.matches || matchesFor(item);
        return <li key={key(item)} style={{ display: "flex", alignItems: "center", flexWrap: "wrap", gap: 10, padding: "10px 0", borderBottom: "1px solid var(--aurral-border)" }}>
          {item.artworkUrl && <img src={item.artworkUrl} alt="" style={imageStyle} loading="lazy" referrerPolicy="no-referrer" />}
          <button type="button" className="btn btn-secondary btn-sm" disabled={busy} onClick={() => choose(item)}>{item.name === "Apple Music playlist" ? `Unnamed Apple playlist (${item.id})` : item.name}</button>
          <span>{result?.failed ? "Comparison failed — unverified" : result?.comparison ? comparisonText(result.comparison) : matches.length > 1 ? "Multiple Aurral matches — review" : matches.length === 1 ? `Already imported — ${matches[0].trackCount} tracks; not compared` : "No existing import identified"}</span>
        </li>;
      })}</ul>
      {playlists.length > 200 && <p>Showing up to 200 matching playlists. Use Find to narrow the list.</p>}
      {selected && <div>
        <h4>{selected.source.name}</h4>
        {selected.source.artworkUrl && <img src={selected.source.artworkUrl} alt="Playlist artwork" width="160" height="160" referrerPolicy="no-referrer" />}
        {selected.source.artworkKind === "track-fallback" && <p>Apple did not provide a playlist cover; showing a track’s artwork.</p>}
        <p>{selected.tracks.length} tracks · {new Set(selected.tracks.map(track => track.artistName)).size} artists</p>
        <button type="button" className="btn btn-primary btn-sm" disabled={busy} onClick={seed}>Use for my recommendations</button>
        <button type="button" className="btn btn-secondary btn-sm" disabled={busy || !!selected.matches?.length || selected.source.name === "Apple Music playlist"} onClick={addPlaylist}>Add playlist and queue missing tracks</button>
        {selected.matches?.length > 1 && <p>Multiple existing Aurral playlists match. Review them before making changes.</p>}
        {selected.matches?.map(match => <p key={match.id}><a href={`/library/playlists/${encodeURIComponent(match.id)}`} target="_blank" rel="noopener noreferrer">View {match.name} in Aurral ({match.trackCount} tracks)</a></p>)}
        {selected.comparison && <div>
          <h4>Compared with your existing Aurral playlist</h4>
          <p>{comparisonText(selected.comparison)}</p>
          <p>Possible matches and tracks needing review are not offered for automatic restore. Local additions are preserved.</p>
          {selected.source.artworkKind === "playlist" && <button type="button" className="btn btn-secondary btn-sm" disabled={busy} onClick={() => changeExisting("artwork", { replaceArtwork: true })}>Use Apple cover for this Aurral playlist</button>}
          {!!selected.comparison.missing && <fieldset disabled={busy}>
            <legend>Select missing tracks to restore (maximum 50)</legend>
            {selected.comparison.details.filter(track => track.status === "missing").map(track => <label key={track.index} style={{ display: "block" }}><input type="checkbox" checked={!!restoreSelected[track.index]} onChange={event => setRestoreSelected(previous => ({ ...previous, [track.index]: event.target.checked }))} /> {track.artist} — {track.title}</label>)}
            <button type="button" className="btn btn-secondary btn-sm" disabled={!indexes.length || indexes.length > 50} onClick={() => changeExisting("restore-missing", { selectedIndexes: indexes, downloadMissing: true })}>Import selected missing tracks</button>
          </fieldset>}
        </div>}
        <details><summary>Preview tracks</summary><ol>{selected.tracks.slice(0, 100).map((track, index) => <li key={`${track.sourceTrackId}:${index}`}>{track.artistName} — {track.trackName}</li>)}</ol>{selected.tracks.length > 100 && <p>Showing the first 100 tracks. Comparisons and imports use the complete playlist.</p>}</details>
      </div>}
    </div>}
    {busy && <p role="status">Reading the selected source…</p>}
    {message && <p role="status">{message}</p>}
  </div>;
}
