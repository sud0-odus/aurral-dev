import test from 'node:test';import assert from 'node:assert/strict';import {mkdtemp,writeFile,readFile,rm} from 'node:fs/promises';import {tmpdir} from 'node:os';import path from 'node:path';
import {setupIsolatedBackend,cleanupIsolatedState} from '../helpers/backendTestHarness.js';
const[state,{dbOps},{playlistManager},{flowPlaylistConfig},{fetchAppleArtwork}]=await setupIsolatedBackend('connector-artwork','backend/db/helpers/index.js','backend/services/playlists/playlistManager.js','backend/services/playlists/flowPlaylistConfig.js','backend/services/connector/sourceArtwork.js');test.after(()=>cleanupIsolatedState(state));
const url='https://is1-ssl.mzstatic.com/image.jpg';
test('source artwork rejects foreign hosts and stops oversized images',async()=>{
 let calls=0;assert.equal(await fetchAppleArtwork('https://evil.invalid/x',async()=>{calls++;}),null);assert.equal(calls,0);
 await assert.rejects(fetchAppleArtwork(url,async(_url,options)=>{assert.equal(options.redirect,'error');assert.equal(options.headers,undefined);return new Response(new Uint8Array(4000001),{headers:{'Content-Type':'image/jpeg'}});}));
});
test('an existing uploaded cover prevents any Apple source artwork request',async t=>{
 const folder=await mkdtemp(path.join(tmpdir(),'source-art-'));t.after(()=>rm(folder,{recursive:true,force:true}));const file=path.join(folder,'custom.webp');await writeFile(file,'existing custom cover');
 dbOps.updateSettings({playlistArtwork:{style:'aurral'}});
 const manager=Object.create(playlistManager);manager.libraryRoot=folder;manager._getPlaylistBaseName=()=> 'fixture';manager._isArtworkGenerationSuppressed=async()=>false;manager.getArtworkContextForPlaylistId=()=>({title:'Fixture',kind:'static'});manager.resolveArtworkFile=async()=>({safePath:file});
 t.mock.method(flowPlaylistConfig,'getStaticPlaylist',()=>({importSource:{provider:'apple-playlist',artworkUrl:url}}));let requested=0;t.mock.method(globalThis,'fetch',async()=>{requested++;throw new Error('Must not fetch');});
 await manager._ensureFlowArtwork('id','Fixture','static');assert.equal(requested,0);assert.equal((await readFile(file)).toString(),'existing custom cover');
});
test('a new Apple playlist uses source artwork before generated artwork',async t=>{
 const folder=await mkdtemp(path.join(tmpdir(),'source-art-'));t.after(()=>rm(folder,{recursive:true,force:true}));
 const manager=Object.create(playlistManager);manager.libraryRoot=folder;manager._getPlaylistBaseName=()=> 'fixture';manager._isArtworkGenerationSuppressed=async()=>false;manager.getArtworkContextForPlaylistId=()=>({title:'Fixture',kind:'static'});manager.resolveArtworkFile=async()=>null;
 t.mock.method(flowPlaylistConfig,'getStaticPlaylist',()=>({importSource:{provider:'apple-playlist',artworkUrl:url}}));t.mock.method(globalThis,'fetch',async()=>new Response('fixture-image',{headers:{'Content-Type':'image/jpeg'}}));let saved;manager.saveArtworkUpload=async(_id,buffer)=>{saved=buffer;};
 await manager._ensureFlowArtwork('id','Fixture','static');assert.equal(saved.toString(),'fixture-image');
});
