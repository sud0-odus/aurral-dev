import test from 'node:test';import assert from 'node:assert/strict';import express from 'express';
import {setupIsolatedBackend,cleanupIsolatedState,resetDatabase} from '../helpers/backendTestHarness.js';
const [state,{db},{dbOps},handlers,tastes,{flowPlaylistConfig,invalidateFlowPlaylistConfigCache}]=await setupIsolatedBackend('connector-library-routes','backend/config/db-sqlite.js','backend/db/helpers/index.js','backend/routes/users/connectorLibraryHandlers.js','backend/services/connector/tasteSources.js','backend/services/playlists/flowPlaylistConfig.js');
let queued=[],refreshed=[],remoteTracks=null,artworkCalls=[];
const source=user=>({service:'apple',kind:'library',id:'p.shared-id',name:`User ${user} source`,artworkUrl:'https://is1-ssl.mzstatic.com/source.jpg',artworkKind:'playlist'});
const adapters=new Map([['apple',{read:async(_user,operation)=>operation(),create:user=>({context:{assertCurrent(){}},list:async()=>[source(user)],playlist:async()=>({source:source(user),tracks:remoteTracks||[{artistName:`User ${user} artist`,trackName:'Track',durationMs:200000,sourceService:'apple',sourceTrackId:'i.track'}]})})}]]);
const app=express();app.use(express.json());app.use((req,_res,next)=>{if(req.headers['x-user'])req.user={id:Number(req.headers['x-user'])};next();});
const router=express.Router();handlers.registerConnectorLibrary(router,{adapterRegistry:adapters,refresh:id=>refreshed.push(id),artwork:{fetch:async url=>{artworkCalls.push({url});return Buffer.from("image");},save:async(id,buffer)=>artworkCalls.push({id,length:buffer.length})},queue:{enqueuePayload:async payload=>{queued.push(payload);return{operationId:1};}}});app.use('/api/users',router);
const server=await new Promise(resolve=>{const s=app.listen(0,'127.0.0.1',()=>resolve(s));});const root=`http://127.0.0.1:${server.address().port}/api/users/me/connector`;
async function request(path,body,user=1,method=body?'POST':'GET'){const response=await fetch(root+path,{method,headers:{'Content-Type':'application/json',...(user?{'x-user':user}:{})},...(body?{body:JSON.stringify(body)}:{})});return{status:response.status,body:await response.json()};}
test.beforeEach(()=>{resetDatabase(db);dbOps.invalidateSettingsCache();invalidateFlowPlaylistConfigCache();queued=[];refreshed=[];remoteTracks=null;artworkCalls=[];});test.after(async()=>{await new Promise(resolve=>server.close(resolve));cleanupIsolatedState(state);});
test('metadata-only preference import is owner scoped, idempotent and never queues music',async()=>{
 const action='/services/apple/preferences';const result=await request(action,{kind:'library',id:'p.shared-id',userId:2});assert.equal(result.status,200);assert.equal(result.body.preferences.sources[0].name,'User 1 source');assert.equal(queued.length,0);assert.deepEqual(refreshed,[1]);
 assert.equal((await request(action,{kind:'library',id:'p.shared-id'})).body.changed,false);assert.deepEqual(refreshed,[1]);
 assert.equal((await request('/preferences',null,2)).body.sources.length,0);assert.equal(db.prepare('SELECT count(*) n FROM playlist_download_jobs').get().n,0);
 const key=result.body.preferences.sources[0].key;await request('/preferences/'+encodeURIComponent(key),null,2,'DELETE');assert.equal(tastes.publicTasteProfile(1).sources.length,1);
});
test('queueing a playlist requires explicit intent and preserves verified metadata/ownership',async()=>{
 assert.equal((await request('/services/apple/import-playlist',{kind:'library',id:'p.shared-id'})).status,400);assert.equal(queued.length,0);
 const result=await request('/services/apple/import-playlist',{kind:'library',id:'p.shared-id',downloadMissing:true,userId:2});assert.equal(result.status,200);assert.equal(queued[0].ownerUserId,1);assert.equal(queued[0].importSource.externalId,'library:p.shared-id');assert.equal(queued[0].tracks[0].durationMs,200000);assert.equal(queued[0].tracks[0].sourceTrackId,'i.track');assert.equal(queued[0].importSource.syncEnabled,false);
 await request('/services/apple/import-playlist',{kind:'library',id:'p.shared-id',downloadMissing:true});assert.equal(queued[0].playlistId,queued[1].playlistId);
});
test('previously imported Apple playlists and local additions are preserved instead of duplicated',async()=>{
 const existing=flowPlaylistConfig.createStaticPlaylist({name:'User 1 source',ownerUserId:1,sourceName:'Apple Music',tracks:[{artistName:'Local addition',trackName:'Keep this'}]});
 const result=await request('/services/apple/import-playlist',{kind:'library',id:'p.shared-id',downloadMissing:true});assert.equal(result.body.alreadyImported,true);assert.equal(result.body.playlistId,existing.id);assert.equal(queued.length,0);assert.equal(flowPlaylistConfig.getStaticPlaylist(existing.id).tracks[0].artistName,'Local addition');
});
test('library browsing requires a signed-in account',async()=>{assert.equal((await request('/services/apple/library',null,null)).status,401);assert.equal((await request('/preferences',null,-1)).status,403);});

test('comparison against the signed-in user’s existing import is read only and preserves local additions',async()=>{
 const existing=flowPlaylistConfig.createStaticPlaylist({name:'User 1 source',ownerUserId:1,sourceName:'Apple Music',tracks:[{artistName:'Local artist',trackName:'Local addition'}]});
 const compared=await request('/services/apple/compare',{kind:'library',id:'p.shared-id',userId:2});
 assert.equal(compared.status,200);assert.equal(compared.body.matches[0].id,existing.id);assert.equal(compared.body.comparison.missing,1);assert.equal(compared.body.comparison.localOnly,1);
 assert.equal(queued.length,0);assert.equal(refreshed.length,0);assert.equal(artworkCalls.length,0);
 assert.equal((await request('/services/apple/inventory',null,2)).body.items.length,0);
 const other=await request('/services/apple/compare',{kind:'library',id:'p.shared-id'},2);assert.equal(other.body.matches.length,0);assert.equal(other.body.comparison,null);
});
test('selective restore revalidates source, current membership, owner, and explicit download intent',async()=>{
 const existing=flowPlaylistConfig.createStaticPlaylist({name:'User 1 source',ownerUserId:1,sourceName:'Apple Music',tracks:[{artistName:'Local',trackName:'Keep'}]});
 const preview=(await request('/services/apple/compare',{kind:'library',id:'p.shared-id'})).body;
 const body={kind:'library',id:'p.shared-id',playlistId:existing.id,fingerprint:preview.fingerprint,selectedIndexes:[0],downloadMissing:true};
 assert.equal((await request('/services/apple/restore-missing',{...body,downloadMissing:false})).status,400);
 assert.equal((await request('/services/apple/restore-missing',body,2)).status,400);
 assert.equal((await request('/services/apple/restore-missing',{...body,selectedIndexes:[0,0]})).status,400);
 remoteTracks=[{artistName:'Changed',trackName:'Changed'}];assert.equal((await request('/services/apple/restore-missing',body)).status,400);remoteTracks=null;
 assert.equal(queued.length,0);
 assert.equal((await request('/services/apple/restore-missing',body)).status,200);assert.equal(queued.length,1);assert.equal(queued[0].kind,'shared-playlist-append-tracks');assert.equal(queued[0].ownerUserId,1);assert.equal(queued[0].tracks[0].durationMs,200000);
 flowPlaylistConfig.appendStaticPlaylistTracks(existing.id,[{artistName:'User 1 artist',trackName:'Track',albumName:'Different'}]);
 assert.equal((await request('/services/apple/restore-missing',body)).status,400);assert.equal(queued.length,1);
 assert.equal(flowPlaylistConfig.getStaticPlaylist(existing.id).tracks[0].trackName,'Keep');
});
test('applying source artwork requires an owned match, unchanged source and explicit replacement consent',async()=>{
 const existing=flowPlaylistConfig.createStaticPlaylist({name:'User 1 source',ownerUserId:1,sourceName:'Apple Music',tracks:[{artistName:'Local',trackName:'Keep'}]});
 const preview=(await request('/services/apple/compare',{kind:'library',id:'p.shared-id'})).body;
 const body={kind:'library',id:'p.shared-id',playlistId:existing.id,fingerprint:preview.fingerprint,replaceArtwork:true};
 assert.equal((await request('/services/apple/artwork',{...body,replaceArtwork:false})).status,400);
 assert.equal((await request('/services/apple/artwork',body,2)).status,400);assert.equal(artworkCalls.length,0);
 assert.equal((await request('/services/apple/artwork',body)).status,200);assert.equal(artworkCalls[1].id,existing.id);assert.equal(queued.length,0);assert.equal(refreshed.length,0);
 assert.equal(flowPlaylistConfig.getStaticPlaylist(existing.id).tracks[0].trackName,'Keep');
});
test('ambiguous legacy matches block duplicate imports and selective changes',async t=>{
 t.mock.method(flowPlaylistConfig,'getStaticPlaylistsOwnedByUser',()=>[1,2].map(i=>({id:String(i),name:'User 1 source',ownerUserId:1,sourceName:'Apple Music',tracks:[]})));
 const preview=(await request('/services/apple/compare',{kind:'library',id:'p.shared-id'})).body;
 assert.equal(preview.matches.length,2);assert.equal(preview.comparison,null);
 assert.equal((await request('/services/apple/import-playlist',{kind:'library',id:'p.shared-id',downloadMissing:true})).status,400);assert.equal(queued.length,0);
});
