import {chromium} from '/workspace/aurral-dev/node_modules/playwright/index.mjs';import assert from 'node:assert/strict';
const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
try{
 const context=await browser.newContext();let connected=true,sources=[],queueCalls=0,seedCalls=0;const errors=[];
 const source={service:'apple',kind:'library',id:'p.fixture',name:'Personal Apple Playlist',artworkUrl:'https://is1-ssl.mzstatic.com/source.jpg'};
 const tracks=[{artistName:'Personal Artist',trackName:'Personal Track',albumName:'Album',durationMs:200000,sourceTrackId:'i.track'}];
 const preferences=()=>({revision:String(seedCalls),artistCount:sources.length,sources});
 await context.route('https://*.mzstatic.com/**',route=>route.fulfill({status:200,contentType:'image/png',body:Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=','base64')}));
 await context.route('**/api/users/me/connector**',async route=>{
  const path=new URL(route.request().url()).pathname.split('/connector')[1];const method=route.request().method();let body;
  if(!path)body={devices:[{id:'fixture-device-12345678'}],services:connected?[{id:'apple'}]:[],available:[{id:'apple',name:'Apple Music',library:true}]};
  else if(path==='/preferences')body=preferences();
  else if(path==='/services/apple/inventory')body={items:[]};
  else if(path==='/services/apple/library')body={playlists:[source]};
  else if(path.includes('/playlists/'))body={source,tracks,matches:[],comparison:null,fingerprint:"fixture"};
  else if(path==='/services/apple/preferences'){const request=route.request().postDataJSON();assert.deepEqual(request,{kind:'library',id:'p.fixture'});seedCalls++;sources=[{...source,key:'apple:library:p.fixture',trackCount:1}];body={changed:true,preferences:preferences()};}
  else if(path==='/services/apple/import-playlist'){const request=route.request().postDataJSON();assert.equal(request.downloadMissing,true);queueCalls++;body={queued:true,playlistId:'fixture',operationId:1};}
  else if(path==='/services/apple'&&method==='DELETE'){connected=false;body={ok:true};}
  else if(path.startsWith('/preferences/')&&method==='DELETE'){sources=[];body=preferences();}
  else throw new Error('Unexpected API fixture path '+path);
  await route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(body)});
 });
 const page=await context.newPage();page.on('pageerror',error=>errors.push(error.message));await page.goto('http://127.0.0.1:4175/connector-preview.html');
 await page.getByRole('button',{name:'Browse Apple Music playlists',exact:true}).click();await page.getByRole('button',{name:'Personal Apple Playlist',exact:true}).click();
 await page.getByRole('button',{name:'Use for my recommendations',exact:true}).click();await page.getByText(/No downloads were queued/).waitFor();assert.equal(seedCalls,1);assert.equal(queueCalls,0);
 assert.equal(await page.locator('img[src="https://is1-ssl.mzstatic.com/source.jpg"]').count(),3);
 await page.getByRole('button',{name:'Add playlist and queue missing tracks',exact:true}).click();await page.getByText(/Playlist import queued/).waitFor();assert.equal(queueCalls,1);
 await page.getByRole('button',{name:'Disconnect',exact:true}).click();await page.getByText('Apple Music: Not connected').waitFor();assert.equal((await page.getByRole('button',{name:'Remove recommendation source',exact:true}).count()),1);
 await page.reload();await page.getByRole('button',{name:'Remove recommendation source',exact:true}).waitFor();assert.ok(await page.getByText('Personal Apple Playlist',{exact:false}).count());
 await page.getByRole('button',{name:'Remove recommendation source',exact:true}).click();await page.getByText('No imported sources yet.',{exact:false}).waitFor();assert.equal(queueCalls,1);assert.deepEqual(errors,[]);
 console.log('PASS: actual browser selects source artwork, saves metadata-only taste without acquisition, queues only on explicit action, retains preferences after disconnect/reload, and removes preferences independently. No page errors.');
}finally{await browser.close();}
