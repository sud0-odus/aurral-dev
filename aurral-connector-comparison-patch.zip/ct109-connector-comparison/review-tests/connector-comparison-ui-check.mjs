import {chromium} from '/workspace/aurral-dev/node_modules/playwright/index.mjs';import assert from 'node:assert/strict';
const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
try{
 const context=await browser.newContext();let queueCalls=0,artCalls=0,seedCalls=0,compareCalls=0,failGroups=false;const errors=[];
 const source={service:'apple',kind:'library',id:'p.fixture',name:'Existing Apple Playlist',artworkUrl:'https://is1-ssl.mzstatic.com/source.jpg',artworkKind:'playlist'};
 const tracks=[{artistName:'Personal Artist',trackName:'Existing Track',albumName:'Album',sourceTrackId:'one'},{artistName:'Personal Artist',trackName:'Missing Track',albumName:'Album',sourceTrackId:'two'}];
 const match={id:'existing',name:source.name,trackCount:2};
 const preview=()=>({source,tracks,matches:[match],fingerprint:'verified-source',comparison:{playlistId:'existing',matched:1,probable:0,missing:1,ambiguous:0,localOnly:1,details:[{index:0,artist:'Personal Artist',title:'Existing Track',status:'matched'},{index:1,artist:'Personal Artist',title:'Missing Track',status:'missing'}]}});
 await context.route('https://*.mzstatic.com/**',route=>route.fulfill({status:200,contentType:'image/png',body:Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=','base64')}));
 await context.route('**/api/users/me/connector**',async route=>{
  const path=new URL(route.request().url()).pathname.split('/connector')[1];let body;
  if(path==='/services/apple/groups'&&failGroups){await route.fulfill({status:400,contentType:'application/json',body:JSON.stringify({error:'Fixture unavailable'})});return;}
  if(!path)body={devices:[{id:'fixture-device-12345678'}],services:[{id:'apple'}],available:[{id:'apple',name:'Apple Music',library:true}]};
  else if(path==='/preferences')body={revision:'none',artistCount:0,sources:[]};
  else if(path==='/services/apple/library')body={playlists:[source]};
  else if(path==='/services/apple/inventory')body={items:[match]};
  else if(path==='/services/apple/groups')body={groups:[{id:'one',name:'Personal recommendations'}]};
  else if(path==='/services/apple/groups/one')body={playlists:[{...source,kind:'catalog',id:'pl.same'}]};
  else if(path.includes('/playlists/'))body=preview();
  else if(path==='/services/apple/compare'){compareCalls++;body=preview();}
  else if(path==='/services/apple/preferences'){seedCalls++;body={changed:true};}
  else if(path==='/services/apple/artwork'){const request=route.request().postDataJSON();assert.equal(request.replaceArtwork,true);assert.equal(request.playlistId,'existing');assert.equal(request.fingerprint,'verified-source');artCalls++;body={updated:true};}
  else if(path==='/services/apple/restore-missing'){const request=route.request().postDataJSON();assert.equal(request.downloadMissing,true);assert.deepEqual(request.selectedIndexes,[1]);assert.equal(request.fingerprint,'verified-source');queueCalls++;body={queued:true,count:1};}
  else throw new Error('Unexpected API fixture '+path);
  await route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(body)});
 });
 const page=await context.newPage();page.on('pageerror',error=>errors.push(error.message));page.on('dialog',dialog=>dialog.accept());await page.goto('http://127.0.0.1:4175/connector-preview.html');
 await page.getByRole('button',{name:'Scan & Compare',exact:true}).click();await page.getByText(/Scan complete/).waitFor();assert.equal(compareCalls,1);assert.equal(queueCalls,0);assert.equal(artCalls,0);
 await page.getByText('1 matched · 0 possible · 1 missing · 0 review · 1 local additions',{exact:true}).waitFor();
 await page.getByRole('button',{name:source.name,exact:true}).click();await page.getByRole('heading',{name:'Compared with your existing Aurral playlist'}).waitFor();
 assert.equal(await page.getByRole('button',{name:'Add playlist and queue missing tracks'}).isDisabled(),true);
 await page.getByRole('button',{name:'Use for my recommendations'}).click();await page.getByText(/Saved as your recommendation source/).waitFor();assert.equal(seedCalls,1);assert.equal(queueCalls,0);
 await page.getByRole('button',{name:'Use Apple cover for this Aurral playlist'}).click();await page.getByText(/Apple playlist cover applied/).waitFor();assert.equal(artCalls,1);assert.equal(queueCalls,0);
 assert.equal(await page.getByRole('checkbox').count(),1);await page.getByRole('checkbox').check();await page.getByRole('button',{name:'Import selected missing tracks'}).click();await page.getByText(/1 missing tracks queued/).waitFor();assert.equal(queueCalls,1);
 failGroups=true;await page.getByRole('button',{name:'Scan & Compare',exact:true}).click();await page.getByText(/1 requests failed; those results remain unverified/).waitFor();assert.equal(await page.getByRole('button',{name:source.name,exact:true}).count(),1);assert.equal(queueCalls,1);assert.deepEqual(errors,[]);
 console.log('PASS: real browser Scan & Compare reads existing import without acquisition, shows track differences/local additions, blocks duplicate Add, saves taste separately, explicitly applies cover and restores only selected missing track. No page errors.');
}finally{await browser.close();}
