import test from 'node:test';
import assert from 'node:assert/strict';
import {comparePlaylist,importedMatches,sourceFingerprint} from '../../backend/services/connector/playlistComparison.js';
const track=(title,album='Album')=>({artistName:'Artist',trackName:title,albumName:album});
test('POC comparison distinguishes exact, possible, missing, ambiguous and local additions',()=>{
 const target={id:'existing',tracks:[track('Exact'),track('Possible','Different'),track('Ambiguous','A'),track('Ambiguous','B'),track('Local')]};
 const result=comparePlaylist(target,[track('Exact'),track('Possible'),track('Missing'),track('Ambiguous'),{artistName:'Artist'}]);
 assert.deepEqual([result.matched,result.probable,result.missing,result.ambiguous,result.localOnly],[1,1,1,2,3]);
 assert.deepEqual(result.details.map(t=>t.status),['matched','possible-match','missing','needs-review','needs-review']);
 assert.equal(target.tracks.length,5);
});
test('a repeated remote track is review rather than missing when its local copy was already consumed',()=>{
 assert.deepEqual(comparePlaylist({tracks:[track('One')]},[track('One'),track('One')]).details.map(t=>t.status),['matched','needs-review']);
});
test('identity match precedes legacy names and unnamed resources never match by generic name',()=>{
 const owned=[{id:'linked',name:'Renamed',importSource:{provider:'apple-playlist',externalId:'library:p.one'}},{id:'legacy',name:'Original',sourceName:'Apple Music'}];
 assert.equal(importedMatches(owned,{kind:'library',id:'p.one',name:'Original'})[0].id,'linked');
 assert.equal(importedMatches(owned,{kind:'library',id:'p.other',name:' ORIGINAL '})[0].id,'legacy');
 assert.equal(importedMatches([{name:'Apple Music playlist',sourceName:'Apple Music'}],{name:'Apple Music playlist'}).length,0);
});
test('fingerprint changes on source/track changes so stale selections cannot restore a different track',()=>{
 const data={source:{service:'apple',kind:'library',id:'p.one'},tracks:[track('One')]};
 assert.equal(sourceFingerprint(data),sourceFingerprint(structuredClone(data)));
 assert.notEqual(sourceFingerprint(data),sourceFingerprint({...data,tracks:[track('Two')]}));
});
