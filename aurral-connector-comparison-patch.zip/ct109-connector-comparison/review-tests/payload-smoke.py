import argparse,importlib.util,sqlite3,tempfile,types,shutil,json
from pathlib import Path
from unittest.mock import patch
root=Path('/workspace/ct109-connector-comparison');spec=importlib.util.spec_from_file_location('installer',root/'apply-patch.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as directory:
 base=Path(directory);app=base/'app';app.mkdir();old=Path('/tmp/connector-comparison-before')
 for item in m.MANIFEST['files']:
  if item['before_sha256'] is None:continue
  target=app/item['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((old/item['path']).read_bytes())
 shutil.copytree('/workspace/ct109-connector-library/frontend-dist',app/'frontend/dist');before=m.tree_digest(app/'frontend/dist')
 db=base/'aurral.db'
 with sqlite3.connect(db) as con:
  con.execute('CREATE TABLE settings(key TEXT,value TEXT)');con.executemany('INSERT INTO settings VALUES (?,?)',[('browserConnectorV1','fixture-existing-pairings'),('personalTasteSourcesV1:1','fixture-saved-taste')])
 args=argparse.Namespace(app_dir=app,db=db,backup_dir=base/'backups',state=base/'state',health_url='http://unused')
 active=True
 def ctl(*commands):
  global active
  if commands[0]=='stop':active=False
  if commands[0]=='start':active=True
  return types.SimpleNamespace(returncode=(0 if active else 3) if commands[0]=='is-active' else 0)
 with patch.object(m,'systemctl',side_effect=ctl),patch.object(m,'healthy',return_value=True):
  m.install(args);m.enable(args)
  with sqlite3.connect(db) as con:con.execute("INSERT INTO settings VALUES ('new-completed-work','preserved')")
  m.rollback(args)
 for item in m.MANIFEST['files']:
  target=app/item['path']
  if item['before_sha256'] is None:assert not target.exists()
  else:assert target.read_bytes()==(old/item['path']).read_bytes()
 assert m.tree_digest(app/'frontend/dist')==before
 with sqlite3.connect(db) as con:assert dict(con.execute('SELECT key,value FROM settings'))=={'browserConnectorV1':'fixture-existing-pairings','personalTasteSourcesV1:1':'fixture-saved-taste','new-completed-work':'preserved'}
 print('PASS: actual six-file/frontend install/enable/rollback preserves pairings, saved taste and new database work, restores prior sources/UI, removes only new code.')
