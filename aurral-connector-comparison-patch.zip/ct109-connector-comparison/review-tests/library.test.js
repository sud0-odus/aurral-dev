import test from 'node:test';import assert from 'node:assert/strict';
import {setupIsolatedBackend,cleanupIsolatedState,resetDatabase} from '../helpers/backendTestHarness.js';
const [state,{db},{dbOps},store,library,tastes,feedback,flow] = await setupIsolatedBackend('connector-library','backend/config/db-sqlite.js','backend/db/helpers/index.js','backend/services/connector/store.js','backend/services/connector/appleLibrary.js','backend/services/connector/tasteSources.js','backend/services/discovery/feedback.js','backend/services/playlists/flowPlaylistConfig.js');
test.after(()=>cleanupIsolatedState(state));test.beforeEach(()=>{resetDatabase(db);dbOps.invalidateSettingsCache();for(const user of [1,2]){store.pairDevice(user,'test-browser-12345678');store.saveSession(user,'test-browser-12345678','apple',{session:`private-${user}`},null);}});
const image='https://is1-ssl.mzstatic.com/image/thumb/fixture/{w}x{h}bb.jpg';
const source={service:'apple',kind:'library',id:'p.fixture',name:'Personal playlist',artworkUrl:'https://is1-ssl.mzstatic.com/cover.jpg'};
const track={id:'i.song',type:'library-songs',attributes:{name:'Personal song',artistName:'Personal artist',albumName:'Personal album',durationInMillis:213456,artwork:{url:image}}};
test('library preview preserves source IDs, duration and source artwork across pages',async()=>{
 const calls=[];const client=library.createAppleLibrary(1,{request:async(path,session)=>{calls.push({path,session});if(!path.includes('/tracks'))return{data:[{id:'p.fixture',attributes:{name:'Personal playlist',artwork:{url:image}}}]};return path.includes('offset=')?{data:[{...track,id:'i.second'}]}:{data:[track],next:'/v1/me/library/playlists/p.fixture/tracks?offset=1&limit=100'};}});
 const result=await client.playlist('library','p.fixture');assert.equal(result.tracks.length,2);assert.equal(result.tracks[0].sourceTrackId,'i.song');assert.equal(result.tracks[0].durationMs,213456);assert.match(result.source.artworkUrl,/600x600/);assert.ok(calls.every(call=>call.session==='private-1'));
 assert.equal(tastes.publicTasteProfile(1).sources.length,0);assert.equal(db.prepare('SELECT count(*) n FROM playlist_download_jobs').get().n,0);
});
test('unexpected, looping or changed-session pagination never returns partial results',async()=>{
 for(const next of ['https://evil.invalid/steal','https://amp-api.music.apple.com/v1/me/recommendations','/v1/me/library/playlists?limit=50']){
  let calls=0;await assert.rejects(library.applePages('/v1/me/library/playlists?limit=50',library.librarySession(1),{request:async()=>{calls++;return{data:[{id:'one'}],next};}}));assert.equal(calls,1);
 }
 let calls=0;await assert.rejects(library.applePages('/v1/me/library/playlists?limit=50',library.librarySession(1),{request:async()=>{calls++;store.revoke(1,null,'apple');return{data:[],next:'/v1/me/library/playlists?offset=50'};}}));assert.equal(calls,1);
});
test('catalog recommendation playlists use the signed-in storefront, not a hardcoded country',async()=>{
 const paths=[];const client=library.createAppleLibrary(1,{request:async path=>{paths.push(path);if(path==='/v1/me/storefront')return{data:[{id:'gb'}]};if(path.includes('/tracks'))return{data:[track]};return{data:[{id:'pl.fixture',attributes:{name:'Recommended',artwork:{url:image}}}]};}});
 await client.playlist('catalog','pl.fixture');assert.ok(paths.includes('/v1/catalog/gb/playlists/pl.fixture'));assert.ok(!paths.some(path=>path.includes('/us/')));
});
test('missing or incomplete track metadata blocks import rather than accepting partial taste',async()=>{
 const client=library.createAppleLibrary(1,{request:async path=>path.includes('/tracks')?{data:[track,{id:'broken',attributes:{name:'No artist'}}]}:{data:[{id:'p.fixture',attributes:{name:'Incomplete'}}]}});
 await assert.rejects(client.playlist('library','p.fixture'),error=>error.code==='APPLE_TRACK_METADATA_INVALID');assert.equal(tastes.publicTasteProfile(1).sources.length,0);
});
test('taste sources are durable, idempotent, account-scoped and do not queue downloads',()=>{
 const tracks=[{artistName:'Wife artist',trackName:'Song'}];const first=tastes.upsertTasteSource(1,source,tracks);const revision=tastes.tasteRevision(1);
 assert.equal(first.changed,true);assert.equal(tastes.upsertTasteSource(1,source,tracks).changed,false);assert.equal(tastes.tasteRevision(1),revision);
 tastes.upsertTasteSource(2,source,[{artistName:'Other artist',trackName:'Other song'}]);
 feedback.addDiscoveryFeedback(1,{artistName:'More artist',action:'more_like_this'});feedback.resetDiscoveryFeedback(1);db.prepare('DELETE FROM discovery_cache').run();
 assert.equal(tastes.tasteArtists(1)[0].artistName,'Wife artist');assert.equal(tastes.tasteArtists(2)[0].artistName,'Other artist');assert.equal(tastes.tasteArtists(1)[0].playcount,undefined);
 assert.ok(!JSON.stringify(dbOps.getSettings()).includes('Wife artist'));
 assert.equal(db.prepare('SELECT count(*) n FROM playlist_download_jobs').get().n,0);
 tastes.removeTasteSource(1,tastes.tasteSourceKey(source));assert.equal(tastes.tasteArtists(1).length,0);assert.equal(tastes.tasteArtists(2).length,1);
});
test('static playlist track and import normalization preserve Apple evidence without enabling sync',()=>{
 const normalized=flow.normalizePlaylistTrack({...library.playlistMetadata({id:'p.fixture',attributes:{}},'library'),artistName:'Artist',trackName:'Track',sourceService:'apple',sourceTrackId:'i.song',artworkUrl:image,durationMs:123000});
 assert.equal(normalized.sourceTrackId,'i.song');assert.equal(normalized.durationMs,123000);assert.match(normalized.artworkUrl,/600x600/);
 const imported=flow.normalizeImportSource({provider:'apple-playlist',externalId:'library:p.fixture',artworkUrl:image,syncEnabled:false});assert.equal(imported.syncEnabled,false);assert.match(imported.artworkUrl,/600x600/);
});

test('artwork/name-only changes and additional tracks above the taste cap do not invalidate recommendations',()=>{
 const tracks=Array.from({length:6},(_,i)=>({artistName:'One artist',trackName:`Track ${i}`}));tastes.upsertTasteSource(1,source,tracks);const revision=tastes.tasteRevision(1);
 const metadata=tastes.upsertTasteSource(1,{...source,name:'Renamed source',artworkUrl:'https://is1-ssl.mzstatic.com/new.jpg'},[...tracks,{artistName:'One artist',trackName:'Another'}]);
 assert.equal(metadata.changed,true);assert.equal(metadata.tasteChanged,false);assert.equal(tastes.tasteRevision(1),revision);
});

test('POC title fallback supports localized playlist titles and track titles',()=>{
 assert.equal(library.playlistMetadata({id:'p.title',attributes:{title:{stringForDisplay:'Actual playlist'}}},'library').name,'Actual playlist');
});
