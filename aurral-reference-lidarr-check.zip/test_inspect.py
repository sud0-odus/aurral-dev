import importlib.util
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).parent

def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

class InspectTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db = Path(self.temp.name) / 'test.db'
        con = sqlite3.connect(self.db)
        con.executescript('''CREATE TABLE settings(key TEXT, value TEXT);
        CREATE TABLE playlist_download_jobs(id TEXT, download_source TEXT, duration_ms INTEGER,
          artist_mbid TEXT, album_mbid TEXT, release_mbid TEXT, track_mbid TEXT, track_name TEXT,
          status TEXT, error TEXT);
        CREATE TABLE metadata_response_cache(cache_key TEXT, response TEXT);
        CREATE TABLE metadata_provider_budget(forbidden_until INTEGER, rate_limited_until INTEGER);''')
        con.execute('INSERT INTO settings VALUES (?,?)', ('integrations', json.dumps({
            'lastfm': {'apiKey': 'SECRET_LASTFM'},
            'lidarr': {'enabled': True, 'url': 'http://private-lidarr:8686', 'apiKey': 'SECRET_LIDARR'}})))
        con.execute('INSERT INTO playlist_download_jobs VALUES (?,?,?,?,?,?,?,?,?,?)',
            ('private-job', 'ytdlp', None, 'artist-id', 'album-id', 'release-id', 'recording-id',
             'PRIVATE TRACK TITLE', 'blocked', 'downloaded file has no comparable length'))
        con.execute('INSERT INTO metadata_response_cache VALUES (?,?)', ('url/album/album-id', json.dumps({
            'tracks': [{'recordingid': 'recording-id', 'durationMs': 123456},
                       {'title': 'PRIVATE TRACK TITLE', 'durationms': 123450},
                       {'title': 'Other track', 'durationms': 999999}]})))
        con.commit()
        con.close()
        self.before = self.db.read_bytes()

    def test_duration_catalog_evidence_privacy_and_read_only(self):
        result = load('inspect-duration').inspect(self.db)
        self.assertTrue(result['lastfm_api_key_present'])
        self.assertEqual(result['job_count'], 1)
        job = result['jobs'][0]
        self.assertIsNone(job['requested_ms'])
        self.assertTrue(job['has_recording_id'])
        self.assertCountEqual(job['matching_cached_track_lengths'],
                              [{'durationMs': 123456}, {'durationms': 123450}])
        encoded = json.dumps(result)
        for secret in ['SECRET_LASTFM', 'SECRET_LIDARR', 'private-lidarr', 'PRIVATE TRACK TITLE',
                       'private-job', 'recording-id', '999999']:
            self.assertNotIn(secret, encoded)
        self.assertEqual(self.db.read_bytes(), self.before)

    def test_lidarr_uses_get_and_redacts_credentials(self):
        module = load('inspect-lidarr')
        endpoints = []
        payloads = {'system/status': {'version': '2.0'}, 'rootfolder': [{'path': '/nonexistent'}],
                    'downloadclient': [{'implementation': 'SABnzbd', 'enable': True, 'fields': ['SECRET_FIELDS']}],
                    'indexer': [], 'qualityprofile': [{}]}
        class Response:
            def __init__(self, payload): self.payload = payload
            def __enter__(self): return self
            def __exit__(self, *args): pass
            def read(self, limit): return json.dumps(self.payload).encode()
        class Opener:
            def open(self, request, timeout):
                self_method = request.get_method()
                if self_method != 'GET': raise AssertionError(self_method)
                endpoint = request.full_url.split('/api/v1/')[1]
                endpoints.append(endpoint)
                return Response(payloads[endpoint])
        with patch.object(module.urllib.request, 'build_opener', return_value=Opener()):
            result = module.inspect(self.db)
        self.assertEqual(len(endpoints), 5)
        self.assertEqual(result['lidarr_version'], '2.0')
        for secret in ['SECRET_LIDARR', 'SECRET_FIELDS', 'private-lidarr']:
            self.assertNotIn(secret, json.dumps(result))
        self.assertEqual(self.db.read_bytes(), self.before)

    def test_missing_database_is_not_created(self):
        missing = self.db.parent / 'missing.db'
        for name in ['inspect-duration', 'inspect-lidarr']:
            with self.assertRaises(sqlite3.OperationalError): load(name).inspect(missing)
        self.assertFalse(missing.exists())

if __name__ == '__main__': unittest.main()
