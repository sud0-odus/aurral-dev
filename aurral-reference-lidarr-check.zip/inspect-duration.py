#!/usr/bin/env python3
"""Read-only requested-duration diagnosis; exports no track names, URLs, keys or raw payloads."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3
import subprocess
import time


def positive(value):
    try:
        value = float(value)
        return round(value) if math.isfinite(value) and value > 0 else None
    except (ValueError, TypeError):
        return None


def walk(value):
    pending = [value]
    while pending:
        current = pending.pop()
        if isinstance(current, dict):
            yield current
            pending.extend(current.values())
        elif isinstance(current, list):
            pending.extend(current)


def inspect(database):
    con = sqlite3.connect(database.resolve().as_uri() + '?mode=ro', uri=True, timeout=2)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA query_only=ON')
    try:
        row = con.execute('SELECT value FROM settings WHERE key=?', ('integrations',)).fetchone()
        integrations = json.loads(row['value']) if row else {}
        lastfm = integrations.get('lastfm', {})
        configured = bool(lastfm.get('apiKey'))
        if not configured:
            try:
                pid = subprocess.run(['systemctl', 'show', 'aurral.service', '-p', 'MainPID', '--value'],
                    capture_output=True, text=True, timeout=2).stdout.strip()
                if pid.isdigit() and int(pid) > 0:
                    configured = any(field.startswith(b'LASTFM_API_KEY=') and field.split(b'=', 1)[1]
                        for field in Path('/proc', pid, 'environ').read_bytes().split(b'\0'))
            except (OSError, subprocess.TimeoutExpired):
                pass
        output = {'read_only': True, 'lastfm_api_key_present': configured,
                  'jobs': [], 'metadata_cooldown_active': False}
        tables = {row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if 'metadata_provider_budget' in tables:
            now = int(time.time()*1000)
            output['metadata_cooldown_active'] = bool(con.execute(
                'SELECT 1 FROM metadata_provider_budget WHERE forbidden_until>? OR rate_limited_until>? LIMIT 1', (now, now)
            ).fetchone())
        rows = con.execute('''SELECT id, download_source, duration_ms, artist_mbid, album_mbid,
            release_mbid, track_mbid, track_name FROM playlist_download_jobs
            WHERE status='blocked' AND (error LIKE '%comparable length%' OR error LIKE '%requested recording length%')
            LIMIT 100''').fetchall()
        for row in rows:
            item = {'job': hashlib.sha256(('aurral-baseline:'+row['id']).encode()).hexdigest()[:20],
                    'source': row['download_source'], 'requested_ms': positive(row['duration_ms']),
                    'has_artist_id': bool(row['artist_mbid']), 'has_album_id': bool(row['album_mbid']),
                    'has_release_id': bool(row['release_mbid']), 'has_recording_id': bool(row['track_mbid']),
                    'album_cached': False, 'matching_cached_track_lengths': []}
            if row['album_mbid'] and 'metadata_response_cache' in tables:
                cached = con.execute('SELECT response FROM metadata_response_cache WHERE instr(cache_key, ?) > 0 AND length(response)<=2097152 LIMIT 3',
                    ('/album/'+row['album_mbid'],)).fetchall()
                item['album_cached'] = bool(cached)
                wanted_title = re.sub(r'\W+', '', (row['track_name'] or '').casefold())
                for entry in cached:
                    try:
                        payload = json.loads(entry['response'])
                    except (TypeError, ValueError, RecursionError):
                        continue
                    for track in walk(payload):
                        title = track.get('trackname') or track.get('title')
                        same_id = bool(row['track_mbid']) and row['track_mbid'] == (track.get('recordingid') or track.get('recordingId'))
                        same_title = isinstance(title, str) and re.sub(r'\W+', '', title.casefold()) == wanted_title
                        if same_id or same_title:
                            lengths = {key: positive(track[key]) for key in ['durationms', 'durationMs', 'length', 'duration']
                                       if key in track and positive(track[key]) is not None}
                            if lengths and lengths not in item['matching_cached_track_lengths']:
                                item['matching_cached_track_lengths'].append(lengths)
                item['matching_cached_track_lengths'] = item['matching_cached_track_lengths'][:10]
            output['jobs'].append(item)
        output['job_count'] = len(output['jobs'])
        output['note'] = 'Cached title matches are diagnostic hints, not proof of recording identity. Duration units follow their original field; no values were applied.'
        return output
    finally:
        con.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', type=Path, default=Path('/opt/aurral_data/aurral.db'))
    args = parser.parse_args()
    try:
        print(json.dumps(inspect(args.db), indent=2))
    except (sqlite3.Error, OSError, ValueError, TypeError):
        print(json.dumps({'read_only': True, 'error': 'Could not inspect requested metadata; no changes made.'}))
