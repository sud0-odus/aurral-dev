Aurral requested-duration and existing Lidarr check

Run inside CT109:
python3 inspect-duration.py
python3 inspect-lidarr.py

No installation, service restart, queue changes or profiling.
The duration check opens SQLite read-only, checks existing metadata cache and
only tests whether a Last.fm API key is present. It does not export keys,
track names, catalog IDs, raw cache data or environment variables.
The Lidarr check reads saved integration settings and makes GET requests to
its existing API. It exports root paths, version and enabled client types,
without credentials or full integration configuration. Redirects are refused.
Folder existence alone cannot establish shared-file access.

Tested with three synthetic database/privacy/read-only checks.
This diagnostic package does not include or install the next application patch.
