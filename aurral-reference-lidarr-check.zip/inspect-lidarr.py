#!/usr/bin/env python3
"""Read-only inventory of Aurral's existing Lidarr connection; never prints credentials."""
import argparse
import json
from pathlib import Path
import sqlite3
import urllib.request
import urllib.error
import urllib.parse


def inspect(database):
    con = sqlite3.connect(database.resolve().as_uri() + '?mode=ro', uri=True, timeout=2)
    try:
        row = con.execute('SELECT value FROM settings WHERE key=?', ('integrations',)).fetchone()
        integrations = json.loads(row[0]) if row else {}
        config = integrations.get('lidarr', {})
    finally:
        con.close()
    output = {'read_only': True, 'enabled': config.get('enabled') is True,
              'configured': bool(config.get('url') and config.get('apiKey'))}
    if not output['configured']:
        output['note'] = 'No complete saved connection. Environment-based credentials are not inspected.'
        return output
    base = str(config['url']).strip().rstrip('/')
    parsed = urllib.parse.urlsplit(base)
    if parsed.scheme not in {'http', 'https'} or not parsed.hostname:
        output['note'] = 'Saved Lidarr URL is invalid.'
        return output

    # Do not forward an API key to a different location through a redirect.
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None

    opener = urllib.request.build_opener(NoRedirect)

    def get(endpoint):
        request = urllib.request.Request(base + '/api/v1/' + endpoint,
            headers={'X-Api-Key': str(config['apiKey']), 'Accept': 'application/json'})
        try:
            with opener.open(request, timeout=5) as response:
                data = response.read(2 * 1024 * 1024 + 1)
                if len(data) > 2 * 1024 * 1024:
                    return {'read_failed': 'response too large'}
                return json.loads(data)
        except urllib.error.HTTPError as error:
            return {'read_failed_http_status': error.code}
        except (OSError, ValueError):
            return {'read_failed': 'connection or JSON response failed'}

    status = get('system/status')
    output['lidarr_version'] = status.get('version') if isinstance(status, dict) else None
    if isinstance(status, dict) and any(key.startswith('read_failed') for key in status):
        output['connection_result'] = status
        return output
    folders = get('rootfolder')
    output['root_folders'] = [{'path': folder.get('path'),
        'exists_in_ct109': Path(str(folder.get('path') or '/nonexistent')).is_dir(),
        'accessible_reported_by_lidarr': folder.get('accessible'),
        'free_space_bytes_reported_by_lidarr': folder.get('freeSpace')}
        for folder in folders] if isinstance(folders, list) else folders
    for endpoint in ['downloadclient', 'indexer']:
        values = get(endpoint)
        output[endpoint + 's'] = [{'implementation': value.get('implementation'),
            'enabled': value.get('enable')} for value in values] if isinstance(values, list) else values
    profiles = get('qualityprofile')
    output['quality_profile_count'] = len(profiles) if isinstance(profiles, list) else profiles
    output['note'] = 'No changes made. Folder existence is not proof of matching media content or app-user permissions.'
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', type=Path, default=Path('/opt/aurral_data/aurral.db'))
    args = parser.parse_args()
    try:
        print(json.dumps(inspect(args.db), indent=2))
    except (sqlite3.Error, OSError, ValueError, TypeError):
        print(json.dumps({'read_only': True, 'error': 'Could not read the saved Lidarr connection; no changes made.'}))
