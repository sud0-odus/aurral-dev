#!/usr/bin/env python3
"""Update only the existing hosted Apple browser; preserve pairing and Aurral."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import ssl
import subprocess
import sys
import tempfile
import time
import urllib.request

KIT = Path(__file__).resolve().parent
MANIFEST = json.loads((KIT/'manifest.json').read_text())
SERVICE = 'aurral-apple-browser.service'

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def service(*args):
    return subprocess.run(['systemctl', *args, SERVICE], capture_output=True, timeout=90)
def atomic_copy(source, target):
    metadata = target.stat()
    fd, temporary = tempfile.mkstemp(prefix='.capture-', dir=target.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(source.read_bytes());handle.flush();os.fsync(handle.fileno())
        os.chmod(temporary, metadata.st_mode & 0o777)
        os.chown(temporary, metadata.st_uid, metadata.st_gid)
        os.replace(temporary, target)
    finally:
        if os.path.exists(temporary):os.unlink(temporary)
def check(args, expected):
    if digest(KIT/'bridge.py') != MANIFEST['after_sha256']:
        raise RuntimeError('Patch payload checksum mismatch.')
    compile((KIT/'bridge.py').read_text(), 'bridge.py', 'exec')
    target=args.root/'bridge.py'
    if target.is_symlink() or not target.is_file() or digest(target) != expected:
        raise RuntimeError('Installed browser differs from the expected version. No files replaced.')
    return target
def healthy(config_file):
    config=json.loads(config_file.read_text())
    context=ssl.create_default_context(cafile=config['caFile'])
    key=Path(config['keyFile']).read_text().strip()
    request=urllib.request.Request(config['url'].rstrip('/')+'/v1/users/1/status',headers={'Authorization':'Bearer '+key})
    with urllib.request.urlopen(request,context=context,timeout=3) as response:
        return response.status==200 and json.load(response).get('configured') is True
def start_and_check(args):
    if service('start').returncode:
        raise RuntimeError('Browser service did not start. Use --rollback.')
    for _ in range(15):
        try:
            if service('is-active','--quiet').returncode==0 and healthy(args.config):return
        except (OSError, ValueError):pass
        time.sleep(1)
    service('stop')
    raise RuntimeError('Browser health check failed; browser stopped. Use --rollback.')
def install(args):
    target=check(args,MANIFEST['before_sha256'])
    if args.state.exists():raise RuntimeError('An install marker already exists; do not reinstall.')
    if not args.config.is_file():raise RuntimeError('Existing Apple browser pairing configuration is missing.')
    if service('stop').returncode or service('is-active','--quiet').returncode==0:
        raise RuntimeError('Could not stop the Apple browser. No files replaced.')
    args.backups.mkdir(mode=0o700,parents=True,exist_ok=True)
    backup=Path(tempfile.mkdtemp(prefix='apple-stream-browser-',dir=args.backups));os.chmod(backup,0o700)
    shutil.copy2(target,backup/'bridge.py')
    state={'patch':MANIFEST['patch'],'backup':str(backup),'root':str(args.root.resolve())}
    # Save recovery instructions before replacing code.
    with args.state.open('x') as handle:
        os.chmod(args.state,0o600);json.dump(state,handle)
    atomic_copy(KIT/'bridge.py',target)
    start_and_check(args)
    print('PASS: Apple browser updated and authenticated HTTPS health check passed.')
    print('Close the old sign-in popup, then click Connect Apple Music again.')
    print('Aurral was not restarted. Database, pairing, keys and resource limits were preserved.')
def rollback(args):
    state=json.loads(args.state.read_text())
    if state.get('patch')!=MANIFEST['patch'] or state.get('root')!=str(args.root.resolve()):raise RuntimeError('Install marker mismatch.')
    target=check(args,MANIFEST['after_sha256'])
    backup=Path(state['backup'])/'bridge.py'
    if digest(backup)!=MANIFEST['before_sha256']:raise RuntimeError('Backup checksum mismatch.')
    if service('stop').returncode or service('is-active','--quiet').returncode==0:raise RuntimeError('Could not stop browser.')
    atomic_copy(backup,target)
    start_and_check(args)
    print('PASS: previous Apple browser restored and healthy. Aurral was not restarted.')
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    action=parser.add_mutually_exclusive_group(required=True)
    for name in ['check','install','rollback']:action.add_argument('--'+name,action='store_true')
    parser.add_argument('--root',type=Path,default=Path('/opt/aurral-apple-browser'))
    parser.add_argument('--config',type=Path,default=Path('/opt/aurral_data/apple-browser/config.json'))
    parser.add_argument('--state',type=Path,default=Path('/opt/aurral-apple-stream-browser-patch.json'))
    parser.add_argument('--backups',type=Path,default=Path('/opt/aurral-patch-backups'))
    args=parser.parse_args()
    if args.check:
        check(args,MANIFEST['before_sha256']);print('PASS: expected Apple browser and patch payload match. No changes made.');return
    if os.geteuid()!=0:raise RuntimeError('Run inside CT109 as root.')
    if args.install:install(args)
    else:rollback(args)
if __name__=='__main__':
    try:main()
    except Exception as error:
        # Never include HTTP bodies, pairing values or credential paths in errors.
        print('STOPPED: '+(str(error) if isinstance(error,RuntimeError) else type(error).__name__),file=sys.stderr)
        sys.exit(1)
