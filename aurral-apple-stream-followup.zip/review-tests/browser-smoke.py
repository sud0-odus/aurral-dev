import base64,importlib.util,os,time,signal,io
from PIL import Image
from pathlib import Path
s=importlib.util.spec_from_file_location('bridge','/tmp/apple-stream-fixture-root/bridge.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
url='about:blank'
def frame(engine):
 end=time.monotonic()+5
 while time.monotonic()<end:
  engine.tick();image=engine.screenshot()
  if image:return image
  time.sleep(.05)
 raise AssertionError('No rendered frame')
for factory in [lambda:b.BrowserEngine(start_url=url),lambda:b.IsolatedBrowserEngine(start_url=url)]:
 e=factory()
 try:
  image=frame(e);assert Image.open(io.BytesIO(image)).size==(1000,760)
  e.input([{'kind':'click','x':30,'y':20}]);e.tick()
  e.input([{'kind':'click','x':30,'y':65},{'kind':'text','text':'fixture text'},{'kind':'key','key':'Enter'}])
  end=time.monotonic()+5
  while time.monotonic()<end:
   image=frame(e);pixel=Image.open(io.BytesIO(image)).getpixel((900,650))
   if pixel[1]>240 and pixel[0]<10:break
  else:raise AssertionError('Input did not change the actual remote page')
  print('PASS:',type(e).__name__,'live frame, pointer, text, Enter and rendered confirmation.',flush=True)
 finally:e.close()
e=b.IsolatedBrowserEngine(start_url=url);profile=e.profile.name;pid=e.process.pid
frame(e);os.kill(pid,signal.SIGSTOP);start=time.monotonic()
try:e.call('tick',timeout=.3);raise AssertionError('Expected deadline')
except TimeoutError:pass
finally:e.close()
assert time.monotonic()-start<4 and not os.path.exists(profile) and not os.path.exists('/proc/'+str(pid))
print('PASS: genuinely stopped worker is killed within deadline and its profile removed.',flush=True)
