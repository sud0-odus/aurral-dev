import { chromium } from '/workspace/aurral-dev/node_modules/playwright/index.mjs';
import assert from 'node:assert/strict';
const browser = await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
try {
 const context = await browser.newContext({viewport:{width:1100,height:900}});
 const sample = await context.newPage();
 await sample.setContent('<html><body style="background:#fafafa;font:24px sans-serif"><h1>Sign-in interaction fixture</h1><input placeholder="Test field"></body></html>');
 const jpg=(await sample.screenshot({type:'jpeg'})).toString('base64');await sample.close();
 let configured=true, connected=false, polls=0, typed=false, closing=false, cancelled=0, sid='abcdefghijklmnopqrstuvwx';
 const errors=[];context.on('page',p=>p.on('pageerror',e=>errors.push(e.message)));
 await context.route('**/api/users/me/apple-music/**', async route=>{
  const url=new URL(route.request().url());const action=url.pathname.split('/apple-music/')[1];let data={};
  if(action==='status')data={configured,connected};
  else if(action==='connect'){polls=0;typed=false;data={id:sid,state:'starting'};}
  else if(action.endsWith('/input')){typed ||= route.request().postDataJSON().events.some(e=>e.kind==='text');data={ok:true};}
  else if(action.endsWith('/cancel')){cancelled++;data={ok:true};}
  else if(action==='disconnect'){connected=false;data={ok:true};}
  else if(action==='playlists')data={complete:true,playlists:[{id:'p.example',name:'Personal playlist fixture',artwork:{url:'https://example.invalid/cover.jpg'}}]};
  else {polls++;if(closing){data={state:'closing',readyForInput:false,message:'Browser is ending; input disabled.'};}else if(typed&&polls>=3){connected=true;data={state:'connected'};}else data=polls<3?{state:'starting',readyForInput:false}:{state:'signing_in',readyForInput:true,image:jpg};}
  await route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(data)});
 });
 const page=await context.newPage();await page.goto('http://127.0.0.1:4175/apple-stream-preview.html');
 await page.getByRole('button',{name:'Connect Apple Music',exact:true}).waitFor();
 const popupEvent=page.waitForEvent('popup');await page.getByRole('button',{name:'Connect Apple Music',exact:true}).click();const popup=await popupEvent;
 await popup.getByPlaceholder('Type or paste for the selected Apple field').waitFor();assert.ok(await popup.getByRole('button',{name:'Send text'}).isDisabled());assert.ok(await popup.locator('img').isHidden());const screen=popup.locator('img');await screen.waitFor();assert.ok(await popup.getByRole('button',{name:'Send text'}).isEnabled());await screen.click({position:{x:40,y:30}});await screen.press('Tab');await screen.press('t');
 await page.getByText('Connected for this session. The sign-in browser is closed.').waitFor({timeout:10000});
 assert.ok(popup.isClosed());assert.ok(typed);
 await page.getByRole('button',{name:'Check playlists',exact:true}).click();await page.getByText('Personal playlist fixture · original cover available').waitFor();
 await page.screenshot({path:'/tmp/apple-connect-profile.png'});
 closing=true;const another=page.waitForEvent('popup');await page.getByRole('button',{name:'Reconnect Apple Music',exact:true}).click();const second=await another;await second.getByText('Browser is ending; input disabled.').waitFor();assert.ok(await second.getByRole('button',{name:'Send text'}).isDisabled());assert.ok(await second.locator('img').isHidden());assert.equal(await second.locator('img').getAttribute('src'),null);await second.getByRole('button',{name:'Cancel',exact:true}).click();
 await page.getByRole('button',{name:'Reconnect Apple Music',exact:true}).waitFor();assert.ok(cancelled>=1);
 await page.getByRole('button',{name:'Disconnect',exact:true}).click();await page.getByRole('button',{name:'Connect Apple Music',exact:true}).waitFor();
 configured=false;await page.reload();await page.getByText('Apple Music connection is not configured on this server.').waitFor();assert.ok(await page.getByRole('button',{name:'Connect Apple Music',exact:true}).isDisabled());
 assert.deepEqual(errors,[]);
 console.log('PASS: popup open/input/success/close, original-cover inventory, cancel, disconnect and unconfigured UI; no page errors.');
} finally {await browser.close();}
