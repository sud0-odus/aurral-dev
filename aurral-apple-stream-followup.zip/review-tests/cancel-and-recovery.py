import importlib.util,time,os,signal
s=importlib.util.spec_from_file_location('bridge','/tmp/apple-stream-fixture-root/bridge.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
engines=[];m=None
def factory():
 e=b.IsolatedBrowserEngine(start_url='about:blank',cancel=m.active['cancel']);engines.append(e);return e
m=b.Manager(factory=factory)
def wait(predicate,seconds=8):
 end=time.monotonic()+seconds
 while not predicate() and time.monotonic()<end:time.sleep(.02)
 assert predicate(),'timed out'
try:
 sid=m.start('1')['id'];wait(lambda:m.get('1',sid)['readyForInput'])
 os.kill(engines[0].process.pid,signal.SIGSTOP)
 start=time.monotonic();m.cancel('1',sid)
 wait(lambda:m.active is None,4)
 assert m.get('1',sid)['state']=='cancelled'
 print('PASS: cancellation frees a genuinely hung browser in %.3fs'%(time.monotonic()-start),flush=True)
 sid=m.start('2')['id'];wait(lambda:m.get('2',sid)['readyForInput'])
 print('PASS: next user can start and receive a live frame after hung-session cleanup.',flush=True)
 m.cancel('2',sid);wait(lambda:m.active is None,4)
 # A capture/tick failure must also free the slot without any Cancel request.
 sid=m.start('3')['id'];wait(lambda:m.get('3',sid)['readyForInput'])
 os.kill(engines[-1].process.pid,signal.SIGSTOP)
 start=time.monotonic();wait(lambda:m.active is None,12)
 assert m.get('3',sid)['state']=='failed'
 print('PASS: silent worker stall fails and releases admission in %.3fs without a service restart.'%(time.monotonic()-start),flush=True)
 sid=m.start('4')['id'];wait(lambda:m.get('4',sid)['readyForInput'])
 m.cancel('4',sid);wait(lambda:m.active is None,4)
 print('PASS: subsequent user receives a live browser after automatic failure cleanup.',flush=True)
finally:m.shutdown()
