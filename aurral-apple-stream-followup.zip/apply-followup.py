#!/usr/bin/env python3
"""Apply the Apple-only streaming browser and readiness UI follow-up."""
import argparse
from pathlib import Path
import subprocess
import sys

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--install',action='store_true',required=True)
 args=parser.parse_args()
 root=Path(__file__).resolve().parent
 def run(component,*flags):subprocess.run([sys.executable,str(root/component/'apply-patch.py'),*flags],check=True)
 # Verify both installed versions before any service is stopped.
 run('ui','--check');run('browser','--check')
 run('ui','--install');run('ui','--enable')
 print('Updating the Apple helper. If the old helper is stuck, systemd may take up to 65 seconds to stop it.',flush=True)
 run('browser','--install')
 print('PASS: Apple-only follow-up enabled. Download scheduler code and pairing were preserved.')
 print('Hard-refresh Aurral with Ctrl+F5. Open Connect Apple Music and use the controls only after Apple browser ready appears.')
 print('This release passed headed Chromium fixture tests. Live Apple authentication still needs your account-side check.')
if __name__=='__main__':
 try:main()
 except subprocess.CalledProcessError:
  print('STOPPED at the failed step; later steps did not run. Share the output rather than repeating the full installer.',file=sys.stderr)
  sys.exit(1)
