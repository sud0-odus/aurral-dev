# Validation record

- 17 bridge unit tests; 4 browser installer tests; 17 UI installer tests: passed.
- 9 offline TLS/client/per-user API boundary tests: passed.
- Headed Chromium + Xvfb fixture: actual frame/pointer/text/Enter and rendered
  page confirmation, forced worker deadline and profile cleanup passed.
  Two CPU guard: 183.0 MiB peak sampled process-group RSS, 9.1 seconds.
- Frozen-session cancellation: 0.223 seconds; next user received a live frame.
- Frozen-session automatic timeout: 8.036 seconds; next user received a live frame.
- React popup browser fixture: controls disabled and stale images hidden during
  loading/closing; input/success/cancel/disconnect/unconfigured states passed.
- Scoped UI lint and production frontend build passed. Build peak sampled RSS
  859.2 MiB under a two CPU / three GiB guard; elapsed 4.5 seconds.
- Actual release source/frontend payload install/enable/rollback with mocked
  systemd/health preserved completed DB work, prior UI and pairing.
- Published preview/capture input hashes matched before packaging.

These are local fixtures. Apple's public site returns ERR_TUNNEL_CONNECTION_FAILED
through this cloud environment; real Apple authentication has not passed here.
The complete account-side test remains on CT109. Test scripts under review-tests
record the cloud fixture commands and use environment-specific paths; do not run
them against the production account or application.
