import { useEffect, useRef, useState } from "react";
import { getData, postData } from "../../../utils/api/core.js";

const PREFIX = "/users/me/apple-music";
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const message = (error) => error?.response?.data?.error || "Apple Music connection failed.";
const SPECIAL_KEYS = new Set(["Enter", "Tab", "Backspace", "Delete", "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Escape", "Home", "End"]);

// The popup is same-origin and contains only a rendered view of the hosted
// browser. It receives no Apple headers, cookies, service key or Aurral token.
function createPopup(popup, send, cancel) {
  const doc = popup.document;
  doc.title = "Connect Apple Music";
  doc.body.style.cssText = "margin:0;background:#151515;color:#fff;font:15px system-ui;";
  const controls = doc.createElement("div");
  controls.style.cssText = "padding:12px;display:flex;gap:12px;align-items:center;";
  const status = doc.createElement("span"); status.textContent = "Starting Apple sign-in…";
  status.style.flex = "1";
  const button = doc.createElement("button"); button.textContent = "Cancel";
  button.onclick = cancel;
  controls.append(status, button);
  const screen = doc.createElement("img");
  screen.alt = "Hosted Apple Music sign-in. Click a field, then type or paste.";
  screen.style.cssText = "display:block;width:100%;height:auto;outline:none;";
  screen.tabIndex = 0;
  const hint = doc.createElement("p");
  hint.textContent = "Waiting for the Apple browser. Controls become available when its screen is ready.";
  hint.style.cssText = "margin:10px 12px;color:#ccc";
  const entry = doc.createElement("input");
  entry.type = "password"; entry.autocomplete = "off"; entry.maxLength = 2048;
  entry.placeholder = "Type or paste for the selected Apple field";
  entry.setAttribute("aria-label", "Text for the selected Apple field");
  const insert = doc.createElement("button"); insert.textContent = "Send text";
  insert.onclick = () => { if (entry.value) { send({ kind: "text", text: entry.value }); entry.value = ""; screen.focus(); } };
  const typing = doc.createElement("div"); typing.style.cssText = "display:flex;gap:8px;padding:8px 12px;";
  entry.style.cssText = "flex:1;min-width:0;padding:8px;";
  typing.append(entry, insert);
  const placeholder = doc.createElement("p");
  placeholder.textContent = "Loading the Apple browser…";
  placeholder.style.cssText = "padding:24px;color:#ccc";
  doc.body.replaceChildren(controls, hint, typing, placeholder, screen);
  let ready = false;
  const setSession = (current) => {
    ready = current.readyForInput === true && Boolean(current.image);
    entry.disabled = insert.disabled = !ready;
    screen.style.display = ready ? "block" : "none";
    screen.style.pointerEvents = ready ? "auto" : "none";
    placeholder.hidden = ready;
    if (ready) {
      screen.src = `data:image/jpeg;base64,${current.image}`;
      status.textContent = "Apple browser ready";
      hint.textContent = "Click Apple’s Sign In button in the screen below. Select an Apple field, then type or paste. The top box sends text to the selected field.";
    } else {
      screen.removeAttribute("src");
      status.textContent = current.state === "closing" ? "Ending the Apple session…" : "Loading the Apple browser…";
      placeholder.textContent = current.state === "closing" ? (current.message || "The browser session is closing. Input is disabled.") : "Waiting for an interactive Apple screen. Nothing to type yet.";
      hint.textContent = "Controls are unavailable until the Apple browser is ready.";
    }
  };
  setSession({ state: "starting" });
  screen.addEventListener("click", (e) => {
    if (!ready) return;
    const rect = screen.getBoundingClientRect();
    screen.focus();
    send({ kind: "click", x: Math.min(999, Math.max(0, (e.clientX - rect.left) * 1000 / rect.width)), y: Math.min(759, Math.max(0, (e.clientY - rect.top) * 760 / rect.height)) });
  });
  screen.addEventListener("keydown", (e) => {
    if (!ready) return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "v") return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "a") { e.preventDefault(); send({ kind: "key", key: "Control+a" }); return; }
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (SPECIAL_KEYS.has(e.key)) {
      e.preventDefault(); send({ kind: "key", key: e.key === "Tab" && e.shiftKey ? "Shift+Tab" : e.key });
    } else if (e.key.length === 1) { e.preventDefault(); send({ kind: "text", text: e.key }); }
  });
  screen.addEventListener("paste", (e) => {
    if (!ready) return;
    e.preventDefault();
    const text = e.clipboardData?.getData("text/plain");
    if (text && text.length <= 2048) send({ kind: "text", text });
  });
  screen.addEventListener("wheel", (e) => { e.preventDefault(); if (ready) send({ kind: "scroll", dy: Math.max(-2000, Math.min(2000, e.deltaY)) }); }, { passive: false });
  return { status, screen, setSession };
}

export function AppleMusicSection({ showSuccess, showError, className = "" }) {
  const [status, setStatus] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [playlists, setPlaylists] = useState(null);
  const active = useRef(null);
  const mounted = useRef(true);
  const refresh = async () => {
    try { const data = await getData(`${PREFIX}/status`); if (mounted.current) setStatus(data); }
    catch (e) { if (mounted.current) setError(message(e)); }
  };
  useEffect(() => {
    mounted.current = true;
    void refresh();
    return () => {
      mounted.current = false;
      const item = active.current;
      if (item) { item.cancelled = true; if (item.id) void postData(`${PREFIX}/session/${item.id}/cancel`, {}, { keepalive: true }).catch(() => {}); item.popup.close(); }
    };
  }, []);

  const connect = async () => {
    const popup = window.open("about:blank", "aurral-apple-music", "width=1040,height=900");
    if (!popup) { setError("Allow popups for Aurral, then try again."); return; }
    const item = { popup, id: null, cancelled: false };
    active.current = item;
    setBusy(true); setError(""); setPlaylists(null);
    let pending = Promise.resolve();
    let queuedInputs = 0;
    const cancel = () => { item.cancelled = true; popup.close(); };
    const ui = createPopup(popup, (event) => {
      if (queuedInputs >= 64) { ui.status.textContent = "Input is catching up. Wait a moment before typing."; return; }
      queuedInputs++;
      pending = pending.then(async () => {
        if (!item.id || item.cancelled || popup.closed) return;
        await postData(`${PREFIX}/session/${item.id}/input`, { events: [event] });
      }).catch((e) => { if (!popup.closed) ui.status.textContent = message(e); }).finally(() => { queuedInputs--; });
    }, cancel);
    let connected = false;
    try {
      const session = await postData(`${PREFIX}/connect`, {});
      item.id = session.id;
      const deadline = Date.now() + 11 * 60 * 1000;
      while (!popup.closed && !item.cancelled && Date.now() < deadline) {
        const current = await getData(`${PREFIX}/session/${item.id}`);
        if (current.state === "connected") { connected = true; break; }
        if (["failed", "expired", "cancelled"].includes(current.state)) throw new Error(current.message || "Apple sign-in ended. Try connecting again.");
        ui.setSession(current);
        await pause(900);
      }
      if (connected) showSuccess?.("Apple Music connected. The hosted browser has closed.");
    } catch (e) {
      if (!item.cancelled && mounted.current) { setError(e.response ? message(e) : e.message); showError?.(e.response ? message(e) : e.message); }
    } finally {
      item.cancelled = true;
      if (item.id && !connected) await postData(`${PREFIX}/session/${item.id}/cancel`, {}).catch(() => {});
      popup.close();
      if (active.current === item) active.current = null;
      if (mounted.current) { setBusy(false); await refresh(); }
    }
  };

  const disconnect = async () => {
    setBusy(true); setError("");
    try { await postData(`${PREFIX}/disconnect`, {}); setPlaylists(null); await refresh(); }
    catch (e) { setError(message(e)); }
    finally { setBusy(false); }
  };
  const checkPlaylists = async () => {
    setBusy(true); setError("");
    try { const data = await getData(`${PREFIX}/playlists`, { timeout: 95000 }); setPlaylists(data.playlists || []); }
    catch (e) { setError(message(e)); await refresh(); }
    finally { setBusy(false); }
  };
  return (
    <section className={`settings-page__section ${className}`} aria-label="Apple Music">
      <div className="settings-page__section-intro">
        <h3 className="settings-page__section-title">Apple Music</h3>
        <p className="settings-page__section-note">Connect your Apple Music account to check your playlists. This preview does not import music or change recommendations.</p>
      </div>
      <p className="settings-page__hint">{status?.connected ? "Connected for this session. The sign-in browser is closed." : status?.configured === false ? "Apple Music connection is not configured on this server." : "Not connected"}</p>
      {error ? <p role="alert">{error}</p> : null}
      <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
        <button type="button" className="btn btn-secondary btn-sm" disabled={busy || !status?.configured} onClick={connect}>{busy ? "Working…" : status?.connected ? "Reconnect Apple Music" : "Connect Apple Music"}</button>
        {status?.connected ? <><button type="button" className="btn btn-secondary btn-sm" disabled={busy} onClick={checkPlaylists}>Check playlists</button><button type="button" className="btn btn-secondary btn-sm" disabled={busy} onClick={disconnect}>Disconnect</button></> : null}
      </div>
      {playlists ? <><p>{playlists.length} playlists available. No downloads queued.</p><ul>{playlists.map((p) => <li key={p.id}>{p.name}{p.artwork?.url ? " · original cover available" : ""}</li>)}</ul></> : null}
    </section>
  );
}
