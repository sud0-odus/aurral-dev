import contextlib
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sqlite3
import tempfile
import time
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('baseline', Path(__file__).with_name('aurral-baseline.py'))
baseline = importlib.util.module_from_spec(spec)
spec.loader.exec_module(baseline)


class BaselineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'aurral.db'
        self.now = int(time.time()*1000)
        con = sqlite3.connect(self.path)
        con.executescript('''
            CREATE TABLE playlist_download_jobs(id,status,created_at,started_at,completed_at,
               download_source,download_client,reused_library_file,request_kind,track_name,error);
            CREATE TABLE honker_task_runs(id,queue,payload,attempt,status,queued_at,run_at,started_at,ended_at,duration_ms);
            CREATE TABLE aurral_history(kind,status,status_label,created_at);
            CREATE TABLE settings(key,value);
            CREATE TABLE _honker_live(queue,payload,state,run_at);
        ''')
        for row in [
            ('download','done',self.now-7200000,self.now-3600000,self.now-1800000,'ytdlp',None,0,'track','PRIVATE TRACK','SECRET URL'),
            ('reuse','done',self.now-60000,self.now-30000,self.now-10000,'ytdlp',None,1,'track','PRIVATE TRACK',None),
            ('stalled','downloading',self.now-90000000,self.now-100000,None,'slskd',None,0,'track','PRIVATE TRACK',None),
            ('failure','failed',self.now-60000,self.now-30000,self.now-5000,'ytdlp',None,0,'track','PRIVATE TRACK','PRIVATE TOKEN'),
        ]:
            con.execute('INSERT INTO playlist_download_jobs VALUES (?,?,?,?,?,?,?,?,?,?,?)',row)
        con.execute('INSERT INTO settings VALUES (?,?)',('integrations',json.dumps({'ytdlp':{'enabled':True,'apiKey':'SECRET_TOKEN','priority':50,'url':'SECRET_URL'}})))
        con.execute('INSERT INTO settings VALUES (?,?)',('playlistWorker','{"concurrency":2}'))
        con.execute('INSERT INTO honker_task_runs VALUES (?,?,?,?,?,?,?,?,?,?)',
                    (1,'slskd-pipeline',json.dumps({'jobId':'download','source':'ytdlp','phase':'download','url':'SECRET_URL','candidates':[{'token':'SECRET_TOKEN'}]}),
                     1,'completed',self.now//1000-50,self.now//1000-40,self.now//1000-30,self.now//1000-10,20000))
        con.commit()
        con.close()

    def test_history_includes_idle_hours_excludes_reuse_and_failed_jobs(self):
        snapshot = baseline.snapshot(self.path,self.now-86400000,set())
        result = baseline.job_summary(snapshot['jobs'],self.now-86400000,self.now)
        self.assertEqual(result['download_completions'],1)
        self.assertEqual(result['reused_completions'],1)
        self.assertEqual(result['failed_in_window'],1)
        self.assertEqual(len(result['hourly']),24)
        self.assertEqual(sum(h['download_completions'] for h in result['hourly']),1)
        self.assertEqual(result['downloads_per_hour'],round(1/24,3))
        self.assertEqual(result['queue_to_completion_seconds']['mean'],5400)
        self.assertEqual(result['latest_start_to_completion_seconds']['mean'],1800)
        self.assertEqual(result['active_job_age_seconds']['mean'],90000)

    def test_stage_duration_units_and_scheduled_delay(self):
        snapshot = baseline.snapshot(self.path,self.now-86400000,set())
        result = baseline.stage_summary(snapshot['worker_runs'])[0]
        self.assertEqual(result['worker_occupied_seconds']['mean'],20)
        self.assertEqual(result['ready_to_worker_start_seconds']['mean'],10)
        self.assertEqual(result['source'],'ytdlp')

    def test_database_is_read_only_and_secrets_not_exported(self):
        before = hashlib.sha256(self.path.read_bytes()).hexdigest()
        snapshot = baseline.snapshot(self.path,self.now-86400000,set())
        after = hashlib.sha256(self.path.read_bytes()).hexdigest()
        self.assertEqual(before,after)
        with baseline.connect(self.path) as con:
            with self.assertRaises(sqlite3.OperationalError):
                con.execute("DELETE FROM settings")
        exported = json.dumps(snapshot)
        for forbidden in ['SECRET','PRIVATE','apiKey','track_name','candidates','url']:
            self.assertNotIn(forbidden,exported)
        self.assertNotIn('download', [j['job'] for j in snapshot['jobs']])

    def test_live_wal_changes_visible_without_restarting(self):
        writer = sqlite3.connect(self.path)
        self.addCleanup(writer.close)
        writer.execute('PRAGMA journal_mode=WAL')
        initial = baseline.snapshot(self.path,self.now-86400000,set())
        writer.execute("UPDATE playlist_download_jobs SET status='done',completed_at=? WHERE id='stalled'",(self.now+1,))
        writer.commit()
        final = baseline.snapshot(self.path,self.now-86400000,set())
        self.assertEqual(sum(j['status']=='done' for j in final['jobs']),1+sum(j['status']=='done' for j in initial['jobs']))

    def test_missing_stage_table_is_reported(self):
        with sqlite3.connect(self.path) as con:
            con.execute('DROP TABLE honker_task_runs')
        warnings = set()
        snapshot = baseline.snapshot(self.path,self.now-86400000,warnings)
        self.assertEqual(snapshot['worker_runs'],[])
        self.assertTrue(any('unavailable' in warning for warning in warnings))

    def test_empty_completion_window_does_not_invent_timings(self):
        result = baseline.job_summary([],self.now-86400000,self.now)
        self.assertEqual(result['download_completions'],0)
        self.assertIsNone(result['queue_to_completion_seconds']['mean'])

    def test_partial_hour_counts_not_inflated_or_double_counted(self):
        snapshot = baseline.snapshot(self.path,self.now-86400000,set())
        result = baseline.job_summary(snapshot['jobs'],self.now-5400000,self.now)
        self.assertEqual(len(result['hourly']),2)
        self.assertEqual(result['downloads_per_hour'],round(1/1.5,3))
        self.assertEqual(sum(h['download_completions'] for h in result['hourly']),1)

    def test_end_to_end_report_with_no_running_app(self):
        prefix = Path(self.tmp.name)/'report'
        argv = ['collector','--db',str(self.path),'--observe-seconds','0','--output',str(prefix)]
        with patch('sys.argv',argv), patch.object(baseline,'system_property',return_value=None), patch.object(baseline,'app_pids',return_value=(set(),set())), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(baseline.main(),0)
        with gzip.open(str(prefix)+'.json.gz','rt') as handle:
            report = json.load(handle)
        self.assertEqual(report['historical_summary']['download_completions'],1)
        self.assertIsNone(report['resource_summary']['cpu_percent_of_budget']['mean'])
        self.assertTrue(any('not detected' in warning for warning in report['limitations']))
        self.assertIn('Historical CPU/memory are not reconstructed',Path(str(prefix)+'.md').read_text())


if __name__ == '__main__':
    unittest.main(verbosity=2)
