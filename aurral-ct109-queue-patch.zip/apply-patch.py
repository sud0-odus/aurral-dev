#!/usr/bin/env python3
"""Install/enable/roll back the CT109 Aurral 2.11 queue-progress patch."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import stat
import subprocess
import sys
import tempfile
import time
import urllib.request

KIT = Path(__file__).resolve().parent
MANIFEST = json.loads((KIT / 'manifest.json').read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def systemctl(*args):
    return subprocess.run(['systemctl', *args, 'aurral.service'], capture_output=True, text=True, timeout=120)


def active():
    return systemctl('is-active', '--quiet').returncode == 0


def stop():
    result = systemctl('stop')
    if result.returncode or active():
        raise RuntimeError('Could not stop aurral.service; no files were installed.')
    print('Aurral stopped. All application queue execution is paused.', flush=True)


def paths(app):
    result = []
    for item in MANIFEST['files']:
        path = app / item['path']
        if not path.resolve().is_relative_to(app.resolve()) or path.is_symlink():
            raise RuntimeError('Refusing an application file outside the app directory or a symlink.')
        result.append((item, path))
    return result


def verify_payload():
    for item in MANIFEST['files']:
        source = KIT / 'files' / item['path']
        if not source.is_file() or digest(source) != item['after_sha256']:
            raise RuntimeError('Patch payload checksum mismatch: ' + item['path'])
        subprocess.run(['node', '--check', str(source)], check=True, capture_output=True, timeout=30)


def verify_app(app, key):
    for item, path in paths(app):
        if not path.is_file() or digest(path) != item[key]:
            raise RuntimeError('Application file differs from the expected ' + key + ': ' + item['path'] +
                               '. Stopped without overwriting it; do not force this patch onto a different build.')


def atomic_copy(source, target):
    metadata = target.stat()
    fd, temporary = tempfile.mkstemp(prefix='.aurral-queue-patch-', dir=target.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(source.read_bytes())
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, stat.S_IMODE(metadata.st_mode))
        os.chown(temporary, metadata.st_uid, metadata.st_gid)
        os.replace(temporary, target)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def write_state(file, state):
    fd, temporary = tempfile.mkstemp(prefix='.aurral-patch-state-', dir=file.parent)
    try:
        with os.fdopen(fd, 'w') as handle:
            json.dump(state, handle, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, 0o600)
        os.replace(temporary, file)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def read_state(file):
    state = json.loads(file.read_text())
    if state.get('patch') != MANIFEST['patch']:
        raise RuntimeError('Installed patch marker does not match this kit.')
    return state


def backup_database(source, target):
    reader = sqlite3.connect(source.resolve().as_uri() + '?mode=ro', uri=True, timeout=5)
    writer = sqlite3.connect(target)
    try:
        reader.backup(writer)
        if writer.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
            raise RuntimeError('Database backup verification failed.')
    finally:
        writer.close()
        reader.close()
    os.chmod(target, 0o600)


def install(args):
    verify_payload()
    verify_app(args.app_dir, 'before_sha256')
    if args.state.exists():
        state = read_state(args.state)
        if state.get('status') != 'rolled_back':
            raise RuntimeError('Patch already has an install marker. Use --enable or --rollback, not another install.')
    if not args.db.is_file():
        raise RuntimeError('Database was not found. Supply --db /actual/path/aurral.db.')
    stop()
    # Remain paused on any error. Installation never starts services.
    verify_app(args.app_dir, 'before_sha256')
    args.backup_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
    backup = Path(tempfile.mkdtemp(prefix='queue-progress-', dir=args.backup_dir))
    os.chmod(backup, 0o700)
    for item, path in paths(args.app_dir):
        saved = backup / item['path']
        saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, saved)
    print('Backing up the stopped application database locally...', flush=True)
    backup_database(args.db, backup / 'aurral.db')
    state = {'patch': MANIFEST['patch'], 'status': 'prepared', 'backup': str(backup),
             'app_dir': str(args.app_dir.resolve()), 'installed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    write_state(args.state, state)
    changed = []
    try:
        for item, path in paths(args.app_dir):
            atomic_copy(KIT / 'files' / item['path'], path)
            changed.append((item, path))
        verify_app(args.app_dir, 'after_sha256')
    except BaseException:
        for item, path in reversed(changed):
            atomic_copy(backup / item['path'], path)
        state['status'] = 'rolled_back'
        write_state(args.state, state)
        raise
    state['status'] = 'installed_paused'
    write_state(args.state, state)
    print('PASS: %d backend files installed. Aurral remains STOPPED; queue/database rows were not edited.' % len(MANIFEST['files']))
    print('Local code/database backup: ' + str(backup))
    print('Next: python3 ' + str(KIT / 'apply-patch.py') + ' --enable')


def healthy(url):
    with urllib.request.urlopen(url, timeout=2) as response:
        payload = json.load(response)
    return payload.get('status') == 'ok' and payload.get('matcher', {}).get('available') is True


def enable(args):
    state = read_state(args.state)
    if state.get('status') not in {'installed_paused', 'enabled'} or state.get('app_dir') != str(args.app_dir.resolve()):
        raise RuntimeError('Patch is not installed for this application directory.')
    verify_app(args.app_dir, 'after_sha256')
    started = systemctl('start')
    if started.returncode:
        raise RuntimeError('Service failed to start. Patch remains installed; use --rollback if needed.')
    for _ in range(40):
        try:
            if active() and healthy(args.health_url):
                state['status'] = 'enabled'
                state['enabled_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
                write_state(args.state, state)
                print('PASS: Aurral is active and health/matcher checks passed. Existing startup recovery resumes eligible work.')
                print('Keep download concurrency at its existing value (2). No source priorities or transcoding settings were changed.')
                return
        except (OSError, ValueError):
            pass
        time.sleep(1)
    stop()
    raise RuntimeError('Health check failed. Service was stopped again; use --rollback. Database backup was not restored.')


def rollback(args):
    state = read_state(args.state)
    if state.get('app_dir') != str(args.app_dir.resolve()) or state.get('status') == 'rolled_back':
        raise RuntimeError('No matching installed patch to roll back.')
    if state.get('status') == 'prepared':
        for item, path in paths(args.app_dir):
            if digest(path) not in {item['before_sha256'], item['after_sha256']}:
                raise RuntimeError('Interrupted installation contains an unknown file edit; refusing to overwrite it.')
    else:
        verify_app(args.app_dir, 'after_sha256')
    backup = Path(state['backup'])
    for item, _ in paths(args.app_dir):
        if digest(backup / item['path']) != item['before_sha256']:
            raise RuntimeError('Backup checksum mismatch; no rollback files were written.')
    stop()
    for item, path in paths(args.app_dir):
        atomic_copy(backup / item['path'], path)
    verify_app(args.app_dir, 'before_sha256')
    state['status'] = 'rolled_back'
    write_state(args.state, state)
    print('PASS: original v2.11 code restored. Service remains STOPPED.')
    print('Your current database was preserved; post-patch completed work was not discarded.')
    print('To resume the original version: systemctl start aurral.service')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    for flag in ['check', 'install', 'enable', 'rollback']:
        action.add_argument('--' + flag, action='store_true')
    parser.add_argument('--app-dir', type=Path, default=Path('/opt/aurral'))
    parser.add_argument('--db', type=Path, default=Path('/opt/aurral_data/aurral.db'))
    parser.add_argument('--backup-dir', type=Path, default=Path('/opt/aurral-patch-backups'))
    parser.add_argument('--state', type=Path, default=Path('/opt/aurral-queue-patch.json'))
    parser.add_argument('--health-url', default='http://127.0.0.1:3001/api/health')
    args = parser.parse_args()
    if args.check:
        verify_payload()
        verify_app(args.app_dir, 'before_sha256')
        if not args.db.is_file():
            raise RuntimeError('Database not found; specify --db.')
        print('PASS: patch payload and all four original v2.11 files match. No service or application changes made.')
        return
    if os.geteuid() != 0:
        raise RuntimeError('Run install/enable/rollback as root inside CT 109.')
    if args.install:
        install(args)
    elif args.enable:
        enable(args)
    else:
        rollback(args)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('STOPPED: ' + str(error), file=sys.stderr)
        sys.exit(1)
