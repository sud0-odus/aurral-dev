import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sqlite3
import tempfile
import types
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('installer',Path(__file__).with_name('apply-patch.py'))
installer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.kit = root/'kit'
        self.app = root/'app'
        self.relative = 'backend/services/test.js'
        (self.app/'backend/services').mkdir(parents=True)
        (self.kit/'files/backend/services').mkdir(parents=True)
        self.old = b'export const version = "original";\n'
        self.new = b'export const version = "patched";\n'
        (self.app/self.relative).write_bytes(self.old)
        (self.kit/'files'/self.relative).write_bytes(self.new)
        self.database = root/'aurral.db'
        with sqlite3.connect(self.database) as con:
            con.execute('CREATE TABLE work (value TEXT)')
            con.execute('INSERT INTO work VALUES (?)',('existing queue',))
        manifest = {'patch':'test-patch','files':[{'path':self.relative,'before_sha256':hashlib.sha256(self.old).hexdigest(),
                                                'after_sha256':hashlib.sha256(self.new).hexdigest()}]}
        self.patch_kit = patch.object(installer,'KIT',self.kit)
        self.patch_manifest = patch.object(installer,'MANIFEST',manifest)
        self.patch_kit.start();self.patch_manifest.start()
        self.addCleanup(self.patch_kit.stop);self.addCleanup(self.patch_manifest.stop)
        self.args = argparse.Namespace(app_dir=self.app,db=self.database,backup_dir=root/'backups',
                                       state=root/'state.json',health_url='http://127.0.0.1:1/api/health')
        self.service_active = True
        self.calls = []
        def service(*args):
            self.calls.append(args)
            if args[0]=='stop': self.service_active = False
            if args[0]=='start': self.service_active = True
            return types.SimpleNamespace(returncode=(0 if self.service_active else 3) if args[0]=='is-active' else 0)
        self.service_mock = patch.object(installer,'systemctl',side_effect=service)
        self.service_mock.start();self.addCleanup(self.service_mock.stop)

    def test_install_enable_rollback_preserves_new_database_work(self):
        installer.install(self.args)
        self.assertFalse(self.service_active)
        self.assertEqual((self.app/self.relative).read_bytes(),self.new)
        state=installer.read_state(self.args.state)
        self.assertEqual(state['status'],'installed_paused')
        backup=Path(state['backup'])
        self.assertEqual((backup.stat().st_mode&0o777),0o700)
        self.assertEqual(((backup/'aurral.db').stat().st_mode&0o777),0o600)
        with sqlite3.connect(backup/'aurral.db') as con:
            self.assertEqual(con.execute('SELECT value FROM work').fetchall(),[('existing queue',)])
        with patch.object(installer,'healthy',return_value=True): installer.enable(self.args)
        self.assertTrue(self.service_active)
        with sqlite3.connect(self.database) as con: con.execute('INSERT INTO work VALUES (?)',('new completed download',))
        installer.rollback(self.args)
        self.assertFalse(self.service_active)
        self.assertEqual((self.app/self.relative).read_bytes(),self.old)
        with sqlite3.connect(self.database) as con: self.assertEqual(con.execute('SELECT count(*) FROM work').fetchone()[0],2)

    def test_unknown_original_is_rejected_before_stopping_service(self):
        (self.app/self.relative).write_text('user modification')
        with self.assertRaisesRegex(RuntimeError,'differs'): installer.install(self.args)
        self.assertTrue(self.service_active)
        self.assertNotIn(('stop',),self.calls)

    def test_payload_tampering_is_rejected(self):
        (self.kit/'files'/self.relative).write_text('unexpected payload')
        with self.assertRaisesRegex(RuntimeError,'checksum'): installer.install(self.args)
        self.assertTrue(self.service_active)

    def test_failed_health_check_stops_service_and_keeps_backup(self):
        installer.install(self.args)
        with patch.object(installer,'healthy',return_value=False),patch.object(installer.time,'sleep'):
            with self.assertRaisesRegex(RuntimeError,'Health check failed'): installer.enable(self.args)
        self.assertFalse(self.service_active)
        self.assertEqual(installer.read_state(self.args.state)['status'],'installed_paused')
        self.assertTrue((Path(installer.read_state(self.args.state)['backup'])/'aurral.db').is_file())

    def test_rollback_does_not_overwrite_later_user_edits(self):
        installer.install(self.args)
        (self.app/self.relative).write_text('later user edit')
        with self.assertRaisesRegex(RuntimeError,'differs'): installer.rollback(self.args)
        self.assertEqual((self.app/self.relative).read_text(),'later user edit')

    def test_failed_install_restores_original_files_and_stays_paused(self):
        other = 'backend/services/other.js'
        (self.app/other).write_bytes(self.old)
        (self.kit/'files'/other).write_bytes(self.new)
        installer.MANIFEST['files'].append({**installer.MANIFEST['files'][0], 'path':other})
        original=installer.atomic_copy
        copies=0
        def fail_after_copy(source,target):
            nonlocal copies
            copies+=1
            if copies == 2:
                raise OSError('simulated file write failure')
            return original(source,target)
        with patch.object(installer,'atomic_copy',side_effect=fail_after_copy):
            with self.assertRaisesRegex(OSError,'simulated'): installer.install(self.args)
        self.assertFalse(self.service_active)
        self.assertEqual((self.app/self.relative).read_bytes(),self.old)
        self.assertEqual((self.app/other).read_bytes(),self.old)
        self.assertEqual(installer.read_state(self.args.state)['status'],'rolled_back')

    def test_interrupted_install_marker_can_restore_known_original_or_patched_files(self):
        installer.install(self.args)
        state=installer.read_state(self.args.state)
        state['status']='prepared'
        installer.write_state(self.args.state,state)
        (self.app/self.relative).write_bytes(self.old)
        installer.rollback(self.args)
        self.assertEqual((self.app/self.relative).read_bytes(),self.old)
        self.assertFalse(self.service_active)


if __name__=='__main__': unittest.main(verbosity=2)
