import createHonkerWorker from "./honkerWorkerFactory.js";
import { getPipelineQueue } from "./honkerDb.js";
import {
  continuePipeline,
  processPipelinePayload,
  enqueuePendingJobsWithoutBatch,
  failPipelineJob,
} from "./downloadPipeline.js";
import { isPipelinePayloadActive } from "./downloadJobs/downloadCancellation.js";
import { isAnyDownloadSourceConfigured } from "./downloadSourceService.js";
import { logger, safeLogDiagnostic } from "./logger.js";
import { recordAlbumGrabQueued, recordAlbumGrabPhase } from "./albumGrabActivity.js";
import { downloadTracker } from "./downloadJobs/downloadTracker.js";
import { withDownloadPayloadMutation } from "./downloadJobs/mutationGuards.js";

async function processLockedPipelineJob(payload, dependencies = {}) {
  const processPayload = dependencies.processPipelinePayload || processPipelinePayload;
  const continuePayload = dependencies.continuePipeline || continuePipeline;
  const failPayload = dependencies.failPipelineJob || failPipelineJob;
  try {
    if (payload?.albumGrab === true && isPipelinePayloadActive(payload)) {
      recordAlbumGrabQueued(payload, downloadTracker.getAll());
      recordAlbumGrabPhase(payload);
    }
    const nextPayload = await processPayload(payload);
    if (nextPayload?.albumGrab === true) recordAlbumGrabPhase(nextPayload);
    await continuePayload(nextPayload);
  } catch (error) {
    if (payload?.manualSelection !== true) throw error;
    const message = safeLogDiagnostic(error) || "Manual download failed";
    logger.error("manual-search", "Selected manual download failed", {
      jobId: payload?.jobId || null,
      source: payload?.source || null,
      reason: message,
    });
    await failPayload(payload, message);
  }
}

export async function processPipelineJob(payload, dependencies = {}) {
  try {
    return await withDownloadPayloadMutation(payload, (current) => processLockedPipelineJob(current, dependencies));
  } finally {
    // Wake dispatch after releasing the playlist lease. A waiting transfer
    // or search may be the only work that survived an idle owner/restart.
    // Failure to wake must not retry a step whose continuation was persisted.
    try {
      const startPending = dependencies.startWorkerIfPending ||
        (await import("./downloadJobs/downloadWorker.js")).startWorkerIfPending;
      await startPending({ respectPause: true });
    } catch (error) {
      logger.warn("downloads", "Could not wake pending download jobs", {
        reason: safeLogDiagnostic(error),
      });
    }
  }
}

const {
  start: startDownloadPipelineWorker,
  stop: stopDownloadPipelineWorker,
  isRunning: isDownloadPipelineWorkerRunning,
} = createHonkerWorker({
  name: "slskd-pipeline",
  getQueue: getPipelineQueue,
  idlePollS: 2,
  retryDelayS: 30,
  shouldRestart: () => isAnyDownloadSourceConfigured(),
  onStart() {
    if (!isAnyDownloadSourceConfigured()) return false;
    console.log("[pipeline] worker starting");
    enqueuePendingJobsWithoutBatch();
    return true;
  },
  processJob: processPipelineJob,
  onFinalFailure(job, error) {
    const message = error?.message || String(error);
    console.error("[downloadPipelineWorker] pipeline job failed:", {
      jobId: job.payload?.jobId || null,
      phase: job.payload?.phase || null,
      candidateIndex: job.payload?.candidateIndex ?? null,
      message,
      stack: error?.stack || null,
    });
    return withDownloadPayloadMutation(job.payload, async (payload) => continuePipeline(await failPipelineJob(payload, message)));
  },
});

export {
  startDownloadPipelineWorker,
  stopDownloadPipelineWorker,
  isDownloadPipelineWorkerRunning,
};
