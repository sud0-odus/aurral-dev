#!/usr/bin/env python3
"""Read-only Aurral v2.11 baseline. Python 3 standard library; no installation."""
import argparse
import collections
import csv
import datetime as dt
import gzip
import hashlib
import json
import math
import os
import re
from pathlib import Path
import sqlite3
import statistics
import subprocess
import sys
import time

SOURCES = {'slskd', 'ytdlp', 'usenet', 'sabnzbd', 'nzbget', 'deemix', 'lidarr'}
PHASES = {'search', 'download', 'poll', 'finalize', 'waiting'}
STATES = {'pending', 'downloading', 'done', 'failed', 'cancelled', 'blocked', 'denied',
          'running', 'completed', 'processing', 'interrupted', 'dead'}
LIMIT = 50000


def utc(ms):
    return dt.datetime.fromtimestamp(ms / 1000, dt.timezone.utc).isoformat()


def token(value):
    return hashlib.sha256(('aurral-baseline:' + str(value)).encode()).hexdigest()[:20] if value else None


def choice(value, allowed):
    return value if value in allowed else 'unknown'


def number(value):
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (ValueError, TypeError):
        return None


def span(end, start):
    end, start = number(end), number(start)
    return (end - start) / 1000 if end is not None and start is not None and end >= start else None


def distribution(values):
    values = sorted(v for v in values if v is not None and math.isfinite(v))
    if not values:
        return {'count': 0, 'mean': None, 'median': None, 'p95': None, 'max': None}
    return {'count': len(values), 'mean': round(statistics.mean(values), 3),
            'median': round(statistics.median(values), 3),
            'p95': round(values[max(0, math.ceil(len(values) * .95) - 1)], 3),
            'max': round(values[-1], 3)}


def read_text(path):
    try:
        return Path(path).read_text().strip()
    except OSError:
        return None


def system_property(name):
    try:
        result = subprocess.run(['systemctl', 'show', 'aurral.service', '-p', name, '--value'],
                                capture_output=True, text=True, timeout=3)
        return result.stdout.strip() if result.returncode == 0 else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def processes():
    result = {}
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            fields = (entry / 'stat').read_text().rsplit(') ', 1)[1].split()
            status = (entry / 'status').read_text().splitlines()
            swap = next((int(line.split()[1]) * 1024 for line in status if line.startswith('VmSwap:')), 0)
            result[int(entry.name)] = {'ppid': int(fields[1]), 'ticks': int(fields[11]) + int(fields[12]),
                                       'start': int(fields[19]), 'rss': int(fields[21]) * os.sysconf('SC_PAGE_SIZE'),
                                       'swap': swap, 'comm': (entry / 'comm').read_text().strip()}
        except (OSError, ValueError, IndexError):
            continue
    return result


def app_pids(proc):
    roots = set()
    main = system_property('MainPID')
    if main and main.isdigit() and int(main) in proc and int(main) > 0:
        roots.add(int(main))
    if not roots:
        for pid in proc:
            if 'node' not in proc[pid]['comm']:
                continue
            try:
                args = Path('/proc', str(pid), 'cmdline').read_bytes().split(b'\0')
                cwd = Path('/proc', str(pid), 'cwd').resolve()
                if any(arg.endswith(b'backend/server.js') or arg == b'server.js' for arg in args):
                    if (cwd / 'backend/services/downloadPipeline.js').is_file() or (cwd / 'services/downloadPipeline.js').is_file():
                        roots.add(pid)
            except OSError:
                continue
    selected = set(roots)
    while True:
        more = {pid for pid, item in proc.items() if item['ppid'] in selected}
        if more <= selected:
            break
        selected |= more
    return selected, roots


def connect(path):
    # mode=ro retains SQLite WAL locking/visibility; immutable=1 would miss live WAL writes.
    con = sqlite3.connect(path.resolve().as_uri() + '?mode=ro', uri=True, timeout=2)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA query_only=ON')
    return con


def find_database(explicit):
    if explicit:
        candidates = [Path(explicit)]
    else:
        candidates = [Path('/opt/aurral_data/aurral.db'), Path('/opt/aurral/backend/data/aurral.db'),
                      Path('/config/aurral.db'), Path('/var/lib/aurral/aurral.db')]
        proc = processes()
        _, roots = app_pids(proc)
        for pid in roots:
            try:
                for fd in Path('/proc', str(pid), 'fd').iterdir():
                    target = fd.resolve()
                    if target.name == 'aurral.db':
                        candidates.append(target)
            except OSError:
                pass
    valid = []
    for path in dict.fromkeys(p.resolve() for p in candidates):
        if not path.is_file():
            continue
        try:
            with connect(path) as con:
                con.execute('SELECT id, status, created_at, completed_at FROM playlist_download_jobs LIMIT 0')
            valid.append(path)
        except sqlite3.Error:
            continue
    if len(valid) != 1:
        raise RuntimeError('Expected one Aurral database, found %d. Run with --db /actual/path/aurral.db.' % len(valid))
    return valid[0]


def columns(con, table):
    return {row['name'] for row in con.execute('PRAGMA table_info("%s")' % table)}


def bounded(con, query, params, warnings, label):
    rows = con.execute(query + ' LIMIT ?', (*params, LIMIT + 1)).fetchall()
    if len(rows) > LIMIT:
        warnings.add(label + ' truncated at %d rows; aggregate results are incomplete.' % LIMIT)
    return rows[:LIMIT]


def snapshot(path, cutoff, warnings):
    # Each snapshot is a short coherent read transaction. It never spans the observation interval.
    con = connect(path)
    try:
        con.execute('BEGIN')
        fields = ['id', 'status', 'created_at', 'started_at', 'completed_at', 'download_source', 'download_client',
                  'reused_library_file', 'request_kind']
        available = columns(con, 'playlist_download_jobs')
        selected = ','.join('"%s"' % f if f in available else 'NULL AS "%s"' % f for f in fields)
        rows = bounded(con, 'SELECT ' + selected + ' FROM playlist_download_jobs WHERE created_at >= ? OR completed_at >= ? '
                       "OR status NOT IN ('done','failed','cancelled','denied') ORDER BY created_at DESC, id", (cutoff, cutoff), warnings, 'Jobs')
        jobs = []
        for row in rows:
            item = dict(row)
            item['job'] = token(item.pop('id'))
            item['source'] = choice(item.pop('download_source') or item.pop('download_client'), SOURCES)
            item.pop('download_client', None)
            item['status'] = choice(item['status'], STATES)
            item['request_kind'] = choice(item['request_kind'], {'track', 'album'})
            item['reused_library_file'] = bool(item['reused_library_file']) if item['reused_library_file'] is not None else None
            item['queue_to_completion_seconds'] = span(item['completed_at'], item['created_at'])
            item['latest_start_to_completion_seconds'] = span(item['completed_at'], item['started_at'])
            jobs.append(item)
        tasks = []
        if columns(con, 'honker_task_runs'):
            rows = bounded(con, 'SELECT id,queue,payload,attempt,status,queued_at,run_at,started_at,ended_at,duration_ms '
                           'FROM honker_task_runs WHERE started_at >= ? OR ended_at >= ? OR ended_at IS NULL ORDER BY id DESC',
                           (int(cutoff / 1000), int(cutoff / 1000)), warnings, 'Worker runs')
            for row in rows:
                item = dict(row)
                try:
                    payload = json.loads(item.pop('payload') or '{}')
                    payload = payload if isinstance(payload, dict) else {}
                except (ValueError, TypeError):
                    payload = {}
                # Never export raw payloads, names, paths, URLs, credentials, or error messages.
                item['job'] = token(payload.get('jobId'))
                item['phase'] = choice(payload.get('phase'), PHASES)
                item['source'] = choice(payload.get('source'), SOURCES)
                item['queue'] = item['queue'] if item['queue'] == 'slskd-pipeline' else 'other'
                item['status'] = choice(item['status'], STATES)
                tasks.append(item)
        else:
            warnings.add('No honker_task_runs table: detailed stage timings unavailable.')
        history = []
        if columns(con, 'aurral_history'):
            rows = bounded(con, "SELECT status,status_label,created_at FROM aurral_history WHERE kind='track_download' AND created_at>=?",
                           (cutoff,), warnings, 'Activity entries')
            for row in rows:
                history.append({'status': choice(row['status'], STATES), 'created_at': row['created_at'],
                                'label': choice(row['status_label'], {'Downloaded', 'Reused', 'Searching', 'Downloading', 'Moving', 'Failed', 'Cancelled'})})
        settings = {}
        if columns(con, 'settings'):
            for key in ['playlistWorker', 'integrations']:
                row = con.execute('SELECT value FROM settings WHERE key=?', (key,)).fetchone()
                try:
                    value = json.loads(row['value']) if row else {}
                    if not isinstance(value, dict):
                        continue
                    if key == 'playlistWorker':
                        settings['configured_job_concurrency'] = number(value.get('concurrency'))
                    else:
                        settings['sources'] = {name: {'enabled': config.get('enabled') if isinstance(config.get('enabled'), bool) else None,
                                                     'priority': number(config.get('priority'))}
                                               for name, config in value.items() if name in SOURCES and isinstance(config, dict)}
                except (ValueError, TypeError):
                    pass
        live = collections.Counter()
        if columns(con, '_honker_live'):
            for row in con.execute("SELECT payload,state,run_at FROM _honker_live WHERE queue='slskd-pipeline'"):
                try:
                    payload = json.loads(row['payload'] or '{}')
                    phase = choice(payload.get('phase'), PHASES) if isinstance(payload, dict) else 'unknown'
                except (ValueError, TypeError):
                    phase = 'unknown'
                state = choice(row['state'], STATES)
                due = 'delayed' if (number(row['run_at']) or 0) > time.time() else 'due'
                live[phase + '/' + state + '/' + due] += 1
        return {'captured_at': int(time.time() * 1000), 'jobs': jobs, 'worker_runs': tasks,
                'activity_entry_counts': dict(collections.Counter(x['label'] for x in history)),
                'configuration': settings, 'pipeline_queue': dict(live)}
    finally:
        con.rollback()
        con.close()


def cgroup_values(root):
    result = {}
    for name in ['memory.current', 'memory.max', 'memory.swap.current', 'memory.swap.max', 'cpu.max']:
        value = read_text(root / name)
        if value is not None:
            result[name] = int(value) if value.isdigit() else value
    for name in ['cpu.stat', 'memory.events']:
        value = read_text(root / name)
        if value:
            result[name] = {parts[0]: int(parts[1]) for line in value.splitlines()
                            if len(parts := line.split()) == 2 and parts[1].isdigit()}
    return result


def sample_resources(previous, service_group, cpu_budget):
    now = time.monotonic()
    proc = processes()
    selected, roots = app_pids(proc)
    selected_proc = {pid: proc[pid] for pid in selected}
    labels = collections.Counter()
    for item in selected_proc.values():
        comm = item['comm'].lower()
        label = 'ffmpeg' if 'ffmpeg' in comm else 'yt-dlp' if 'yt-dlp' in comm else 'node' if 'node' in comm else 'other'
        labels[label] += 1
    result = {'at': int(time.time() * 1000), 'app_detected': bool(roots), 'app_process_count': len(selected),
              'process_counts': dict(labels), 'app_summed_rss_bytes': sum(x['rss'] for x in selected_proc.values()),
              'app_process_swap_bytes': sum(x['swap'] for x in selected_proc.values()),
              'app_cpu_percent_of_budget': None, 'cpu_method': None,
              'container_visible_cgroup': cgroup_values(Path('/sys/fs/cgroup'))}
    service = cgroup_values(service_group) if service_group else {}
    result['app_service_cgroup'] = service or None
    if previous:
        elapsed = now - previous[0]
        old_cpu = previous[2].get('cpu.stat', {}).get('usage_usec')
        cpu = service.get('cpu.stat', {}).get('usage_usec')
        if cpu is not None and old_cpu is not None and cpu >= old_cpu:
            result['app_cpu_percent_of_budget'] = round((cpu - old_cpu) / 1e6 / elapsed / cpu_budget * 100, 2)
            result['cpu_method'] = 'systemd_service_cgroup'
        elif roots:
            delta = sum(max(0, item['ticks'] - previous[1][pid]['ticks']) for pid, item in selected_proc.items()
                        if pid in previous[1] and item['start'] == previous[1][pid]['start'])
            result['app_cpu_percent_of_budget'] = round(delta / os.sysconf('SC_CLK_TCK') / elapsed / cpu_budget * 100, 2)
            result['cpu_method'] = 'surviving_processes_estimate_excludes_short_lived_children'
    return result, (now, selected_proc, service)


def job_summary(jobs, start, end):
    ended = [j for j in jobs if j['status'] == 'done' and j['completed_at'] is not None and start <= j['completed_at'] < end]
    downloaded = [j for j in ended if j['reused_library_file'] is False]
    reused = [j for j in ended if j['reused_library_file'] is True]
    unknown = [j for j in ended if j['reused_library_file'] is None]
    attributed = [j for j in downloaded if j['source'] != 'unknown']
    buckets = []
    cursor = start
    while cursor < end:
        stop = min(cursor + 3600000, end)
        count = sum(cursor <= j['completed_at'] < stop for j in downloaded)
        buckets.append({'start_utc': utc(cursor), 'end_utc': utc(stop), 'download_completions': count,
                        'source_attributed_completions': sum(cursor <= j['completed_at'] < stop for j in attributed),
                        'reused_completions': sum(cursor <= j['completed_at'] < stop for j in reused)})
        cursor = stop
    active = [j for j in jobs if j['status'] not in {'done', 'failed', 'cancelled', 'denied'}]
    return {'window_start_utc': utc(start), 'window_end_utc': utc(end), 'window_hours': (end-start)/3600000,
            'retained_done_jobs': len(ended), 'download_completions': len(downloaded), 'reused_completions': len(reused),
            'unknown_reuse_completions': len(unknown), 'downloads_per_hour': round(len(downloaded)/((end-start)/3600000), 3),
            'source_attributed_completions': len(attributed),
            'source_attributed_completions_per_hour': round(len(attributed)/((end-start)/3600000), 3),
            'source_attributed_queue_to_completion_seconds': distribution(span(j['completed_at'],j['created_at']) for j in attributed),
            'by_source': dict(collections.Counter(j['source'] for j in downloaded)),
            'current_status_counts': dict(collections.Counter(j['status'] for j in jobs)),
            'created_in_window': sum(start <= j['created_at'] < end for j in jobs),
            'failed_in_window': sum(j['status']=='failed' and j['completed_at'] is not None and start <= j['completed_at'] < end for j in jobs),
            'queue_to_completion_seconds': distribution(span(j['completed_at'], j['created_at']) for j in downloaded),
            'latest_start_to_completion_seconds': distribution(span(j['completed_at'], j['started_at']) for j in downloaded),
            'active_job_age_seconds': distribution(span(end, j['created_at']) for j in active), 'hourly': buckets}


def stage_summary(runs):
    grouped = collections.defaultdict(list)
    for run in runs:
        if run['queue'] == 'slskd-pipeline':
            grouped[(run['source'], run['phase'])].append(run)
    result = []
    for (source, phase), items in sorted(grouped.items()):
        finished = [r for r in items if r['ended_at'] is not None and r['duration_ms'] is not None]
        result.append({'source': source, 'phase': phase, 'retained_executions': len(items),
                       'statuses': dict(collections.Counter(r['status'] for r in items)),
                       'worker_occupied_seconds': distribution(r['duration_ms']/1000 for r in finished),
                       'ready_to_worker_start_seconds': distribution(span(r['started_at']*1000, r['run_at']*1000)
                                                                    for r in items if r['run_at'] is not None)})
    return result


def render(report):
    base = report['historical_summary']
    live = report['live_window_summary']
    resource = report['resource_summary']
    def metric(value):
        return 'unavailable' if value is None else str(round(value, 2))
    lines = ['# Aurral download baseline', '', 'Historical window: %s to %s (UTC).' % (base['window_start_utc'], base['window_end_utc']), '',
             '| Measure | Result |', '|---|---:|',
             '| Source-attributed non-reuse completions | %s |' % base['source_attributed_completions'],
             '| Source-attributed completions per hour, including idle hours | %s |' % base['source_attributed_completions_per_hour'],
             '| Other non-reuse done records, source unknown (excluded above) | %s |' % (base['download_completions']-base['source_attributed_completions']),
             '| Reused-file completions (separate) | %s |' % base['reused_completions'],
             '| Failed jobs ending in the window | %s |' % base['failed_in_window'],
             '| Source-attributed queue-to-completion mean / median / p95, seconds | %s / %s / %s |' % tuple(metric(base['source_attributed_queue_to_completion_seconds'][k]) for k in ['mean','median','p95']),
             '| Latest-start-to-completion mean / median / p95, seconds | %s / %s / %s |' % tuple(metric(base['latest_start_to_completion_seconds'][k]) for k in ['mean','median','p95']),
             '| App CPU during observation, mean / max, percent of configured CPU budget | %s / %s |' % (metric(resource['cpu_percent_of_budget']['mean']),metric(resource['cpu_percent_of_budget']['max'])),
             '| Peak app service cgroup memory, MiB | %s |' % metric(resource['service_memory_mib']['max']),
             '| Peak summed process RSS, MiB (shared pages can count twice) | %s |' % metric(resource['process_rss_mib']['max']),
             '| Peak app process swap, MiB | %s |' % metric(resource['process_swap_mib']['max']), '',
             'Resource observation: %.1f seconds; CPU budget: %s cores. Historical CPU/memory are not reconstructed.' % (report['observation_seconds'],report['cpu_budget']), '',
             '## Follow-up observation results', '',
             '- Source-attributed non-reuse completions during observation: %s.' % live['source_attributed_completions'],
             '- Observed source-attributed completions per hour: %s (short-window estimate).' % live['source_attributed_completions_per_hour'],
             '- Final retained job states: %s.' % json.dumps(live['current_status_counts'],sort_keys=True), '',
             '## Hourly retained source-attributed completions', '', '| Interval start (UTC) | Source-attributed completions | Reused |', '|---|---:|---:|']
    lines += ['| %s | %s | %s |' % (b['start_utc'],b['source_attributed_completions'],b['reused_completions']) for b in base['hourly']]
    lines += ['', '## Retained and observed stage execution timings', '',
              'These are worker occupancy times, not transfer wall times. A poll is one check; an album operation can cover multiple tracks.', '',
              '| Source | Stage | Executions | Finished samples | Mean / p95 seconds |', '|---|---|---:|---:|---:|']
    for stage in report['stage_summary']:
        timing = stage['worker_occupied_seconds']
        lines.append('| %s | %s | %s | %s | %s / %s |' % (stage['source'],stage['phase'],stage['retained_executions'],timing['count'],metric(timing['mean']),metric(timing['p95'])))
    lines += ['', '## Coverage and interpretation', ''] + ['- '+warning for warning in report['limitations']]
    lines += ['', 'The jobs CSV lists individual pseudonymous jobs and elapsed times. The compressed JSON contains the full baseline, stage executions and resource/queue samples. Neither contains raw database files, full settings, environment, track names, URLs, paths, or logs.', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', help='Aurral SQLite database; helper-script location detected automatically')
    parser.add_argument('--hours', type=float, default=24, help='Historical lookback (default: 24 hours)')
    parser.add_argument('--observe-seconds', type=float, default=300, help='Live sample duration (default: 300 seconds)')
    parser.add_argument('--interval', type=float, default=5, help='Sample interval (default: 5 seconds)')
    parser.add_argument('--cpu-budget', type=float, default=2, help='Allocated CPU cores (default: 2)')
    parser.add_argument('--output', default='aurral-baseline', help='Output path prefix (two new files; never overwrite)')
    args = parser.parse_args()
    if not 0 < args.hours <= 168 or not 0 <= args.observe_seconds <= 86400 or not .1 <= args.interval <= 300 or not 0 < args.cpu_budget <= 1024 or args.observe_seconds / args.interval > 20000:
        parser.error('Use 0<hours<=168, 0<=observe-seconds<=86400, .1<=interval<=300, 0<cpu-budget<=1024, and at most 20000 samples.')
    prefix = Path(args.output)
    json_path, md_path, csv_path = Path(str(prefix)+'.json.gz'), Path(str(prefix)+'.md'), Path(str(prefix)+'.jobs.csv')
    if any(p.exists() for p in [json_path, md_path, csv_path]):
        parser.error('Output already exists; choose a new --output prefix.')
    database = find_database(args.db)
    start = int(time.time()*1000)
    cutoff = start - int(args.hours*3600000)
    warnings = set()
    initial = snapshot(database, cutoff, warnings)
    runs = {r['id']: r for r in initial['worker_runs']}
    observations = []
    version = None
    for file in [Path.home()/'.aurral', Path('/root/.aurral')]:
        candidate = read_text(file)
        if candidate and re.fullmatch(r'v?\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.]+)?',candidate):
            version = candidate
            break
    previous = None
    group = system_property('ControlGroup')
    service_group = None
    if group and group.startswith('/'):
        candidate = (Path('/sys/fs/cgroup') / group.lstrip('/')).resolve()
        if candidate.is_relative_to(Path('/sys/fs/cgroup')) and candidate.is_dir():
            service_group = candidate
    deadline = time.monotonic() + args.observe_seconds
    print('Reading existing history and observing for %g seconds. Leave Aurral running normally.' % args.observe_seconds, flush=True)
    latest = initial
    interrupted = False
    progress_at = time.monotonic() + 60
    try:
        while True:
            resource, previous = sample_resources(previous, service_group, args.cpu_budget)
            try:
                latest = snapshot(database, cutoff, warnings)
                for run in latest['worker_runs']:
                    if run['id'] in runs or len(runs) < LIMIT:
                        runs[run['id']] = run
                    else:
                        warnings.add('Observed worker run limit reached; stage data incomplete.')
                resource['pipeline_queue'] = latest['pipeline_queue']
                resource['job_status_counts'] = dict(collections.Counter(j['status'] for j in latest['jobs']))
            except sqlite3.Error:
                warnings.add('At least one live database sample failed; initial historical snapshot is preserved.')
                resource['database_sample_failed'] = True
            observations.append(resource)
            left = deadline - time.monotonic()
            if left <= 0:
                break
            if time.monotonic() >= progress_at:
                print('Sampling normally; about %d seconds remaining.' % math.ceil(left),flush=True)
                progress_at = time.monotonic() + 60
            time.sleep(min(args.interval, left))
    except KeyboardInterrupt:
        interrupted = True
        warnings.add('Observation stopped early by user; report contains samples collected so far.')
    report = {'format': 'aurral-baseline-v1', 'collector_revision': '1.1', 'helper_recorded_version': version, 'collector_started_utc': utc(start), 'cpu_budget': args.cpu_budget,
              'observation_seconds': round((time.time()*1000-start)/1000, 2), 'observation_interrupted': interrupted,
              'historical_summary': job_summary(initial['jobs'],cutoff,start),
              'live_window_summary': job_summary(latest['jobs'], start, max(start+1, latest['captured_at'])),
              'historical_jobs': initial['jobs'], 'final_jobs': latest['jobs'], 'worker_runs': sorted(runs.values(),key=lambda r:r['id']),
              'configuration': initial['configuration'], 'historical_activity_entry_counts': initial['activity_entry_counts'],
              'resource_samples': observations, 'stage_summary': stage_summary(runs.values()),
              'stage_coverage': {'earliest_retained_start_utc': utc(min(r['started_at'] for r in runs.values())*1000) if runs else None,
                                 'latest_retained_start_utc': utc(max(r['started_at'] for r in runs.values())*1000) if runs else None,
                                 'retained_worker_runs': len(runs)},
              'resource_summary': {
                  'cpu_percent_of_budget': distribution(s['app_cpu_percent_of_budget'] for s in observations),
                  'service_memory_mib': distribution(s['app_service_cgroup'].get('memory.current',0)/1024**2 for s in observations if s['app_service_cgroup'] and isinstance(s['app_service_cgroup'].get('memory.current'),int)),
                  'process_rss_mib': distribution(s['app_summed_rss_bytes']/1024**2 for s in observations if s['app_detected']),
                  'process_swap_mib': distribution(s['app_process_swap_bytes']/1024**2 for s in observations if s['app_detected'])},
              'limitations': sorted(warnings) + [
                  'Historical totals describe retained current job records, not an append-only lifetime ledger; deleted/reset jobs and repeat completions can be missing.',
                  'A done job means downloaded/imported work; file reuse is counted separately. Distinct jobs can reference the same recording.',
                  'Source-attributed throughput excludes unknown-source non-reuse records, which can be created when indexing existing library files.',
                  'Queue-to-completion includes waiting/retries. started_at can reset during searches/retries: latest-start elapsed time is not total processing time or actual transfer time.',
                  'Only completed downloads enter elapsed-time averages; pending, blocked and failed jobs remain separate to expose survivor bias.',
                  'Hourly throughput includes zero-completion/idle intervals; uptime for the historical window is unknown.',
                  'The v2.11 worker-run ledger is pruned after roughly one hour. Stage timings cover retained recent runs plus this observation, not necessarily the full historical window.',
                  'Worker duration has one-second timestamp precision and includes waits/locks. Zero-second samples do not mean zero work.',
                  'Activity history overwrites the entry for a job and is pruned; its counts are supplementary, not extra completions.',
                  'CPU/memory/swap are sampled now; short spikes or exited subprocesses can be missed. CPU uses the systemd service cgroup where available, otherwise surviving process estimates.',
                  'Summed process RSS can double-count shared pages; service cgroup memory includes cache. Container-visible cgroup scope depends on the LXC configuration.',
                  'No live download was initiated, settings changed, or service restarted by this collector.',
              ]}
    if not any(s['app_detected'] for s in observations):
        report['limitations'].insert(0,'Aurral process not detected; application CPU/memory/swap are unavailable, not zero.')
    with gzip.open(json_path, 'xt', encoding='utf-8') as handle:
        json.dump(report,handle,ensure_ascii=True,allow_nan=False,indent=2)
    with md_path.open('x') as handle:
        handle.write(render(report))
    merged_jobs = {j['job']: j for j in initial['jobs']}
    merged_jobs.update({j['job']: j for j in latest['jobs']})
    with csv_path.open('x',newline='') as handle:
        fields = ['job','source','status','reused_library_file','created_utc','latest_start_utc','completed_utc',
                  'queue_to_completion_seconds','latest_start_to_completion_seconds','unfinished_age_seconds']
        writer = csv.DictWriter(handle,fieldnames=fields)
        writer.writeheader()
        for job in sorted(merged_jobs.values(),key=lambda j:j['created_at']):
            row = {key: job.get(key) for key in fields if key in job}
            for key,source in [('created_utc','created_at'),('latest_start_utc','started_at'),('completed_utc','completed_at')]:
                row[key] = utc(job[source]) if job[source] is not None else None
            row['unfinished_age_seconds'] = span(latest['captured_at'],job['created_at']) if job['status'] not in {'done','failed','cancelled','denied'} else None
            writer.writerow(row)
    print('Saved %s, %s and %s' % (md_path,json_path,csv_path))
    print('Source-attributed completions in historical window: %s; %.3f per hour.' %
          (report['historical_summary']['source_attributed_completions'],report['historical_summary']['source_attributed_completions_per_hour']))
    print('Source-attributed completions during observation: %s; %.3f per hour (short-window estimate).' %
          (report['live_window_summary']['source_attributed_completions'],report['live_window_summary']['source_attributed_completions_per_hour']))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (RuntimeError, sqlite3.Error, OSError) as error:
        print('Collection failed (%s). %s' % (type(error).__name__, str(error) if isinstance(error,RuntimeError) else
              'Check database permissions/path and that the output directory is writable. No application changes were made.'),file=sys.stderr)
        sys.exit(1)
