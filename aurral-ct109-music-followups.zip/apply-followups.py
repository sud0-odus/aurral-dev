#!/usr/bin/env python3
"""Apply the two reviewed CT109 follow-ups, then start a detached profile."""
import argparse
from pathlib import Path
import subprocess
import sys

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--install',action='store_true',required=True)
    parser.add_argument('--hours',type=float,default=1)
    args=parser.parse_args()
    if not 0<args.hours<=24:parser.error('Use 0 < hours <= 24.')
    root=Path(__file__).resolve().parent
    queue=root/'queue'/ 'apply-patch.py'
    apple=root/'apple'/'apply-patch.py'
    def run(script,*arguments):subprocess.run([sys.executable,str(script),*arguments],check=True)
    # Verify both inputs before stopping any service.
    run(queue,'--check');run(apple,'--check')
    run(queue,'--install');run(queue,'--enable')
    run(apple,'--install')
    run(root/'queue'/'start-profile.py','--hours',str(args.hours))
    print('Done. Leave Aurral running normally. Close the old Apple popup and retry Connect Apple Music.')
if __name__=='__main__':
    try:main()
    except subprocess.CalledProcessError:
        print('STOPPED at the failed step. Read its message; later steps were not run.',file=sys.stderr)
        sys.exit(1)
