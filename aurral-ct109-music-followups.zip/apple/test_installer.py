import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('installer',Path(__file__).with_name('apply-patch.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class InstallerTests(unittest.TestCase):
 def setUp(self):
  temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);root=Path(temp.name)
  self.app=root/'browser';self.app.mkdir();self.kit=root/'kit';self.kit.mkdir()
  self.old=b'print("old")\n';self.new=b'print("new")\n'
  (self.app/'bridge.py').write_bytes(self.old);(self.app/'bridge.py').chmod(0o640)
  (self.app/'pairing.key').write_text('preserve private pairing');(self.kit/'bridge.py').write_bytes(self.new)
  self.config=root/'config.json';self.config.write_text('{}')
  self.args=argparse.Namespace(root=self.app,config=self.config,state=root/'state.json',backups=root/'backups')
  manifest={'patch':'test','before_sha256':hashlib.sha256(self.old).hexdigest(),'after_sha256':hashlib.sha256(self.new).hexdigest()}
  for name,value in [('KIT',self.kit),('MANIFEST',manifest)]:
   p=patch.object(m,name,value);p.start();self.addCleanup(p.stop)
  self.active=True;self.calls=[]
  def service(*args):
   self.calls.append(args)
   if args[0]=='stop':self.active=False
   if args[0]=='start':self.active=True
   return types.SimpleNamespace(returncode=(0 if self.active else 3) if args[0]=='is-active' else 0)
  p=patch.object(m,'service',side_effect=service);p.start();self.addCleanup(p.stop)
 def test_install_and_rollback_preserve_pairing_and_owner_mode(self):
  with patch.object(m,'healthy',return_value=True):m.install(self.args)
  self.assertTrue(self.active);self.assertEqual((self.app/'bridge.py').read_bytes(),self.new)
  self.assertEqual((self.app/'bridge.py').stat().st_mode&0o777,0o640)
  self.assertEqual((self.app/'pairing.key').read_text(),'preserve private pairing')
  self.assertEqual(self.args.state.stat().st_mode&0o777,0o600)
  with patch.object(m,'healthy',return_value=True):m.rollback(self.args)
  self.assertTrue(self.active);self.assertEqual((self.app/'bridge.py').read_bytes(),self.old)
 def test_unknown_input_stops_before_service_changes(self):
  (self.app/'bridge.py').write_text('different')
  with self.assertRaisesRegex(RuntimeError,'differs'):m.install(self.args)
  self.assertEqual(self.calls,[])
 def test_failed_health_remains_stopped_and_can_rollback(self):
  with patch.object(m,'healthy',return_value=False),patch.object(m.time,'sleep'):
   with self.assertRaisesRegex(RuntimeError,'health check failed'):m.install(self.args)
  self.assertFalse(self.active);self.assertTrue(self.args.state.is_file())
  with patch.object(m,'healthy',return_value=True):m.rollback(self.args)
  self.assertTrue(self.active)
 def test_later_edit_prevents_rollback(self):
  with patch.object(m,'healthy',return_value=True):m.install(self.args)
  (self.app/'bridge.py').write_text('later edit');self.calls.clear()
  with self.assertRaisesRegex(RuntimeError,'differs'):m.rollback(self.args)
  self.assertEqual(self.calls,[])
if __name__=='__main__':unittest.main()
