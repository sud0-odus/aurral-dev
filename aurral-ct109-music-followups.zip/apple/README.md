# Hosted Apple browser screenshot follow-up

Requires the installed Apple connect preview. Updates only bridge.py and restarts
only aurral-apple-browser.service. It preserves Aurral, the DB, TLS pairing files,
Chromium dependencies, service unit and resource limits.

Playwright screenshots can wait indefinitely for page fonts. A real Chromium
fixture reproduced the old timeout while a font remained pending; CDP compositor
capture returned a valid frame in 0.027 seconds. This removes that reproduced
failure mode, but the original production TimeoutError did not identify which
operation failed. New logs identify operation and exception class without input
or credentials. The CT memory admission fallback handles an unlimited visible
cgroup using LXC's available-memory view. Capture retains a 15-second browser
watchdog; existing service memory/CPU/time limits remain unchanged.

```
python3 apply-patch.py --check
python3 apply-patch.py --install
```
Then close the old popup and click Connect Apple Music again. Existing temporary
Apple sessions are cleared by this service restart. Apple authentication still
requires a live test on CT109. On failure:
```
journalctl -u aurral-apple-browser --since "10 minutes ago" -n 30 --no-pager
```
Rollback restores the checksum-verified prior browser and checks authenticated
HTTPS health; it preserves pairing and does not restart Aurral:
```
python3 apply-patch.py --rollback
```
Validation: 16 browser unit tests and 4 guarded installer tests passed. Real
Chromium control/capture/profile-cleanup smoke and the pending-font regression
passed. Actual bridge payload install/rollback passed with mocked service calls.
