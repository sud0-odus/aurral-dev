import importlib.util
import json
import os
from pathlib import Path
import threading
import time
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('bridge', Path(__file__).with_name('bridge.py'))
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)


class FakeEngine:
    def __init__(self):
        self.closed = False
        self.ready = False
        self.events = []
        self.secret = {'Authorization': 'Bearer PRIVATE_TOKEN', 'Music-User-Token': 'PRIVATE_USER'}
    def tick(self): time.sleep(0.002)
    def input(self, events): self.events.extend(events)
    def screenshot(self): return b'jpeg'
    def authenticated_headers(self): return self.secret if self.ready else None
    def close(self): self.closed = True


def wait_for(predicate, timeout=3):
    end = time.monotonic() + timeout
    while not predicate() and time.monotonic() < end: time.sleep(0.005)
    if not predicate(): raise AssertionError('condition timed out')


class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.now = 10
        self.engines = []
        def factory():
            e = FakeEngine(); self.engines.append(e); return e
        self.manager = bridge.Manager(factory, clock=lambda: self.now)
        self.addCleanup(self.manager.shutdown)
    def start(self, user='1'):
        result = self.manager.start(user)
        wait_for(lambda: self.manager.get(user,result['id'])['state']=='signing_in')
        return result['id']
    def test_credentials_never_returned_and_browser_closes_before_connected(self):
        sid=self.start()
        self.engines[0].ready=True;self.now+=6
        wait_for(lambda:self.manager.get('1',sid)['state']=='connected')
        self.assertTrue(self.engines[0].closed)
        public=json.dumps([self.manager.status('1'),self.manager.get('1',sid)])
        self.assertNotIn('PRIVATE',public)
        self.assertFalse(self.manager.get('1',sid)['browserRunning'])
        self.assertTrue(self.manager.status('1')['connected'])
    def test_users_cannot_read_type_into_or_cancel_each_others_browser(self):
        sid=self.start()
        for action in [lambda:self.manager.get('2',sid),lambda:self.manager.input('2',sid,[{'kind':'text','text':'secret'}]),lambda:self.manager.cancel('2',sid)]:
            with self.assertRaises(bridge.BridgeError) as result: action()
            self.assertEqual(result.exception.status,404)
        with self.assertRaises(bridge.BridgeError) as result:self.manager.start('2')
        self.assertEqual(result.exception.status,409)
        self.assertFalse(self.manager.status('2')['connected'])
    def test_cancel_discards_typed_input_and_closes_browser(self):
        sid=self.start();self.manager.input('1',sid,[{'kind':'text','text':'PRIVATE_PASSWORD'}])
        self.manager.cancel('1',sid)
        wait_for(lambda:self.manager.active is None)
        self.assertTrue(self.engines[0].closed)
        self.assertFalse(self.manager.status('1')['connected'])
        self.assertTrue(self.manager.sessions[sid]['events'].empty())
    def test_repeated_connect_does_not_launch_another_browser(self):
        sid=self.start()
        self.assertEqual(self.manager.start('1')['id'],sid)
        self.assertEqual(len(self.engines),1)
    def test_closed_popup_idle_timeout_releases_browser(self):
        sid=self.start();self.now+=bridge.IDLE_TTL+1
        wait_for(lambda:self.manager.active is None)
        self.assertEqual(self.manager.get('1',sid)['state'],'expired')
        self.assertTrue(self.engines[0].closed)
    def test_absolute_timeout_is_not_extended_by_polling(self):
        sid=self.start();self.now+=bridge.SIGNIN_TTL+1
        self.manager.get('1',sid)
        wait_for(lambda:self.manager.active is None)
        self.assertEqual(self.manager.get('1',sid)['state'],'expired')
    def test_capture_does_not_persist_after_cancel_race(self):
        sid=self.start();self.engines[0].ready=True;self.now+=6
        wait_for(lambda:self.manager.active is None)
        self.assertTrue(self.manager.status('1')['connected'])
        self.manager.cancel('1',sid)
        self.assertFalse(self.manager.status('1')['connected'])
    def test_session_expiry_requires_reauthentication_not_another_browser(self):
        sid=self.start();self.engines[0].ready=True;self.now+=6
        wait_for(lambda:self.manager.active is None)
        self.now+=bridge.SESSION_TTL+1
        self.assertFalse(self.manager.status('1')['connected'])
        self.assertEqual(len(self.engines),1)
    def test_factory_failure_frees_admission_and_exposes_no_exception(self):
        def fail():raise RuntimeError('PRIVATE filesystem and token')
        self.manager.factory=fail
        sid=self.manager.start('1')['id']
        wait_for(lambda:self.manager.active is None)
        self.assertEqual(self.manager.get('1',sid)['state'],'failed')
        self.assertNotIn('PRIVATE',json.dumps(self.manager.get('1',sid)))
    def test_cleanup_failure_cannot_be_reported_as_connected(self):
        sid=self.start();self.engines[0].ready=True
        self.engines[0].close=lambda:(_ for _ in ()).throw(RuntimeError('PRIVATE'))
        self.now+=6;wait_for(lambda:self.manager.active is None)
        self.assertFalse(self.manager.status('1')['connected'])
        self.assertEqual(self.manager.get('1',sid)['state'],'failed')
    def test_two_users_credentials_are_isolated_after_sequential_signins(self):
        for user in ['1','2']:
            self.start(user);self.engines[-1].secret={'user':user};self.engines[-1].ready=True;self.now+=6
            wait_for(lambda:self.manager.active is None)
        self.manager.cancel('1')
        self.assertFalse(self.manager.status('1')['connected'])
        self.assertTrue(self.manager.status('2')['connected'])
    def test_memory_pressure_refuses_launch_before_a_browser_is_created(self):
        with patch.object(bridge,'ensure_memory_headroom',side_effect=bridge.BridgeError('Not enough free memory',503)):
            with self.assertRaises(bridge.BridgeError) as result:self.manager.start('1')
        self.assertEqual(result.exception.status,503)
        self.assertEqual(self.engines,[])
        self.assertIsNone(self.manager.active)
    def test_ct_memory_limit_not_host_ram_controls_admission(self):
        import tempfile
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            (root/'memory.max').write_text(str(4*1024**3))
            (root/'memory.current').write_text(str(3*1024**3))
            with patch.object(bridge,'Path',return_value=root):
                with self.assertRaises(bridge.BridgeError):bridge.ensure_memory_headroom()
                (root/'memory.current').write_text(str(2*1024**3))
                bridge.ensure_memory_headroom()
    def test_screen_capture_does_not_wait_for_document_fonts(self):
        import types,base64
        engine=object.__new__(bridge.BrowserEngine)
        page=object()
        calls=[]
        session=types.SimpleNamespace(send=lambda method,params:(calls.append(method) or {'data':base64.b64encode(b'jpeg').decode()}))
        engine.capture_session=None;engine.capture_page=None;engine.driver_pid=None
        engine.current_page=lambda:page
        engine.context=types.SimpleNamespace(new_cdp_session=lambda p:session)
        self.assertEqual(engine.screenshot(),b'jpeg')
        self.assertEqual(calls,['Page.captureScreenshot'])
    def test_only_apple_destinations_are_allowed(self):
        for url in ['https://music.apple.com/','https://idmsa.apple.com/','https://is1-ssl.mzstatic.com/image/']:
            self.assertTrue(bridge.allowed_url(url))
        for url in ['https://apple.com.evil.test/','http://music.apple.com/','https://127.0.0.1/','file:///etc/passwd','https://evil.test/apple.com']:
            self.assertFalse(bridge.allowed_url(url))
    def test_input_is_bounded_and_not_executable_code(self):
        for events in [[{'kind':'text','text':'x'*2049}], [{'kind':'click','x':-1,'y':0}], [{'kind':'key','key':'Control+l'}], [{'kind':'evaluate','text':'javascript'}], []]:
            with self.assertRaises(bridge.BridgeError):bridge.validate_events(events)
        self.assertEqual(bridge.validate_events([{'kind':'text','text':'legitimate paste'}])[0]['text'],'legitimate paste')

if __name__=='__main__':unittest.main()
