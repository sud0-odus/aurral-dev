import { appleArtwork } from "./metadata.js";
export async function fetchAppleArtwork(value, fetcher = fetch) {
  const url=appleArtwork(value);if(!url)return null;
  const response=await fetcher(url,{redirect:"error",signal:AbortSignal.timeout(10000)});
  if(!response.ok||!response.headers.get("content-type")?.startsWith("image/")){await response.body?.cancel();return null;}
  const reader=response.body.getReader();let size=0;const chunks=[];
  try{while(true){const{done,value:chunk}=await reader.read();if(done)break;size+=chunk.length;if(size>4000000)throw new Error("Source artwork exceeded its limit");chunks.push(Buffer.from(chunk));}}
  finally{try{await reader.cancel();}catch{/* Preserve the original error. */}}
  return Buffer.concat(chunks);
}
