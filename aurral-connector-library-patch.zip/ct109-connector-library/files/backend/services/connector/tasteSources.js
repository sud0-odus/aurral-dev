import crypto from "node:crypto";
import { dbOps } from "../../db/helpers/index.js";
export class TasteSourceError extends Error {}
const key = id => `personalTasteSourcesV1:${id}`;
const normalized = value => String(value || "").normalize("NFKC").trim().toLocaleLowerCase().replace(/\s+/g, " ");
export const tasteSourceKey = source => `${source.service}:${source.kind}:${source.id}`;
export function readTasteProfile(userId) { return dbOps.getJSONSetting(key(userId)) || { revision: "none", sources: [] }; }
export function tasteRevision(userId) { return readTasteProfile(userId).revision; }
export function upsertTasteSource(userId, source, tracks) {
  if (!Number.isSafeInteger(Number(userId)) || Number(userId) < 1) throw new Error("A user account is required");
  if (!source?.service || !source?.id || !["library", "catalog"].includes(source.kind) || !Array.isArray(tracks) || !tracks.length || tracks.length > 3000) throw new Error("Complete source metadata is required");
  const counts = new Map();
  for (const track of tracks) {
    const name = String(track.artistName || "").trim().slice(0, 250), identity = normalized(name);
    if (!identity || ["various artists", "unknown artist"].includes(identity)) continue;
    const artist = counts.get(identity) || { artistName: name, count: 0 }; artist.count++; counts.set(identity, artist);
  }
  const artists = [...counts.values()].sort((a, b) => b.count - a.count || a.artistName.localeCompare(b.artistName)).slice(0, 500);
  if (!artists.length) throw new TasteSourceError("This source has no usable artist metadata for recommendations.");
  const artistDigest = crypto.createHash("sha256").update(JSON.stringify(artists.map(artist=>({name:normalized(artist.artistName),count:Math.min(5,artist.count)})).sort((a,b)=>a.name.localeCompare(b.name)))).digest("hex");
  const snapshot = { service: source.service, kind: source.kind, id: source.id, name: source.name, artworkUrl: source.artworkUrl || null, artworkKind: source.artworkKind || "playlist", trackCount: tracks.length, artists };
  const digest = crypto.createHash("sha256").update(JSON.stringify(snapshot)).digest("hex");
  const profile = readTasteProfile(userId); const id = tasteSourceKey(snapshot);
  const existing = profile.sources.find(item => tasteSourceKey(item) === id);
  if (existing?.digest === digest) return { changed: false, tasteChanged: false, source: existing };
  if (!existing && profile.sources.length >= 64) throw new TasteSourceError("Remove an old recommendation source before adding another");
  const tasteChanged = !existing || existing.artistDigest !== artistDigest;
  const next = { ...snapshot, digest, artistDigest, importedAt: Date.now() };
  const sources = profile.sources.filter(item => tasteSourceKey(item) !== id); sources.push(next);
  dbOps.setJSONSetting(key(userId), { revision: tasteChanged ? crypto.randomUUID() : profile.revision, sources });
  return { changed: true, tasteChanged, source: next };
}
export function removeTasteSource(userId, sourceKey) {
  const profile = readTasteProfile(userId);const sources = profile.sources.filter(source => tasteSourceKey(source) !== sourceKey);
  if (sources.length === profile.sources.length) return false;
  dbOps.setJSONSetting(key(userId), { revision: crypto.randomUUID(), sources });return true;
}
export function tasteArtists(userId) {
  const artists = new Map();
  for (const source of readTasteProfile(userId).sources) for (const entry of source.artists) {
    const identity = normalized(entry.artistName);const artist = artists.get(identity) || { artistName: entry.artistName, sources: 0, occurrences: 0 };
    artist.sources++;artist.occurrences += Math.min(5, entry.count);artists.set(identity, artist);
  }
  return [...artists.values()].sort((a,b) => b.sources-a.sources || b.occurrences-a.occurrences || a.artistName.localeCompare(b.artistName)).slice(0,1000)
    .map(artist => ({ artistName: artist.artistName, source: "imported", profileBucket: "imported", affinityWeight: 1.15 + Math.min(0.6,Math.log1p(artist.sources)*0.2) }));
}
export function publicTasteProfile(userId) {
  const profile = readTasteProfile(userId);
  return { revision: profile.revision, artistCount: tasteArtists(userId).length,
    sources: profile.sources.map(({ service, kind, id, name, artworkUrl, trackCount, importedAt }) => ({ key: `${service}:${kind}:${id}`, service, kind, id, name, artworkUrl, trackCount, importedAt })) };
}
