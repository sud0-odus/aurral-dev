// Each service owns validation; credentials never follow a redirect to another origin.
export class ConnectorValidationError extends Error {
  constructor(code, message, providerStatus = null) { super(message); this.code = code; this.providerStatus = providerStatus; }
}
const fail = (code, message, status) => new ConnectorValidationError(code, message, status);
let cached, pending;
async function boundedRead(url, maximum, fetcher, stage, extract = null) {
  const origin = new URL(url).origin;
  let current = url;
  const signal = AbortSignal.timeout(15000);
  for (let hop = 0; hop < 5; hop++) {
    let response;
    try { response = await fetcher(current, { signal, redirect: "manual", headers: { "User-Agent": "Mozilla/5.0" } }); }
    catch { throw fail(`${stage}_NETWORK`, "Aurral could not reach Apple's service. Check its outbound connection and try again."); }
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      await response.body?.cancel();
      let target; try { target = new URL(response.headers.get("location"), current); } catch { /* Reject malformed redirects below. */ }
      if (!response.headers.get("location") || !target || target.origin !== origin || target.username || target.password) {
        throw fail(`${stage}_REDIRECT`, "Apple redirected to an unexpected host. The connector stopped without forwarding the session.");
      }
      current = target.href; continue;
    }
    if (!response.ok) {
      await response.body?.cancel();
      const message = ["APPLE_SESSION", "APPLE_LIBRARY"].includes(stage) && [401, 403].includes(response.status)
        ? "Apple rejected this session. Sign into the intended account on music.apple.com, then create a fresh connection request."
        : `Apple returned HTTP ${response.status} while Aurral was checking ${["APPLE_SESSION", "APPLE_LIBRARY"].includes(stage) ? "library access" : "web authorization"}.`;
      throw fail(`${stage}_HTTP`, message, response.status);
    }
    const reader = response.body?.getReader();
    if (!reader) throw fail(`${stage}_EMPTY`, "Apple returned an empty response.");
    const chunks = []; let size = 0;
    const decoder = extract ? new TextDecoder() : null;
    let window = "";
    try {
      while (true) {
        let chunk; try { chunk = await reader.read(); } catch { throw fail(`${stage}_NETWORK`, "Apple's response was interrupted. Try a fresh connection request."); }
        if (chunk.done) break;
        size += chunk.value.length;
        if (size > maximum) throw fail(`${stage}_SIZE`, "Apple's response exceeded the connector's size limit.");
        if (extract) {
          // Keep at most 128K decoded characters. Process chunks in pieces so a
          // match cannot be skipped even if the transport supplies a large chunk.
          for (let offset = 0; offset < chunk.value.length; offset += 16384) {
            window = (window + decoder.decode(chunk.value.subarray(offset, offset + 16384), { stream: true })).slice(-131072);
            const found = extract(window, false);
            if (found != null) return found;
          }
        } else chunks.push(Buffer.from(chunk.value));
      }
    } finally { try { await reader.cancel(); } catch { /* Preserve the safe original failure. */ } }
    if (extract) return extract((window + decoder.decode()).slice(-131072), true);
    return Buffer.concat(chunks).toString("utf8");
  }
  throw fail(`${stage}_REDIRECT_LIMIT`, "Apple redirected too many times. The connector stopped the request.");
}
const PUBLIC_SCAN_LIMIT = 32 * 1024 * 1024;
function findValidAppleToken(text, final = false) {
  const scan = final ? `${text}\n` : text;
  // JWT JSON headers start with eyJ. A specific prefix and finite segment sizes
  // avoid broad regex backtracking through embedded image/base64 data.
  for (const match of scan.matchAll(/eyJ[A-Za-z0-9_-]{12,20480}\.[A-Za-z0-9_-]{15,20480}\.[A-Za-z0-9_-]{10,20480}(?=[^A-Za-z0-9_-])/g)) {
    const token = match[0];
    try {
      const claims = JSON.parse(Buffer.from(token.split(".")[1], "base64url"));
      if (claims.iss === "AMPWebPlay" && claims.exp * 1000 > Date.now() + 60000) return { token, expires: claims.exp * 1000 };
    } catch { /* Ignore unrelated bundle strings. */ }
  }
  return null;
}
export async function discoverAppleWebToken(fetcher = fetch) {
  const bundle = await boundedRead("https://music.apple.com/us/browse", PUBLIC_SCAN_LIMIT, fetcher, "APPLE_WEB_PAGE",
    text => text.match(/\/assets\/index~[A-Za-z0-9]{1,128}\.js/)?.[0] || null);
  if (!bundle) throw fail("APPLE_WEB_BUNDLE_MISSING", "Apple's page did not expose a recognized web-player bundle. The connector needs a format update.");
  const result = await boundedRead(`https://music.apple.com${bundle}`, PUBLIC_SCAN_LIMIT, fetcher, "APPLE_WEB_BUNDLE", findValidAppleToken);
  if (!result) throw fail("APPLE_WEB_TOKEN_MISSING", "Apple's web-player authorization token could not be found. No session was saved.");
  return result;
}

export async function getAppleWebToken(fetcher = fetch) {
  if (cached?.expires > Date.now()) return cached.token;
  if (pending) return pending;
  pending = (async () => {
    const result = await discoverAppleWebToken(fetcher);
    cached = { token: result.token, expires: Math.min(result.expires - 60000, Date.now() + 3600000) };
    return result.token;
  })();
  try { return await pending; } finally { pending = null; }
}
async function validateAppleSession(credential, { fetcher = fetch, webToken = getAppleWebToken } = {}) {
  if (typeof credential?.session !== "string" || !credential.session || credential.session.length > 16000 || /[\r\n]/.test(credential.session)) throw fail("APPLE_SESSION_INVALID", "The connector did not supply a valid Apple session. Create a fresh request.");
  const authorization = await webToken(fetcher);
  const headers = { Authorization: `Bearer ${authorization}`, "Music-User-Token": credential.session, Origin: "https://music.apple.com", Referer: "https://music.apple.com/" };
  const text = await boundedRead("https://amp-api.music.apple.com/v1/me/library/playlists?limit=1", 1000000,
    (url, options) => fetcher(url, { ...options, headers: { ...options.headers, ...headers } }), "APPLE_SESSION");
  let body; try { body = JSON.parse(text); } catch { throw fail("APPLE_SESSION_FORMAT", "Apple returned an unexpected response while checking the session."); }
  if (!Array.isArray(body.data)) throw fail("APPLE_SESSION_FORMAT", "Apple did not confirm access to this account's library.");
  return { credentials: { session: credential.session }, expires: Number.isFinite(credential.expires) && credential.expires > Date.now() ? credential.expires : null };
}
const registry = new Map([
  ["apple", { id: "apple", name: "Apple Music", method: "browser-session", library: true, validate: validateAppleSession }],
]);
export const connectorServices = [...registry.values()].map(({ id, name, method, library }) => ({ id, name, method, library: library === true }));
export async function validateConnectorSession(service, credential, options) {
  const adapter = registry.get(service);
  if (!adapter) throw fail("CONNECTOR_SERVICE_UNSUPPORTED", "This service is not supported by the connector.");
  return adapter.validate(credential, options);
}

export async function appleWebJSON(path, session, { fetcher = fetch } = {}) {
  const url = new URL(path, "https://amp-api.music.apple.com");
  if (url.origin !== "https://amp-api.music.apple.com" || url.username || url.password || url.hash || !url.pathname.startsWith("/v1/")) throw fail("APPLE_LIBRARY_PATH", "Unexpected Apple library path.");
  const token = await getAppleWebToken(fetcher);
  const headers = { Authorization: `Bearer ${token}`, "Music-User-Token": session, Origin: "https://music.apple.com", Referer: "https://music.apple.com/" };
  const text = await boundedRead(url.href, 1000000, (target, options) => fetcher(target, { ...options, headers: { ...options.headers, ...headers } }), "APPLE_LIBRARY");
  try { return JSON.parse(text); } catch { throw fail("APPLE_LIBRARY_FORMAT", "Apple returned invalid library data."); }
}
