export function appleArtwork(value) {
  const raw = typeof value === "string" ? value : value?.url;
  if (typeof raw !== "string" || raw.length > 3000) return null;
  try {
    const url = new URL(raw.replaceAll("{w}", "600").replaceAll("{h}", "600").replaceAll("{f}", "jpg"));
    if (url.protocol !== "https:" || url.username || url.password || !url.hostname.endsWith(".mzstatic.com")) return null;
    return url.href;
  } catch { return null; }
}
export function sourceText(value, limit = 250) {
  const text = typeof value === "string" ? value : value?.stringForDisplay;
  return String(text || "").trim().slice(0, limit);
}
export function appleTrack(item) {
  const attributes = item?.attributes || {};
  const artistName = sourceText(attributes.artistName);
  const trackName = sourceText(attributes.name);
  if (!artistName || !trackName) return null;
  return { artistName, trackName, albumName: sourceText(attributes.albumName),
    durationMs: Number.isFinite(attributes.durationInMillis) && attributes.durationInMillis > 0 ? Math.round(attributes.durationInMillis) : null,
    sourceService: "apple", sourceTrackId: sourceText(item.id, 120), artworkUrl: appleArtwork(attributes.artwork),
    ...(Number.isInteger(attributes.trackNumber) && attributes.trackNumber > 0 ? { trackNumber: attributes.trackNumber } : {}),
    ...(Number.isInteger(attributes.discNumber) && attributes.discNumber > 0 ? { discNumber: attributes.discNumber } : {}),
  };
}
