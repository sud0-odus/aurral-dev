import { createHash } from "node:crypto";
import { requireAuth, requireUserAccount } from "../../middleware/requirePermission.js";
import { createAppleLibrary, withAppleRead } from "../../services/connector/appleLibrary.js";
import { publicTasteProfile, upsertTasteSource, removeTasteSource, TasteSourceError } from "../../services/connector/tasteSources.js";
import { ConnectorValidationError } from "../../services/connector/adapters.js";
import { requestUserDiscoveryRefresh } from "../../services/discovery/provider.js";
import { flowPlaylistConfig } from "../../services/playlists/flowPlaylistConfig.js";
import { playlistOperationQueue } from "../../services/playlists/playlistOperationQueue.js";
const adapters = new Map([["apple", { create: createAppleLibrary, read: withAppleRead }]]);
function playlistId(userId, source) {
  const hex=createHash("sha256").update(`${userId}:${source.service}:${source.kind}:${source.id}`).digest("hex").slice(0,32);
  return `${hex.slice(0,8)}-${hex.slice(8,12)}-5${hex.slice(13,16)}-a${hex.slice(17,20)}-${hex.slice(20)}`;
}
export function registerConnectorLibrary(router, { adapterRegistry = adapters, refresh = requestUserDiscoveryRefresh, queue = playlistOperationQueue } = {}) {
  const guard=[requireAuth, requireUserAccount];
  const enqueueRefresh=userId=>{try{return refresh(userId,{reason:"imported-taste-updated"});}catch{return{enqueued:false,reason:"refresh_will_retry"};}};
  const wrap=fn=>async(req,res)=>{res.set("Cache-Control","no-store");try{await fn(req,res);}catch(error){res.status(400).json({error:error instanceof ConnectorValidationError||error instanceof TasteSourceError?error.message:"The library action could not complete. No partial source was imported.",code:error instanceof ConnectorValidationError?error.code:"CONNECTOR_LIBRARY_FAILED"});}};
  const read=(req,operation)=>{
    const adapter=adapterRegistry.get(req.params.service);
    if(!adapter)throw new ConnectorValidationError("CONNECTOR_LIBRARY_UNSUPPORTED","This service does not yet support library browsing.");
    return adapter.read(req.user.id,()=>operation(adapter.create(req.user.id)));
  };
  const root="/me/connector";
  router.get(`${root}/preferences`,...guard,wrap((req,res)=>res.json(publicTasteProfile(req.user.id))));
  router.delete(`${root}/preferences/:key`,...guard,wrap((req,res)=>{const changed=removeTasteSource(req.user.id,req.params.key);if(changed)enqueueRefresh(req.user.id);res.json({changed,...publicTasteProfile(req.user.id)});}));
  router.get(`${root}/services/:service/library`,...guard,wrap(async(req,res)=>res.json({playlists:await read(req,client=>client.list())})));
  router.get(`${root}/services/:service/groups`,...guard,wrap(async(req,res)=>res.json({groups:await read(req,client=>client.groups())})));
  router.get(`${root}/services/:service/groups/:id`,...guard,wrap(async(req,res)=>res.json({playlists:await read(req,client=>client.group(req.params.id))})));
  router.get(`${root}/services/:service/playlists/:kind/:id`,...guard,wrap(async(req,res)=>res.json(await read(req,client=>client.playlist(req.params.kind,req.params.id)))));
  router.post(`${root}/services/:service/preferences`,...guard,wrap(async(req,res)=>{
    const result=await read(req,async client=>{const data=await client.playlist(req.body?.kind,req.body?.id);client.context.assertCurrent();return upsertTasteSource(req.user.id,data.source,data.tracks);});
    if(result.tasteChanged)enqueueRefresh(req.user.id);
    res.json({changed:result.changed,preferences:publicTasteProfile(req.user.id)});
  }));
  router.post(`${root}/services/:service/import-playlist`,...guard,wrap(async(req,res)=>{
    if(req.body?.downloadMissing!==true)return res.status(400).json({error:"Adding a playlist requires explicitly requesting its download queue."});
    const result=await read(req,async client=>{
      const {source,tracks}=await client.playlist(req.body?.kind,req.body?.id);client.context.assertCurrent();
      const own=flowPlaylistConfig.getStaticPlaylistsOwnedByUser(req.user.id);
      const linked=own.find(p=>p.importSource?.provider==="apple-playlist"&&p.importSource.externalId===`${source.kind}:${source.id}`);
      if(linked)return{alreadyImported:true,playlistId:linked.id};
      const legacy=own.filter(p=>p.sourceName==="Apple Music"&&p.name.toLocaleLowerCase()===source.name.toLocaleLowerCase());
      if(legacy.length)return{alreadyImported:true,playlistId:legacy[0].id,legacyNameMatch:true};
      const conflict=[...own,...flowPlaylistConfig.getFlowsOwnedByUser(req.user.id)].some(item=>item.name.toLocaleLowerCase()===source.name.toLocaleLowerCase());
      if(conflict)throw new ConnectorValidationError("APPLE_PLAYLIST_NAME_CONFLICT","A different playlist or flow already uses this name. Rename it before importing this source.");
      const id=playlistId(req.user.id,source);
      const operation=await queue.enqueuePayload({kind:"shared-playlist-create",label:`shared-playlist:${id}:apple-import`,playlistId:id,name:source.name,sourceName:"Apple Music",ownerUserId:req.user.id,tracks,
        importSource:{provider:"apple-playlist",externalId:`${source.kind}:${source.id}`,externalName:source.name,artworkUrl:source.artworkUrl,syncEnabled:false},description:"Imported from Apple Music"});
      return{playlistId:id,queued:true,operationId:operation.operationId};
    });res.json(result);
  }));
}
