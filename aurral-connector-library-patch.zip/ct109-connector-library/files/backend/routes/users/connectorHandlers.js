import { registerConnectorLibrary } from "./connectorLibraryHandlers.js";
import { logger } from "../../services/logger.js";
import { requireAuth, requireUserAccount } from "../../middleware/requirePermission.js";
import * as store from "../../services/connector/store.js";
import { ConnectorValidationError, connectorServices, validateConnectorSession } from "../../services/connector/adapters.js";
export function registerConnector(router, { validate = validateConnectorSession } = {}) {
  registerConnectorLibrary(router);
  const guard = [requireAuth, requireUserAccount];
  const wrap = (fn) => async (req, res) => {
    res.set("Cache-Control", "no-store");
    try { await fn(req, res); } catch (error) {
      const stage = res.locals.connectorStage || "request";
      const known = error instanceof ConnectorValidationError;
      const code = known ? error.code : `CONNECTOR_${stage.toUpperCase()}_FAILED`;
      const messages = {
        pairing: "This browser is not paired with your Aurral account. Pair it again before connecting a service.",
        request: "This connection request expired or was already used. Create a fresh request in Aurral.",
        validation: "The service session could not be validated. Create a fresh request and check the service login.",
        storage: "Aurral could not securely save the connection. Check the connector log.",
      };
      // Controlled codes only: never log request bodies, credentials or provider responses.
      logger.warn("connector", "Connection request failed", { stage, code, ...(known && error.providerStatus ? { providerStatus: error.providerStatus } : {}) });
      res.status(400).json({ error: known ? error.message : messages[stage] || messages.request, code, stage });
    }
  };
  const root = "/me/connector";
  router.get(root, ...guard, wrap((req, res) => res.json({ ...store.publicStatus(req.user.id), available: connectorServices })));
  router.post(`${root}/intent`, ...guard, wrap((req, res) => {
    const { kind, service } = req.body || {};
    if (kind !== "pair" && !(kind === "capture" && connectorServices.some(s => s.id === service))) return res.status(400).json({ error: "Unsupported connector operation" });
    res.json(store.createIntent(req.user.id, kind, kind === "capture" ? service : null));
  }));
  router.post(`${root}/pair`, ...guard, wrap((req, res) => {
    store.consumeIntent(req.user.id, req.body?.nonce, "pair"); store.pairDevice(req.user.id, req.body?.deviceId); res.json({ ok: true });
  }));
  router.post(`${root}/capture`, ...guard, wrap(async (req, res) => {
    const { nonce, service, deviceId, credential } = req.body || {};
    res.locals.connectorStage = "pairing";
    store.requireDevice(req.user.id, deviceId);
    res.locals.connectorStage = "request";
    store.consumeIntent(req.user.id, nonce, "capture", service);
    res.locals.connectorStage = "validation";
    const result = await validate(service, credential);
    // Recheck pairing after external validation so concurrent revocation wins.
    res.locals.connectorStage = "storage";
    store.saveSession(req.user.id, deviceId, service, result.credentials, result.expires);
    res.json({ ok: true });
  }));
  router.delete(`${root}/devices/:id`, ...guard, wrap((req, res) => { store.revoke(req.user.id, req.params.id); res.json({ ok: true }); }));
  router.delete(`${root}/services/:id`, ...guard, wrap((req, res) => { store.revoke(req.user.id, null, req.params.id); res.json({ ok: true }); }));
}
