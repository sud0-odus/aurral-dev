import { useState } from "react";
import { getData, postData } from "../../../utils/api/core.js";
const ROOT="/users/me/connector";
const errorText=error=>typeof error.response?.data?.error==="string"?error.response.data.error:"Could not complete the library action.";
export function ConnectedLibrarySection({service,onPreferencesChanged}) {
  const [open,setOpen]=useState(false),[playlists,setPlaylists]=useState([]),[groups,setGroups]=useState([]),[selected,setSelected]=useState(null);
  const [busy,setBusy]=useState(false),[message,setMessage]=useState(""),[query,setQuery]=useState("");
  const base=`${ROOT}/services/${encodeURIComponent(service.id)}`;
  const run=async(operation)=>{if(busy)return;setBusy(true);setMessage("");try{await operation();}catch(error){setMessage(errorText(error));}finally{setBusy(false);}};
  const loadLibrary=()=>run(async()=>{setOpen(true);setSelected(null);setGroups([]);setPlaylists((await getData(`${base}/library`,{timeout:90000})).playlists);});
  const loadGroups=()=>run(async()=>{setOpen(true);setSelected(null);setPlaylists([]);setGroups((await getData(`${base}/groups`,{timeout:90000})).groups);});
  const choose=item=>run(async()=>setSelected(await getData(`${base}/playlists/${item.kind}/${encodeURIComponent(item.id)}`,{timeout:90000})));
  const seed=()=>run(async()=>{await postData(`${base}/preferences`,{kind:selected.source.kind,id:selected.source.id},{timeout:120000});setMessage("Saved as your recommendation source. No downloads were queued. Discovery refresh will use these artists.");onPreferencesChanged();});
  const addPlaylist=()=>run(async()=>{const result=await postData(`${base}/import-playlist`,{kind:selected.source.kind,id:selected.source.id,downloadMissing:true},{timeout:120000});setMessage(result.alreadyImported?"This playlist is already in your Aurral library. Existing tracks and covers were preserved.":"Playlist import queued. Missing tracks will enter Aurral’s normal download pipeline.");});
  const visible=playlists.filter(item=>item.name.toLocaleLowerCase().includes(query.toLocaleLowerCase())).slice(0,200);
  return <div>
    <button type="button" className="btn btn-secondary btn-sm" disabled={busy} onClick={loadLibrary}>Browse {service.name} playlists</button>
    <button type="button" className="btn btn-secondary btn-sm" disabled={busy} onClick={loadGroups}>Browse {service.name} recommendations</button>
    {open&&<div>
      <button type="button" className="btn btn-secondary btn-sm" onClick={()=>setOpen(false)}>Close browser</button>
      <p>Choose a source to preview. Use for recommendations saves your personal taste without downloading its tracks. Adding an Aurral playlist is a separate action.</p>
      {groups.map(group=><button type="button" className="btn btn-secondary btn-sm" disabled={busy} key={group.id} onClick={()=>run(async()=>{setPlaylists((await getData(`${base}/groups/${encodeURIComponent(group.id)}`,{timeout:90000})).playlists);setSelected(null);})}>{group.name}</button>)}
      {!!playlists.length&&<label>Find a playlist <input className="arr-input" value={query} onChange={event=>setQuery(event.target.value)} /></label>}
      <ul>{visible.map(item=><li key={`${item.kind}:${item.id}`}>
        {item.artworkUrl&&<img src={item.artworkUrl} alt="" width="64" height="64" loading="lazy" referrerPolicy="no-referrer"/>}
        <button type="button" className="btn btn-secondary btn-sm" disabled={busy} onClick={()=>choose(item)}>{item.name}</button>
      </li>)}</ul>
      {playlists.length>200&&<p>Showing up to 200 matching playlists. Use Find to narrow the list.</p>}
      {selected&&<div>
        <h4>{selected.source.name}</h4>
        {selected.source.artworkUrl&&<img src={selected.source.artworkUrl} alt="Playlist artwork" width="160" height="160" referrerPolicy="no-referrer"/>}
        <p>{selected.tracks.length} tracks · {new Set(selected.tracks.map(track=>track.artistName)).size} artists</p>
        <button type="button" className="btn btn-primary btn-sm" disabled={busy} onClick={seed}>Use for my recommendations</button>
        <button type="button" className="btn btn-secondary btn-sm" disabled={busy} onClick={addPlaylist}>Add playlist and queue missing tracks</button>
        <details><summary>Preview tracks</summary><ol>{selected.tracks.slice(0,100).map((track,index)=><li key={`${track.sourceTrackId}:${index}`}>{track.artistName} — {track.trackName}</li>)}</ol>{selected.tracks.length>100&&<p>Showing the first 100 tracks. The complete playlist is used by either action.</p>}</details>
      </div>}
    </div>}
    {busy&&<p role="status">Reading the selected source…</p>}
    {message&&<p role="status">{message}</p>}
  </div>;
}
