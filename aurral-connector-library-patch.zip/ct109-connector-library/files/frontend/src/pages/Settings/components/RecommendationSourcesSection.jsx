import { useEffect, useState } from "react";
import { getData, deleteData } from "../../../utils/api/core.js";
export function RecommendationSourcesSection({revision}) {
  const [profile,setProfile]=useState(null),[error,setError]=useState("");
  useEffect(()=>{let active=true;getData("/users/me/connector/preferences").then(data=>{if(active)setProfile(data);}).catch(()=>{if(active)setError("Could not read recommendation sources.");});return()=>{active=false;};},[revision]);
  const remove=async key=>{try{setProfile(await deleteData(`/users/me/connector/preferences/${encodeURIComponent(key)}`));setError("");}catch{setError("Could not remove this recommendation source.");}};
  return <div><h4>Your recommendation sources</h4>
    <p>These saved preferences belong to your Aurral account. They survive discovery cache refreshes, feedback resets and streaming-service disconnection.</p>
    {profile&&<p>{profile.sources.length} sources · {profile.artistCount} artists</p>}
    <ul>{profile?.sources?.map(source=><li key={source.key}>
      {source.artworkUrl&&<img src={source.artworkUrl} alt="" width="64" height="64" loading="lazy" referrerPolicy="no-referrer"/>}
      {source.name} · {source.trackCount} tracks <button type="button" className="btn btn-secondary btn-sm" onClick={()=>remove(source.key)}>Remove recommendation source</button>
    </li>)}</ul>
    {!profile?.sources?.length&&<p>No imported sources yet. Connect a service, browse its playlists, and choose Use for my recommendations.</p>}
    {error&&<p role="alert">{error}</p>}
  </div>;
}
