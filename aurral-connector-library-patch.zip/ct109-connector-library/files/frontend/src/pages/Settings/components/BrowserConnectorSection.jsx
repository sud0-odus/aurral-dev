import { ConnectedLibrarySection } from "./ConnectedLibrarySection.jsx";
import { RecommendationSourcesSection } from "./RecommendationSourcesSection.jsx";
import { useCallback, useEffect, useRef, useState } from "react";
import { getData, postData, deleteData } from "../../../utils/api/core";
const ROOT = "/users/me/connector";
export function BrowserConnectorSection({ className = "", showError, showSuccess }) {
  const [status, setStatus] = useState(null);
  const [preferencesRevision, setPreferencesRevision] = useState(0);
  const [intent, setIntent] = useState(null);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const busy = useRef(false);
  const refresh = useCallback(async () => setStatus(await getData(ROOT)), []);
  useEffect(() => { refresh().catch(() => setError("Could not read connector status.")); }, [refresh]);
  useEffect(() => {
    if (!intent) return;
    const timer = setTimeout(() => { setIntent(null); setError("Connection request expired. Create a fresh request."); }, Math.max(0, intent.expires - Date.now()));
    return () => clearTimeout(timer);
  }, [intent]);
  useEffect(() => {
    const receive = async (event) => {
      if (event.source !== window || event.origin !== location.origin || event.data?.type !== "aurral-connector-submit" || !intent || event.data.nonce !== intent.nonce || busy.current) return;
      const message = event.data;
      if (message.kind !== intent.kind || (intent.kind === "capture" && message.service !== intent.service)) return;
      busy.current = true; setSubmitting(true);
      let ok = false;
      try {
        const body = { nonce: intent.nonce, deviceId: message.deviceId };
        if (intent.kind === "capture") { body.service = intent.service; body.credential = message.credential; }
        await postData(`${ROOT}/${intent.kind === "pair" ? "pair" : "capture"}`, body, { timeout: 55000 });
        ok = true; setIntent(null); setError(""); await refresh();
        showSuccess?.(intent.kind === "pair" ? "Aurral Connector paired. Choose a service separately." : "Service session validated and connected.");
      } catch (failure) {
        const data = failure.response?.data;
        const reason = typeof data?.error === "string" ? data.error : "Connection was not accepted. Create a fresh request.";
        const code = typeof data?.code === "string" && /^[A-Z_]+$/.test(data.code) ? ` (${data.code})` : "";
        setIntent(null); setError(reason + code);
        showError?.(reason + code);
      } finally {
        window.postMessage({ type: "aurral-connector-result", nonce: intent.nonce, ok }, location.origin);
        busy.current = false; setSubmitting(false);
      }
    };
    window.addEventListener("message", receive);
    return () => window.removeEventListener("message", receive);
  }, [intent, refresh, showError, showSuccess]);
  const begin = async (kind, service) => {
    try { setError(""); setIntent(await postData(`${ROOT}/intent`, { kind, service })); }
    catch { setError("Could not create a connector request."); }
  };
  const revoke = async (kind, id) => {
    try { await deleteData(`${ROOT}/${kind}/${encodeURIComponent(id)}`); setIntent(null); await refresh(); }
    catch { setError("Could not disconnect the connector or service."); }
  };
  return <section className={`settings-page__section ${className}`}>
    <h3 className="settings-page__section-title">Aurral Connector</h3>
    <p className="settings-page__section-note">Pair your browser once, then connect individual services. Each service requests its own access.</p>
    <details><summary>1. Install the browser extension</summary>
      <p>This preview supports Chrome and Edge. Download and extract the ZIP, open the browser’s Extensions page, enable Developer mode, and choose Load unpacked. Select the extracted folder containing manifest.json.</p>
      <a className="btn btn-secondary btn-sm" href="/aurral-connector.zip" download>Download Aurral Connector</a>
      <p>Keep the extracted folder. A browser-store installation link can replace these preview steps after publication.</p>
    </details>
    <h4>2. Pair this browser</h4>
    <button type="button" className="btn btn-secondary btn-sm" disabled={!status || Boolean(intent)} onClick={() => begin("pair")}>Pair Aurral Connector</button>
    <p>After creating a request, open the Aurral Connector toolbar icon while this tab is active, and choose Pair this browser. Pairing does not connect a streaming account.</p>
    {status?.devices?.map(device => <p key={device.id}>Paired browser · {device.id.slice(0, 8)} <button type="button" className="btn btn-secondary btn-sm" onClick={() => revoke("devices", device.id)}>Remove</button></p>)}
    <h4>3. Choose a service</h4>
    <p>Apple Music is the first adapter. More services can be added independently; they are not granted access by installing or pairing the connector.</p>
    {status?.available?.map(service => {
      const connected = status.services.some(item => item.id === service.id);
      return <div key={service.id}><p>{service.name}: {connected ? "Session connected" : "Not connected"}</p>
        <button type="button" className="btn btn-secondary btn-sm" disabled={!status.devices.length || Boolean(intent)} onClick={() => begin("capture", service.id)}>{connected ? "Reconnect" : "Connect"} {service.name}</button>
        {connected && <button type="button" className="btn btn-secondary btn-sm" onClick={() => revoke("services", service.id)}>Disconnect</button>}
        {connected && service.library && <ConnectedLibrarySection service={service} onPreferencesChanged={()=>setPreferencesRevision(value=>value+1)}/>}

      </div>;
    })}
    {intent && <div role="status"><p>{intent.kind === "pair" ? "Pairing request ready." : "Service request ready."} Open the Aurral Connector toolbar icon in this tab to continue. Keep this Aurral tab open.</p>
      <button type="button" className="btn btn-secondary btn-sm" disabled={submitting} onClick={() => setIntent(null)}>Cancel request</button>
      {submitting && <p>Validating the connection with the service…</p>}
      <script id="aurral-connector-request" type="application/json">{JSON.stringify(intent)}</script>
    </div>}
    <RecommendationSourcesSection revision={preferencesRevision}/>
    {error && <p role="alert">{error}</p>}
  </section>;
}
