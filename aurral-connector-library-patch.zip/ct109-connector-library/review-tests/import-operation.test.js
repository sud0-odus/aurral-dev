import test from "node:test";
import assert from "node:assert/strict";
import {setupIsolatedBackend,cleanupIsolatedState} from "../helpers/backendTestHarness.js";
const [state,{db},{flowPlaylistConfig},{processPlaylistOperation},{playlistManager}] = await setupIsolatedBackend("connector-repeat-import", "backend/config/db-sqlite.js", "backend/services/playlists/flowPlaylistConfig.js", "backend/services/playlists/playlistOperations.js", "backend/services/playlists/playlistManager.js");
test.after(()=>cleanupIsolatedState(state));
test("replayed Apple import preserves local additions and queues no jobs", async t=>{
 const importSource={provider:"apple-playlist",externalId:"library:p.fixture",syncEnabled:false};
 const existing=flowPlaylistConfig.createStaticPlaylist({id:"replayed-apple-fixture",name:"Existing",ownerUserId:1,importSource,tracks:[{artistName:"Local Artist",trackName:"Keep this"}]});
 let artwork=0; t.mock.method(playlistManager,"ensurePlaylistArtwork",async()=>{artwork++;});
 const result=await processPlaylistOperation({kind:"shared-playlist-create",playlistId:existing.id,name:"Remote name",ownerUserId:1,importSource,tracks:[{artistName:"Remote Artist",trackName:"Remote track"}]});
 assert.equal(result.alreadyImported,true);assert.equal(result.tracksQueued,0);assert.equal(artwork,0);
 assert.equal(db.prepare("SELECT count(*) n FROM playlist_download_jobs").get().n,0);
 assert.equal(flowPlaylistConfig.getStaticPlaylist(existing.id).tracks[0].artistName,"Local Artist");
 await assert.rejects(processPlaylistOperation({kind:"shared-playlist-create",playlistId:existing.id,ownerUserId:2,importSource,tracks:[]}),/identity conflict/);
});
