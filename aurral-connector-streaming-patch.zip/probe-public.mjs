// Public Apple resources only. Never read the application database or user session.
import fs from 'node:fs/promises';
const file = new URL('./files/backend/services/connector/adapters.js', import.meta.url);
try {
  const source = await fs.readFile(file);
  const adapter = await import(`data:text/javascript;base64,${source.toString('base64')}`);
  const result = await adapter.discoverAppleWebToken();
  if (!result?.token) throw new Error('Public token missing');
  console.log(JSON.stringify({ok:true,stage:'publicAppleLookup'}));
} catch(error) {
  const code = typeof error.code === 'string' && /^[A-Z_]+$/.test(error.code) ? error.code : 'PUBLIC_LOOKUP_FAILED';
  console.log(JSON.stringify({ok:false,code}));process.exitCode=1;
}
