import assert from 'node:assert/strict';
const token=`${Buffer.from(JSON.stringify({typ:'JWT',alg:'ES256'})).toString('base64url')}.${Buffer.from(JSON.stringify({iss:'AMPWebPlay',exp:Math.floor(Date.now()/1000)+3600})).toString('base64url')}.syntheticSignature`;
const urls=[];
globalThis.fetch=async(url,options)=>{
 urls.push(url);assert.ok(!options.headers['Music-User-Token']);
 if(url.endsWith('/browse'))return new Response(null,{status:301,headers:{location:'/us/new'}});
 if(url.endsWith('/new'))return new Response('x'.repeat(2500000)+'<script src="/assets/index~probe.js"></script>');
 assert.equal(url,'https://music.apple.com/assets/index~probe.js');return new Response(`const token="${token}";`);
};
process.once('beforeExit',()=>assert.deepEqual(urls,['https://music.apple.com/us/browse','https://music.apple.com/us/new','https://music.apple.com/assets/index~probe.js']));
