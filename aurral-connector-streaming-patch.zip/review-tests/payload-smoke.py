import argparse,importlib.util,sqlite3,tempfile,types
from pathlib import Path
from unittest.mock import patch
root=Path('/workspace/ct109-connector-streaming');spec=importlib.util.spec_from_file_location('installer',root/'apply-patch.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as directory:
 base=Path(directory);app=base/'app';target=app/'backend/services/connector/adapters.js';target.parent.mkdir(parents=True);target.write_bytes(Path('/tmp/connector-streaming-before.js').read_bytes())
 db=base/'aurral.db'
 with sqlite3.connect(db) as con:con.execute('CREATE TABLE settings(key TEXT,value TEXT)');con.execute("INSERT INTO settings VALUES ('browserConnectorV1','preserve existing pairing')")
 args=argparse.Namespace(app_dir=app,db=db,backup_dir=base/'backups',state=base/'state',health_url='http://unused')
 active=True;events=[]
 def probe():events.append('probe');assert active
 def ctl(*commands):
  global active
  events.append(commands[0])
  if commands[0]=='stop':active=False
  if commands[0]=='start':active=True
  return types.SimpleNamespace(returncode=(0 if active else 3) if commands[0]=='is-active' else 0)
 with patch.object(m,'systemctl',side_effect=ctl),patch.object(m,'healthy',return_value=True),patch.object(m,'run_public_probe',side_effect=probe):m.install(args);m.enable(args);m.rollback(args)
 assert events.index('probe')<events.index('stop')
 assert target.read_bytes()==Path('/tmp/connector-streaming-before.js').read_bytes()
 with sqlite3.connect(db) as con:assert con.execute('SELECT value FROM settings').fetchone()[0]=='preserve existing pairing'
 print('PASS: real payload install/enable/rollback preserves pairing and runs public preflight before stopping the app.')
