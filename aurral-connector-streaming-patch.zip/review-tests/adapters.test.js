import test from "node:test";import assert from "node:assert/strict";
import { validateConnectorSession, getAppleWebToken, discoverAppleWebToken } from "../../backend/services/connector/adapters.js";
import { apple } from "../../connector-extension/adapters/apple.js";
test("Apple accepts a verified library response and sends credentials only to the fixed Apple host", async()=>{
 const calls=[];const result=await validateConnectorSession("apple",{session:"private-session"},{webToken:async()=>"fixture-web-token",fetcher:async(url,options)=>{calls.push({url,options});return new Response(JSON.stringify({data:[]}));}});
 assert.equal(result.credentials.session,"private-session");assert.equal(calls[0].url,"https://amp-api.music.apple.com/v1/me/library/playlists?limit=1");assert.equal(calls[0].options.redirect,"manual");assert.equal(calls[0].options.headers["Music-User-Token"],"private-session");
});
test("unknown services, malformed credentials, redirects and failed Apple authorization cannot connect",async()=>{
 for(const [service,credential] of [["spotify",{session:"x"}],["apple",{session:"bad\nheader"}]])await assert.rejects(validateConnectorSession(service,credential));
 for(const response of [new Response("{}",{status:401}),new Response("{}"),new Response("not json")])await assert.rejects(validateConnectorSession("apple",{session:"x"},{webToken:async()=>"fixture",fetcher:async()=>response}));
});
test("web token retrieval fetches only Apple-owned fixed paths and verifies issuer/expiry",async()=>{
 const token=`${Buffer.from(JSON.stringify({typ:'JWT',alg:'ES256'})).toString('base64url')}.${Buffer.from(JSON.stringify({iss:"AMPWebPlay",exp:Math.floor(Date.now()/1000)+3600})).toString('base64url')}.fixturesignature`;
 const urls=[];const result=await getAppleWebToken(async url=>{urls.push(url);return new Response(url.endsWith("/browse")?'<script src="/assets/index~abc123.js"></script>':`const token="${token}"`);});
 assert.equal(result,token);assert.deepEqual(urls,["https://music.apple.com/us/browse","https://music.apple.com/assets/index~abc123.js"]);
});
test("extension Apple adapter reads just the named session cookie and expiry",async()=>{
 const calls=[];const value=await apple.capture({cookies:{get:async info=>{calls.push(info);return{value:"private",expirationDate:123};}}});
 assert.deepEqual(calls,[{url:"https://music.apple.com/",name:"media-user-token"}]);assert.deepEqual(value,{session:"private",expires:123000});
 assert.ok(apple.matches({removed:false,cookie:{name:"media-user-token",domain:".music.apple.com"}}));assert.ok(!apple.matches({removed:false,cookie:{name:"media-user-token",domain:"music.apple.com.evil.test"}}));
});

const fixtureJwt=()=>`${Buffer.from(JSON.stringify({typ:'JWT',alg:'ES256'})).toString('base64url')}.${Buffer.from(JSON.stringify({iss:"AMPWebPlay",exp:Math.floor(Date.now()/1000)+3600})).toString('base64url')}.fixturesignature`;
test("the real browse-to-new redirect succeeds with the existing bundle format",async()=>{
 const urls=[],signals=[];const token=fixtureJwt();
 const result=await discoverAppleWebToken(async(url,options)=>{
  urls.push(url);signals.push(options.signal);
  if(url.endsWith('/browse'))return new Response(null,{status:301,headers:{location:'https://music.apple.com/us/new'}});
  return new Response(url.endsWith('/new')?'<script src="/assets/index~ea66e33958.js"></script>':`token="${token}"`);
 });
 assert.equal(result.token,token);assert.deepEqual(urls,['https://music.apple.com/us/browse','https://music.apple.com/us/new','https://music.apple.com/assets/index~ea66e33958.js']);assert.equal(signals[0],signals[1]);
});
test("a private Apple session is never forwarded across origins or to an insecure URL",async()=>{
 for(const location of ['https://evil.invalid/steal','http://amp-api.music.apple.com/library','https://user@amp-api.music.apple.com/library']){
  const calls=[];
  await assert.rejects(validateConnectorSession('apple',{session:'PRIVATE'},{webToken:async()=> 'web',fetcher:async(url,options)=>{calls.push({url,options});return new Response(null,{status:302,headers:{location}});}}),error=>error.code==='APPLE_SESSION_REDIRECT');
  assert.equal(calls.length,1);assert.equal(calls[0].url,'https://amp-api.music.apple.com/v1/me/library/playlists?limit=1');
 }
});
test("redirect loops are bounded and Apple response bodies are excluded from errors",async()=>{
 let calls=0;
 await assert.rejects(discoverAppleWebToken(async()=>{calls++;return new Response(null,{status:301,headers:{location:'/us/new'}});}),error=>error.code==='APPLE_WEB_PAGE_REDIRECT_LIMIT');assert.equal(calls,5);
 await assert.rejects(validateConnectorSession('apple',{session:'PRIVATE'},{webToken:async()=> 'web',fetcher:async()=>new Response('PRIVATE_PROVIDER_DETAILS',{status:401})}),error=>error.code==='APPLE_SESSION_HTTP'&&error.providerStatus===401&&!error.message.includes('PRIVATE'));
});
test("bootstrap rejection is distinguishable from a rejected session",async()=>{
 await assert.rejects(discoverAppleWebToken(async()=>new Response('private provider body',{status:403})),error=>error.code==='APPLE_WEB_PAGE_HTTP'&&error.providerStatus===403&&!error.message.includes('private'));
});

function streamedFixture(prefixCount, markerParts, tailCount=512) {
 const filler=new TextEncoder().encode('x'.repeat(32768));const parts=markerParts.map(text=>new TextEncoder().encode(text));
 const stats={bytes:0,cancelled:false};let index=0;
 const response=new Response(new ReadableStream({pull(controller){let value;
  if(index<prefixCount)value=filler;else if(index<prefixCount+parts.length)value=parts[index-prefixCount];else if(index<prefixCount+parts.length+tailCount)value=filler;else{controller.close();return;}
  index++;stats.bytes+=value.length;controller.enqueue(value);
 },cancel(){stats.cancelled=true;}}));return{response,stats};
}
test('large public resources are scanned incrementally and cancelled as soon as the needed values are complete',async()=>{
 const token=fixtureJwt();const signatureStart=token.lastIndexOf('.')+1;
 const page=streamedFixture(100,['<script src="/assets/index~large','123.js"></script>']);
 const bundle=streamedFixture(420,['const t="',token.slice(0,signatureStart+10),token.slice(signatureStart+10),'";']);
 const result=await discoverAppleWebToken(async url=>url.endsWith('/browse')?page.response:bundle.response);
 assert.equal(result.token,token);assert.ok(page.stats.bytes>2000000);assert.ok(bundle.stats.bytes>12000000);
 assert.ok(page.stats.bytes<4000000);assert.ok(bundle.stats.bytes<15000000);assert.ok(page.stats.cancelled);assert.ok(bundle.stats.cancelled);
});
test('a token cut in the middle of its signature is not accepted early',async()=>{
 const token=fixtureJwt();const cut=token.lastIndexOf('.')+11;const bundle=streamedFixture(0,['"',token.slice(0,cut),token.slice(cut),'"'],0);
 const result=await discoverAppleWebToken(async url=>url.endsWith('/browse')?new Response('/assets/index~split.js'):bundle.response);
 assert.equal(result.token,token);
});
test('a missing bundle remains bounded even when the public page never contains a match',async()=>{
 const page=streamedFixture(1030,[],0);
 await assert.rejects(discoverAppleWebToken(async()=>page.response),error=>error.code==='APPLE_WEB_PAGE_SIZE');
 assert.ok(page.stats.bytes<34*1024*1024);assert.ok(page.stats.cancelled);
});
test('private library JSON keeps its original one-megabyte bound',async()=>{
 const response=new Response('x'.repeat(1000001));
 await assert.rejects(validateConnectorSession('apple',{session:'private'},{webToken:async()=> 'web',fetcher:async()=>response}),error=>error.code==='APPLE_SESSION_SIZE');
});
