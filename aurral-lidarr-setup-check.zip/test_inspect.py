import importlib.util
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).parent

def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

class InventoryTests(unittest.TestCase):
    def test_api_get_only_and_redacts_private_fields(self):
        m = load('inspect-container')
        payloads = {'system/status': {'version': '2.0', 'apiKey': 'SECRET_STATUS'},
            'rootfolder': [{'path': '/not-a-real-media-dir', 'freeSpace': 1234, 'secret': 'SECRET_ROOT'}],
            'downloadclient': [{'implementation': 'SABnzbd', 'enable': True,
                'fields': [{'name': 'apiKey', 'value': 'SECRET_CLIENT'},
                           {'name': 'category', 'value': 'music'}]}],
            'indexer': [{'implementation': 'Torznab', 'apiKey': 'SECRET_INDEXER', 'fields': ['SECRET_FIELDS']}],
            'qualityprofile': [{'id': 1, 'name': 'Lossless'}], 'metadataprofile': [], 'remotepathmapping': [],
            'config/mediamanagement': {'useHardlinks': True, 'apiKey': 'SECRET_CONFIG'}, 'config/naming': {}}
        calls = []
        class Response:
            def __init__(self, payload): self.payload = payload
            def __enter__(self): return self
            def __exit__(self, *args): pass
            def read(self, limit): return json.dumps(self.payload).encode()
        class Opener:
            def open(self, request, timeout):
                self_test.assertEqual(request.get_method(), 'GET')
                self_test.assertEqual(timeout, 5)
                endpoint = request.full_url.split('/api/v1/')[1]
                calls.append(endpoint)
                return Response(payloads[endpoint])
        self_test = self
        with patch.object(m.urllib.request, 'build_opener', return_value=Opener()):
            result = m.api_inventory({'url': 'http://lidarr:8686', 'apiKey': 'SECRET_REQUEST'})
        self.assertEqual(len(calls), 9)
        self.assertEqual(result['downloadclient'][0]['categories'], ['music'])
        self.assertTrue(result['media_management']['useHardlinks'])
        self.assertNotIn('SECRET', json.dumps(result))

    def test_unexpected_api_error_bodies_are_not_exported(self):
        m = load('inspect-container')
        class Response:
            def __enter__(self): return self
            def __exit__(self, *args): pass
            def read(self, limit): return b'{"apiKey":"SECRET_BODY", "error":"SECRET_MESSAGE"}'
        class Opener:
            def open(self, request, timeout): return Response()
        with patch.object(m.urllib.request, 'build_opener', return_value=Opener()):
            result = m.api_inventory({'url': 'http://lidarr', 'apiKey': 'SECRET_REQUEST'})
        self.assertNotIn('SECRET', json.dumps(result))
        self.assertIn('error', result['connection'])

    def test_aurral_environment_fallback_and_db_remains_unchanged(self):
        m = load('inspect-container')
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / 'test.db'
            with sqlite3.connect(db) as con:
                con.execute('CREATE TABLE settings(key TEXT, value TEXT)')
                con.execute('INSERT INTO settings VALUES (?, ?)', ('integrations', json.dumps({'lidarr': {'enabled': True}})))
            before = db.read_bytes()
            with patch.object(m, 'service_pid', return_value=None), \
                 patch.object(m, 'aurral_environment', return_value={'LIDARR_URL': 'http://lidarr', 'LIDARR_API_KEY': 'SECRET_ENV'}), \
                 patch.object(m, 'api_inventory', return_value={'configured': True}) as api:
                result = m.inspect('aurral', db)
                self.assertEqual(api.call_args.args[0]['apiKey'], 'SECRET_ENV')
            self.assertEqual(result['key_source'], 'environment_or_env_file')
            self.assertNotIn('SECRET', json.dumps(result))
            self.assertEqual(db.read_bytes(), before)

    def test_settings_take_precedence_over_environment(self):
        m = load('inspect-container')
        config = {'url': 'http://saved', 'apiKey': 'SECRET_SAVED', 'enabled': True}
        with patch.object(m, 'service_pid', return_value=None), \
             patch.object(m, 'saved_aurral_config', return_value=config), \
             patch.object(m, 'aurral_environment', return_value={'LIDARR_URL': 'http://env', 'LIDARR_API_KEY': 'SECRET_ENV'}), \
             patch.object(m, 'api_inventory', return_value={'configured': True}) as api:
            result = m.inspect('aurral', Path('/unused'))
            self.assertEqual(api.call_args.args[0]['apiKey'], 'SECRET_SAVED')
            self.assertEqual(api.call_args.args[0]['url'], 'http://saved')
        self.assertEqual(result['key_source'], 'settings')

    def test_host_layout_omits_unrelated_configuration(self):
        m = load('inspect-setup')
        result = m.layout('hostname: lidarr\nmp0: /mnt/music,mp=/music\nnet0: name=eth0\ndescription: SECRET\nssh-public-keys: SECRET\n')
        self.assertEqual(set(result), {'hostname', 'mp0', 'net0'})
        self.assertNotIn('SECRET', json.dumps(result))

    def test_local_lidarr_data_directory_and_xml_key_are_read_without_export(self):
        m = load('inspect-container')
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config = root / 'config.xml'
            config.write_text('<Config><ApiKey>SECRET_XML</ApiKey><Port>8686</Port><UrlBase>/lidarr</UrlBase></Config>')
            command = root / 'cmdline'
            command.write_bytes(('Lidarr\0-data=' + str(root) + '\0').encode())
            before = config.read_bytes()
            def paths(*args):
                return command if args == ('/proc', '123', 'cmdline') else Path(*args)
            with patch.object(m, 'Path', side_effect=paths):
                result, location = m.local_lidarr_config('123')
            self.assertEqual(result['url'], 'http://127.0.0.1:8686/lidarr')
            self.assertEqual(result['apiKey'], 'SECRET_XML')
            self.assertEqual(location, str(config))
            self.assertEqual(config.read_bytes(), before)

    def test_missing_database_is_not_created(self):
        m = load('inspect-container')
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / 'missing.db'
            with self.assertRaises(sqlite3.OperationalError):
                m.saved_aurral_config(db)
            self.assertFalse(db.exists())

    def test_redirects_not_followed(self):
        m = load('inspect-container')
        self.assertIsNone(m.NoRedirect().redirect_request(None, None, None, None))

if __name__ == '__main__': unittest.main()
