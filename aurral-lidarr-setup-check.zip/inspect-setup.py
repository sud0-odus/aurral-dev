#!/usr/bin/env python3
"""Run on the Proxmox host: read CT103 Lidarr and CT109 Aurral configuration."""
import json
import os
from pathlib import Path
import subprocess
import sys


def layout(text):
    allowed = {'hostname', 'cores', 'memory', 'swap', 'rootfs', 'unprivileged'}
    result = {}
    for line in text.splitlines():
        key, sep, value = line.partition(':')
        if sep and (key in allowed or (key.startswith(('mp', 'net')) and key.lstrip('abcdefghijklmnopqrstuvwxyz').isdigit())):
            result[key] = value.strip()
    return result


def run(args):
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=65)
        return result.stdout if result.returncode == 0 else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def main():
    if os.geteuid() != 0:
        raise RuntimeError('Run as root on the Proxmox host.')
    source = Path(__file__).with_name('inspect-container.py').read_text()
    report = {'read_only': True, 'containers': {}}
    for ctid, role in [('103', 'lidarr'), ('109', 'aurral')]:
        print('Reading CT%s %s configuration (GET requests only)...' % (ctid, role), file=sys.stderr, flush=True)
        config = run(['pct', 'config', ctid])
        output = run(['pct', 'exec', ctid, '--', 'python3', '-c', source, '--role', role])
        item = {'proxmox': layout(config) if config is not None else {'error': 'Could not read CT configuration'}}
        try:
            item['application'] = json.loads(output) if output else {'error': 'Could not run Python inspection in CT'}
        except ValueError:
            item['application'] = {'error': 'Container inspection did not return JSON'}
        report['containers'][ctid] = item
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError):
        print('Could not run inspection. No changes made.', file=sys.stderr)
        sys.exit(1)
