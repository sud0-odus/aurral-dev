Lidarr / Aurral existing setup check

Run inspect-setup.py with Python 3 as root on the Proxmox host.
It reads CT103 (Lidarr) and CT109 (Aurral) using pct config / pct exec.
It neither installs files in the containers nor changes configuration,
restarts services, launches downloads, searches, tests indexers or scans media.

The inspection reads:
- Allowlisted Proxmox CPU/memory/network/mount configuration.
- Lidarr service identity and its local config.xml (key retained in memory only).
- Aurral's saved Lidarr settings, relevant live-process environment values and
  simple LIDARR_* entries in /opt/aurral/backend/.env. Settings take precedence.
- GET-only Lidarr API endpoints for version, root folders, enabled download
  clients/indexers, quality/metadata profiles, remote path mappings and
  media management/naming preferences. Each request has a five-second timeout
  and a 2 MiB response cap. Redirects and environment HTTP proxies are disabled.

Output includes internal hostnames, music paths, profile names, UID/GID and
permissions. API keys, full provider fields, credentials and config files are
not exported. Unexpected API response bodies are not exported.
No production reports or credentials are included in this kit.

The .env parser supports ordinary KEY=value and quoted single-line values.
It does not execute shell files or inspect every possible custom service path.
A service wrapper may have a different environment than its child process.
TLS certificate errors are reported as request failures; verification is not
bypassed. Root folder existence/ownership does not establish matching files
across containers or complete app-user permissions. No filesystem tree walk
or artist/track catalog export is performed.

Eight synthetic configuration, privacy and read-only checks are included:
python3 test_inspect.py
