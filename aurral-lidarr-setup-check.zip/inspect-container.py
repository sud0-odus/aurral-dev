#!/usr/bin/env python3
"""Read-only, credential-redacted Lidarr/Aurral inventory. Invoked by inspect-setup.py."""
import argparse
import json
from pathlib import Path
import sqlite3
import subprocess
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET


def service_pid(name):
    try:
        result = subprocess.run(['systemctl', 'show', name, '-p', 'MainPID', '--value'],
                                capture_output=True, text=True, timeout=5)
        pid = result.stdout.strip()
        return pid if pid.isdigit() and int(pid) > 0 else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def read_environment(pid):
    if not pid:
        return {}
    allowed = {'LIDARR_URL', 'LIDARR_API_KEY', 'LIDARR_INSECURE'}
    result = {}
    try:
        for item in Path('/proc', pid, 'environ').read_bytes().split(b'\0'):
            name, sep, value = item.partition(b'=')
            key = name.decode(errors='replace')
            if sep and key in allowed:
                result[key] = value.decode(errors='replace')
    except OSError:
        pass
    return result


def aurral_environment(pid):
    # Node --env-file values may not appear in /proc's initial environment.
    values = {}
    path = Path('/opt/aurral/backend/.env')
    try:
        if path.stat().st_size <= 262144:
            for line in path.read_text().splitlines():
                line = line.strip().removeprefix('export ')
                key, sep, value = line.partition('=')
                key = key.strip()
                if sep and key in {'LIDARR_URL', 'LIDARR_API_KEY', 'LIDARR_INSECURE'}:
                    value = value.strip()
                    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
                        value = value[1:-1]
                    values[key] = value
    except OSError:
        pass
    return values | read_environment(pid)


def local_lidarr_config(pid):
    candidates = []
    if pid:
        try:
            args = Path('/proc', pid, 'cmdline').read_bytes().decode(errors='replace').split('\0')
            for i, arg in enumerate(args):
                if arg.lower().startswith(('-data=', '--data=')):
                    candidates.append(Path(arg.split('=', 1)[1]) / 'config.xml')
                elif arg.lower() in {'-data', '--data'} and i + 1 < len(args):
                    candidates.append(Path(args[i + 1]) / 'config.xml')
        except OSError:
            pass
    candidates.extend(Path(p) for p in ['/var/lib/lidarr/config.xml', '/var/lib/lidarr/.config/Lidarr/config.xml',
                                         '/root/.config/Lidarr/config.xml', '/config/config.xml'])
    for candidate in candidates:
        try:
            if candidate.stat().st_size > 65536:
                continue
            root = ET.fromstring(candidate.read_bytes())
            key = root.findtext('ApiKey') or ''
            if key:
                tls = (root.findtext('EnableSsl') or '').lower() == 'true'
                port = root.findtext('SslPort' if tls else 'Port') or ('6868' if tls else '8686')
                if not port.isdigit():
                    continue
                urlbase = '/' + (root.findtext('UrlBase') or '').strip('/')
                return {'url': f"{'https' if tls else 'http'}://127.0.0.1:{port}{urlbase.rstrip('/')}",
                        'apiKey': key}, str(candidate)
        except (OSError, ET.ParseError):
            continue
    return {}, None


def saved_aurral_config(db):
    con = sqlite3.connect(db.resolve().as_uri() + '?mode=ro', uri=True, timeout=2)
    try:
        con.execute('PRAGMA query_only=ON')
        row = con.execute('SELECT value FROM settings WHERE key=?', ('integrations',)).fetchone()
        value = json.loads(row[0]) if row else {}
        return value.get('lidarr') or {}
    finally:
        con.close()


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def api_inventory(config):
    if not config.get('url') or not config.get('apiKey'):
        return {'configured': False}
    base = str(config['url']).strip().rstrip('/')
    parsed = urllib.parse.urlsplit(base)
    if parsed.scheme not in {'http', 'https'} or not parsed.hostname:
        return {'configured': False, 'error': 'invalid server URL'}
    output = {'configured': True, 'server_host': parsed.hostname, 'server_port': parsed.port}
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect)

    def get(endpoint):
        request = urllib.request.Request(base + '/api/v1/' + endpoint,
                                        headers={'X-Api-Key': str(config['apiKey']), 'Accept': 'application/json'})
        try:
            with opener.open(request, timeout=5) as response:
                data = response.read(2097153)
                if len(data) > 2097152:
                    return {'error': 'response exceeds 2 MiB limit'}
                return json.loads(data)
        except urllib.error.HTTPError as error:
            return {'http_status': error.code}
        except (OSError, ValueError):
            return {'error': 'request or JSON response failed'}

    status = get('system/status')
    if not isinstance(status, dict) or 'version' not in status:
        output['connection'] = {'error': 'Could not read Lidarr status'}
        if isinstance(status, dict) and isinstance(status.get('http_status'), int):
            output['connection']['http_status'] = status['http_status']
        return output
    output['version'] = status.get('version')
    for endpoint, fields in [
        ('rootfolder', ['path', 'accessible', 'freeSpace']),
        ('downloadclient', ['implementation', 'enable', 'priority']),
        ('indexer', ['implementation', 'enableRss', 'enableAutomaticSearch', 'enableInteractiveSearch']),
        ('qualityprofile', ['id', 'name', 'upgradeAllowed']),
        ('metadataprofile', ['id', 'name']),
        ('remotepathmapping', ['host', 'remotePath', 'localPath']),
    ]:
        result = get(endpoint)
        if isinstance(result, list):
            safe = []
            for item in result:
                if not isinstance(item, dict):
                    continue
                entry = {field: item.get(field) for field in fields}
                if endpoint == 'rootfolder':
                    entry['exists_in_this_ct'] = bool(item.get('path')) and Path(item['path']).is_dir()
                    if entry['exists_in_this_ct']:
                        info = Path(item['path']).stat()
                        entry['directory_owner_uid'] = info.st_uid
                        entry['directory_owner_gid'] = info.st_gid
                        entry['directory_mode'] = oct(info.st_mode & 0o7777)
                if endpoint == 'downloadclient':
                    entry['categories'] = [field.get('value') for field in item.get('fields', [])
                        if isinstance(field, dict) and field.get('name') in {'category', 'musicCategory'}
                        and isinstance(field.get('value'), str)]
                safe.append(entry)
            output[endpoint] = safe
        else:
            output[endpoint] = {'error': 'Could not read this endpoint'}
            if isinstance(result, dict) and isinstance(result.get('http_status'), int):
                output[endpoint]['http_status'] = result['http_status']
    management = get('config/mediamanagement')
    if isinstance(management, dict):
        output['media_management'] = {key: management.get(key) for key in
            ['renameTracks', 'replaceIllegalCharacters', 'createEmptyArtistFolders', 'deleteEmptyFolders',
             'useHardlinks', 'setPermissions', 'chmodFolder', 'chownGroup']}
    naming = get('config/naming')
    if isinstance(naming, dict):
        output['naming'] = {key: naming.get(key) for key in
            ['renameTracks', 'standardTrackFormat', 'multiDiscTrackFormat', 'artistFolderFormat', 'albumFolderFormat']}
    return output


def inspect(role, database):
    service = 'lidarr.service' if role == 'lidarr' else 'aurral.service'
    pid = service_pid(service)
    output = {'read_only': True, 'role': role, 'service_running': bool(pid)}
    if pid:
        try:
            status = Path('/proc', pid, 'status').read_text().splitlines()
            output['service_identity'] = {line.split(':', 1)[0].lower(): int(line.split()[2])
                for line in status if line.startswith(('Uid:', 'Gid:'))}
        except (OSError, ValueError, IndexError):
            pass
    if role == 'lidarr':
        config, path = local_lidarr_config(pid)
        output['config_file'] = path
    else:
        config = saved_aurral_config(database)
        env = aurral_environment(pid)
        output['enabled'] = config.get('enabled') is True
        output['url_source'] = 'settings' if config.get('url') else 'environment_or_env_file' if env.get('LIDARR_URL') else 'default'
        output['key_source'] = 'settings' if config.get('apiKey') else 'environment_or_env_file' if env.get('LIDARR_API_KEY') else 'missing'
        config = {**config, 'url': config.get('url') or env.get('LIDARR_URL') or 'http://localhost:8686',
                  'apiKey': config.get('apiKey') or env.get('LIDARR_API_KEY')}
        output['saved_root_folders'] = [path for path in (config.get('rootFolderPaths') or []) if isinstance(path, str)][:200]
        output['saved_root_folder'] = config.get('rootFolderPath')
    output['api'] = api_inventory(config)
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--role', choices=['lidarr', 'aurral'], required=True)
    parser.add_argument('--db', type=Path, default=Path('/opt/aurral_data/aurral.db'))
    args = parser.parse_args()
    try:
        print(json.dumps(inspect(args.role, args.db), indent=2))
    except (OSError, ValueError, TypeError, sqlite3.Error):
        print(json.dumps({'read_only': True, 'role': args.role, 'error': 'Inspection failed; no changes made.'}))
