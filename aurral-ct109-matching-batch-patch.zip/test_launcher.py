import importlib.util
import hashlib
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('launcher', Path(__file__).with_name('start-profile.py'))
launcher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(launcher)


class LauncherTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        collector = b'# test collector\n'
        (self.root/'aurral-baseline.py').write_bytes(collector)
        (self.root/'manifest.json').write_text(json.dumps({'collector_sha256': hashlib.sha256(collector).hexdigest()}))
        self.output = str(self.root/'profile')

    def test_detached_job_limits_only_collector_and_samples_for_eight_hours(self):
        with patch.object(launcher, '__file__', str(self.root/'start-profile.py')), \
             patch.object(launcher.os, 'geteuid', return_value=0), \
             patch('sys.argv', ['launcher', '--output', self.output]), \
             patch.object(launcher.subprocess, 'run', return_value=types.SimpleNamespace(returncode=0)) as run:
            launcher.main()
        command = run.call_args_list[-1].args[0]
        self.assertEqual(command[0], 'systemd-run')
        self.assertIn('--property=MemoryMax=384M', command)
        self.assertIn('--property=CPUQuota=20%', command)
        self.assertIn('--property=MemorySwapMax=0', command)
        self.assertEqual(command[command.index('--observe-seconds')+1], '28800')
        self.assertEqual(command[command.index('--interval')+1], '30')
        self.assertNotIn('aurral.service', command)

    def test_existing_output_is_rejected_without_starting_a_job(self):
        Path(self.output+'.json.gz').write_bytes(b'existing')
        with patch.object(launcher, '__file__', str(self.root/'start-profile.py')), \
             patch.object(launcher.os, 'geteuid', return_value=0), \
             patch('sys.argv', ['launcher', '--output', self.output]), \
             patch.object(launcher.subprocess, 'run') as run:
            with self.assertRaisesRegex(RuntimeError, 'output exists'):
                launcher.main()
        run.assert_not_called()


if __name__ == '__main__':
    unittest.main()
