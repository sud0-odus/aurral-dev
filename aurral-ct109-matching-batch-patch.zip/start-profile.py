#!/usr/bin/env python3
"""Start an eight-hour, read-only CT109 profile under systemd, independent of SSH."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--hours', type=float, default=8)
    parser.add_argument('--output', default='/tmp/aurral-matching-batch-109')
    args = parser.parse_args()
    if os.geteuid() != 0:
        parser.error('Run inside CT109 as root.')
    if not 0 < args.hours <= 24:
        parser.error('Use 0 < hours <= 24.')
    kit = Path(__file__).resolve().parent
    manifest = json.loads((kit/'manifest.json').read_text())
    collector = kit/'aurral-baseline.py'
    if hashlib.sha256(collector.read_bytes()).hexdigest() != manifest['collector_sha256']:
        raise RuntimeError('Collector checksum mismatch.')
    prefix = str(Path(args.output).resolve())
    for suffix in ['.json.gz', '.md', '.jobs.csv', '.checkpoint.json.gz']:
        if Path(prefix+suffix).exists():
            raise RuntimeError('Profile output exists; choose a different --output prefix.')
    if subprocess.run(['systemctl', 'is-active', '--quiet', 'aurral.service']).returncode:
        raise RuntimeError('Aurral is not active. Enable the patch before profiling.')
    subprocess.run([
        'systemd-run', '--unit=aurral-matching-batch-profile', '--collect',
        '--description=Aurral read-only matching and batching profile',
        '--property=Nice=10', '--property=CPUQuota=20%',
        '--property=MemoryMax=384M', '--property=MemorySwapMax=0', '--property=UMask=0077',
        sys.executable, '-u', str(collector), '--hours', '24',
        '--observe-seconds', str(args.hours*3600), '--interval', '30', '--output', prefix,
    ], check=True)
    print('Profiling for %g hours. You can close PuTTY; Aurral keeps running.' % args.hours)
    print('Collector-only limits: 384 MiB RAM, no swap, 20% of one CPU. Aurral limits are unchanged.')
    print('Progress: journalctl -u aurral-matching-batch-profile -n 10 --no-pager')
    print('Result: ' + prefix + '.json.gz')
    print('A checkpoint is saved every five minutes. To end early and save a report:')
    print('systemctl stop aurral-matching-batch-profile')


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, subprocess.CalledProcessError) as error:
        print('STOPPED: ' + str(error), file=sys.stderr)
        sys.exit(1)
