# CT109 source admission follow-up (v2.11.0 patch 8)

Requires the installed source-lanes patch 6. Apple preview 7 is compatible.
All ten backend input files are checked by SHA-256 before service changes.

The overnight collector recorded 207 source-attributed completions (189 YouTube,
18 Soulseek), then no completions after 22:49. All eight active slots ended up
on Soulseek; repeated searches occupied the general pipeline and denied YouTube
new work. The retained worker ledger capped at 50,000 records, so its execution
counts are lower bounds. The full resource observation covers eight hours.

This follow-up gives general acquisition six admitted jobs and YouTube two
buffered jobs per configured YouTube worker. Waiting source handoffs are persisted
separately and promoted transactionally when capacity is released. They have no
running worker or independent polling loop. Due times, attempts and review files
survive handoff, restart and cancellation. Existing excess work drains normally.
Configuration remains general concurrency 2, YouTube concurrency 1 by default;
this does not increase worker counts. Finalization remains serialized.

Soulseek search attempts now have a persisted 15-minute deadline across query
cycles. Logged-out time retains its separate existing 45-minute bound. Ongoing
file transfers keep their existing progress/stall policy. Matching rules and
transcoding are unchanged.

Inside CT109:
```
python3 apply-patch.py --check
python3 apply-patch.py --install
python3 apply-patch.py --enable
python3 start-profile.py --hours 1
```
Install stops Aurral, backs up source and the stopped database locally, and
leaves it stopped. Enable starts it and checks health/matcher availability.
No queue rows are edited by installation. A rollback restores previous source
and returns waiting handoffs to the v6 source queues; current database work is
preserved rather than replaced with the old database backup:
```
python3 apply-patch.py --rollback
systemctl start aurral.service
```
If a file differs, stop and share the output; do not bypass the checksum guard.

The collector (revision 1.6) includes waiting source handoffs. It runs separately
under systemd with 384 MiB RAM, no swap and 20% of one CPU. It checkpoints every
five minutes and does not depend on PuTTY staying open. Existing output prefixes
are never overwritten. Default report: /tmp/aurral-source-admission-109.json.gz.
The first check is sustained completions and continuing YouTube work after the
initial queue burst, with bounded CPU/memory and no OOM. One-hour results alone
do not prove all-night stability. Broad historical data need not be recollected.
