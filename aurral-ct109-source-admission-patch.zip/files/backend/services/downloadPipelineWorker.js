import { dbOps } from "../db/helpers/index.js";
import { pipelineQueueName, ytdlpConcurrency, createLaneGate } from "./downloadLanePolicy.js";
import createHonkerWorker from "./honkerWorkerFactory.js";
import { getPipelineQueue, getHonkerQueueByName, enqueuePipelineJob, promoteWaitingPipelineJobs } from "./honkerDb.js";
import {
  continuePipeline,
  buildNextSourcePayload,
  processPipelinePayload,
  enqueuePendingJobsWithoutBatch,
  failPipelineJob,
} from "./downloadPipeline.js";
import { isPipelinePayloadActive } from "./downloadJobs/downloadCancellation.js";
import { isAnyDownloadSourceConfigured } from "./downloadSourceService.js";
import { logger, safeLogDiagnostic } from "./logger.js";
import { recordAlbumGrabQueued, recordAlbumGrabPhase } from "./albumGrabActivity.js";
import { downloadTracker } from "./downloadJobs/downloadTracker.js";
import { withDownloadPayloadMutation } from "./downloadJobs/mutationGuards.js";

async function processLockedPipelineJob(payload, dependencies = {}) {
  const processPayload = dependencies.processPipelinePayload || processPipelinePayload;
  const continuePayload = dependencies.continuePipeline || continuePipeline;
  const failPayload = dependencies.failPipelineJob || failPipelineJob;
  try {
    if (payload?.albumGrab === true && isPipelinePayloadActive(payload)) {
      recordAlbumGrabQueued(payload, downloadTracker.getAll());
      recordAlbumGrabPhase(payload);
    }
    const nextPayload = await processPayload(payload);
    if (nextPayload?.albumGrab === true) recordAlbumGrabPhase(nextPayload);
    await continuePayload(nextPayload);
  } catch (error) {
    if (payload?.manualSelection !== true) throw error;
    const message = safeLogDiagnostic(error) || "Manual download failed";
    logger.error("manual-search", "Selected manual download failed", {
      jobId: payload?.jobId || null,
      source: payload?.source || null,
      reason: message,
    });
    await failPayload(payload, message);
  }
}

export async function processPipelineJob(payload, dependencies = {}) {
  try {
    return await withDownloadPayloadMutation(payload, (current) => processLockedPipelineJob(current, dependencies));
  } finally {
    // Wake dispatch after releasing the playlist lease. A waiting transfer
    // or search may be the only work that survived an idle owner/restart.
    // Failure to wake must not retry a step whose continuation was persisted.
    try {
      const startPending = dependencies.startWorkerIfPending ||
        (await import("./downloadJobs/downloadWorker.js")).startWorkerIfPending;
      await startPending({ respectPause: true });
    } catch (error) {
      logger.warn("downloads", "Could not wake pending download jobs", {
        reason: safeLogDiagnostic(error),
      });
    }
  }
}

const runYoutube = createLaneGate(() => ytdlpConcurrency(dbOps.getSettings()?.playlistWorker?.ytdlpConcurrency));

function makeWorker(name, getQueue, { youtube = false } = {}) {
  return createHonkerWorker({
    name, getQueue, idlePollS: 2, retryDelayS: 30,
    shouldRestart: () => isAnyDownloadSourceConfigured(),
    // Old queue rows are routed when claimed. Restart/rollback never discards them.
    async processJob(payload) {
      if (!payload.source && payload.phase === "search") payload = buildNextSourcePayload(payload) || payload;
      const destination = pipelineQueueName(payload);
      const current = youtube ? "ytdlp-pipeline" : name;
      if (destination !== current) {
        enqueuePipelineJob(payload);
        return;
      }
      if (youtube) return runYoutube(() => processPipelineJob(payload));
      return processPipelineJob(payload);
    },
    onJobSuccess() { promoteWaitingPipelineJobs(); },
    onFinalFailure(job, error) {
      const message = error?.message || String(error);
      console.error("[downloadPipelineWorker] pipeline job failed:", { jobId: job.payload?.jobId, phase: job.payload?.phase, message });
      return withDownloadPayloadMutation(job.payload, async (payload) => continuePipeline(await failPipelineJob(payload, message)));
    },
  });
}
const generalWorker = makeWorker("slskd-pipeline", getPipelineQueue);
const youtubeWorker = makeWorker("ytdlp-pipeline", () => getHonkerQueueByName("ytdlp-pipeline"), { youtube: true });
const youtubeSecondWorker = makeWorker("ytdlp-pipeline-second", () => getHonkerQueueByName("ytdlp-pipeline"), { youtube: true });
const finalizerWorker = makeWorker("download-finalize", () => getHonkerQueueByName("download-finalize"));
const workers = [generalWorker, youtubeWorker, youtubeSecondWorker, finalizerWorker];

export function startDownloadPipelineWorker() {
  if (!isAnyDownloadSourceConfigured()) return;
  const wasRunning = isDownloadPipelineWorkerRunning();
  promoteWaitingPipelineJobs();
  for (const worker of workers) {
    if (worker === youtubeSecondWorker && ytdlpConcurrency(dbOps.getSettings()?.playlistWorker?.ytdlpConcurrency) !== 2) continue;
    void worker.start();
  }
  if (!wasRunning) enqueuePendingJobsWithoutBatch();
}
export function stopDownloadPipelineWorker() {
  return Promise.all(workers.map((worker) => worker.stop()));
}
export function isDownloadPipelineWorkerRunning() {
  return workers.some((worker) => worker.isRunning());
}
