import test from "node:test";import assert from "node:assert/strict";import express from "express";
import {setupIsolatedBackend,cleanupIsolatedState,resetDatabase} from "../helpers/backendTestHarness.js";
const [state,{db},routes,store] = await setupIsolatedBackend("connector-routes","backend/config/db-sqlite.js","backend/routes/users/connectorHandlers.js","backend/services/connector/store.js");
let validating;
const app=express();app.use(express.json());app.use((req,_res,next)=>{if(req.headers['x-fixture-user'])req.user={id:Number(req.headers['x-fixture-user'])};next();});
const router=express.Router();routes.registerConnector(router,{validate:async(_service,credential)=>{if(validating)await validating;return{credentials:credential,expires:null};}});app.use('/api/users',router);
const server=await new Promise(resolve=>{const s=app.listen(0,'127.0.0.1',()=>resolve(s));});
const base=`http://127.0.0.1:${server.address().port}/api/users/me/connector`;
async function request(path='',body, user=1, method=body?'POST':'GET') {const response=await fetch(base+path,{method,headers:{'Content-Type':'application/json',...(user?{'x-fixture-user':String(user)}:{})},...(body?{body:JSON.stringify(body)}:{})});return{status:response.status,body:await response.json()};}
test.after(async()=>{await new Promise(resolve=>server.close(resolve));cleanupIsolatedState(state);});
test.beforeEach(()=>{resetDatabase(db);validating=null;});
const device='test-browser-device-1234';
async function pair(){const intent=await request('/intent',{kind:'pair'});assert.equal((await request('/pair',{nonce:intent.body.nonce,deviceId:device})).status,200);}
test('all connector operations require a real account',async()=>{assert.equal((await request('',null,null)).status,401);assert.equal((await request('',null,-1)).status,403);});
test('pairing remains separate from capture, and supplied user IDs are ignored',async()=>{await pair();assert.deepEqual((await request()).body.services,[]);const intent=await request('/intent',{kind:'capture',service:'apple',userId:2});const result=await request('/capture',{nonce:intent.body.nonce,service:'apple',deviceId:device,credential:{session:'private'},userId:2});assert.equal(result.status,200);assert.equal(store.readSession(2,'apple'),null);assert.ok(!JSON.stringify((await request()).body).includes('private'));});
test('another account cannot complete a request, and replay cannot overwrite a connection',async()=>{await pair();const intent=await request('/intent',{kind:'capture',service:'apple'});const body={nonce:intent.body.nonce,service:'apple',deviceId:device,credential:{session:'private'}};assert.equal((await request('/capture',body,2)).status,400);assert.equal((await request('/capture',body)).status,200);assert.equal((await request('/capture',body)).status,400);});
test('revocation during remote validation prevents a session being saved',async()=>{await pair();const intent=await request('/intent',{kind:'capture',service:'apple'});let release;validating=new Promise(resolve=>{release=resolve;});const pending=request('/capture',{nonce:intent.body.nonce,service:'apple',deviceId:device,credential:{session:'private'}});await new Promise(resolve=>setTimeout(resolve,20));store.revoke(1,device);release();assert.equal((await pending).status,400);assert.equal(store.readSession(1,'apple'),null);});
