import argparse,importlib.util,sqlite3,tempfile,types,shutil,json
from pathlib import Path
from unittest.mock import patch
root=Path('/workspace/ct109-connector-preview')
s=importlib.util.spec_from_file_location('installer',root/'apply-patch.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
with tempfile.TemporaryDirectory() as directory:
 base=Path(directory);app=base/'app';app.mkdir()
 originals={'backend/routes/users.js':'/tmp/connector-users-before.js','frontend/src/pages/Settings/components/SettingsAccountTab.jsx':'/tmp/connector-account-before.jsx'}
 for rel,src in originals.items():
  target=app/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(Path(src).read_bytes())
 shutil.copytree('/workspace/ct109-remove-apple-viewer/app/frontend-dist',app/'frontend/dist');before_front=m.tree_digest(app/'frontend/dist')
 db=base/'aurral.db'
 with sqlite3.connect(db) as con:con.execute('CREATE TABLE work(value TEXT)');con.execute("INSERT INTO work VALUES ('existing playlists and queue')")
 args=argparse.Namespace(app_dir=app,db=db,backup_dir=base/'backups',state=base/'state',health_url='http://unused')
 active=True
 def ctl(*commands):
  global active
  if commands[0]=='stop':active=False
  if commands[0]=='start':active=True
  return types.SimpleNamespace(returncode=(0 if active else 3) if commands[0]=='is-active' else 0)
 with patch.object(m,'systemctl',side_effect=ctl),patch.object(m,'healthy',return_value=True):m.install(args);m.enable(args);m.rollback(args)
 for rel in originals:assert (app/rel).read_bytes()==Path(originals[rel]).read_bytes()
 assert not (app/'backend/services/connector/store.js').exists()
 assert m.tree_digest(app/'frontend/dist')==before_front
 with sqlite3.connect(db) as con:assert con.execute('SELECT * FROM work').fetchall()==[('existing playlists and queue',)]
 print('PASS: actual seven-file source/extension/prebuilt frontend install, enable and rollback; nested new modules work; existing DB work preserved.')
# Existing input files must match the published viewer-removal build.
previous={f['path']:f['after_sha256'] for f in json.loads(Path('/workspace/ct109-remove-apple-viewer/app/manifest.json').read_text())['files']}
for item in m.MANIFEST['files']:
 if item['before_sha256']:assert previous[item['path']]==item['before_sha256']
print('PASS: both existing source files match the confirmed installed removal build.')
