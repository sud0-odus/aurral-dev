import test from "node:test";import assert from "node:assert/strict";
import { validateConnectorSession, getAppleWebToken } from "../../backend/services/connector/adapters.js";
import { apple } from "../../connector-extension/adapters/apple.js";
test("Apple accepts a verified library response and sends credentials only to the fixed Apple host", async()=>{
 const calls=[];const result=await validateConnectorSession("apple",{session:"private-session"},{webToken:async()=>"fixture-web-token",fetcher:async(url,options)=>{calls.push({url,options});return new Response(JSON.stringify({data:[]}));}});
 assert.equal(result.credentials.session,"private-session");assert.equal(calls[0].url,"https://amp-api.music.apple.com/v1/me/library/playlists?limit=1");assert.equal(calls[0].options.redirect,"error");assert.equal(calls[0].options.headers["Music-User-Token"],"private-session");
});
test("unknown services, malformed credentials, redirects and failed Apple authorization cannot connect",async()=>{
 for(const [service,credential] of [["spotify",{session:"x"}],["apple",{session:"bad\nheader"}]])await assert.rejects(validateConnectorSession(service,credential));
 for(const response of [new Response("{}",{status:401}),new Response("{}"),new Response("not json")])await assert.rejects(validateConnectorSession("apple",{session:"x"},{webToken:async()=>"fixture",fetcher:async()=>response}));
});
test("web token retrieval fetches only Apple-owned fixed paths and verifies issuer/expiry",async()=>{
 const token=`${Buffer.from('{}').toString('base64url').padEnd(16,'a')}.${Buffer.from(JSON.stringify({iss:"AMPWebPlay",exp:Math.floor(Date.now()/1000)+3600})).toString('base64url')}.fixturesignature`;
 const urls=[];const result=await getAppleWebToken(async url=>{urls.push(url);return new Response(url.endsWith("/browse")?'<script src="/assets/index~abc123.js"></script>':`const token="${token}"`);});
 assert.equal(result,token);assert.deepEqual(urls,["https://music.apple.com/us/browse","https://music.apple.com/assets/index~abc123.js"]);
});
test("extension Apple adapter reads just the named session cookie and expiry",async()=>{
 const calls=[];const value=await apple.capture({cookies:{get:async info=>{calls.push(info);return{value:"private",expirationDate:123};}}});
 assert.deepEqual(calls,[{url:"https://music.apple.com/",name:"media-user-token"}]);assert.deepEqual(value,{session:"private",expires:123000});
 assert.ok(apple.matches({removed:false,cookie:{name:"media-user-token",domain:".music.apple.com"}}));assert.ok(!apple.matches({removed:false,cookie:{name:"media-user-token",domain:"music.apple.com.evil.test"}}));
});
