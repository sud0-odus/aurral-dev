import test from "node:test";
import assert from "node:assert/strict";
import { setupIsolatedBackend, cleanupIsolatedState, resetDatabase } from "../helpers/backendTestHarness.js";
const [state, { db }, store] = await setupIsolatedBackend("connector", "backend/config/db-sqlite.js", "backend/services/connector/store.js");
test.after(() => cleanupIsolatedState(state));
test.beforeEach(() => resetDatabase(db));
const device = "fixture-device-12345678";
test("pairing intent is account-bound and consumed exactly once", () => {
 const intent = store.createIntent(1,"pair");
 assert.throws(()=>store.consumeIntent(2,intent.nonce,"pair"));
 store.consumeIntent(1,intent.nonce,"pair"); assert.throws(()=>store.consumeIntent(1,intent.nonce,"pair"));
 store.pairDevice(1,device); assert.equal(store.publicStatus(1).devices.length,1); assert.equal(store.publicStatus(2).devices.length,0);
 assert.equal(store.publicStatus(1).services.length,0);
});
test("capture cannot reuse pairing, switch service, or use another user's device", () => {
 const intent=store.createIntent(1,"capture","apple");
 assert.throws(()=>store.consumeIntent(1,intent.nonce,"pair"));assert.throws(()=>store.consumeIntent(1,intent.nonce,"capture","spotify"));
 store.pairDevice(1,device);assert.throws(()=>store.requireDevice(2,device));
 store.consumeIntent(1,intent.nonce,"capture","apple");
});
test("credentials are encrypted, excluded from status and isolated by user", () => {
 store.pairDevice(1,device);store.saveSession(1,device,"apple",{session:"PRIVATE_APPLE_SESSION"},null);
 const raw=db.prepare("SELECT value FROM settings WHERE key='browserConnectorV1'").get().value;
 assert.ok(raw.includes("AURRAL_ENC:"));assert.ok(!raw.includes("PRIVATE_APPLE_SESSION"));
 assert.deepEqual(store.readSession(1,"apple"),{session:"PRIVATE_APPLE_SESSION"});assert.equal(store.readSession(2,"apple"),null);
 assert.ok(!JSON.stringify(store.publicStatus(1)).includes("PRIVATE"));
 store.revoke(1,device);assert.equal(store.readSession(1,"apple"),null);assert.throws(()=>store.saveSession(1,device,"apple",{session:"x"},null));
});
test("expired and replaced requests cannot complete", t => {
 t.mock.timers.enable({apis:["Date"],now:Date.now()});
 const first=store.createIntent(1,"pair");store.createIntent(1,"capture","apple");assert.throws(()=>store.consumeIntent(1,first.nonce,"pair"));
 const second=store.createIntent(1,"pair");t.mock.timers.tick(300001);assert.throws(()=>store.consumeIntent(1,second.nonce,"pair"));
});
test("service disconnect preserves pairing and another account", () => {
 for(const user of [1,2]){store.pairDevice(user,device);store.saveSession(user,device,"apple",{session:`private-${user}`},null);}
 store.revoke(1,null,"apple");assert.equal(store.publicStatus(1).devices.length,1);assert.equal(store.readSession(1,"apple"),null);assert.ok(store.readSession(2,"apple"));
});

test("inherited object properties cannot impersonate a paired browser",()=>{store.pairDevice(1,device);assert.throws(()=>store.requireDevice(1,"propertyIsEnumerable"));});
