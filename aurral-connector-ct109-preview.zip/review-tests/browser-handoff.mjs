import {chromium} from '/workspace/aurral-dev/node_modules/playwright/index.mjs';
import assert from 'node:assert/strict';
import {requestFromTab,deliver} from '/workspace/aurral-dev/connector-extension/bridge.js';
const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
try{
 const context=await browser.newContext();let devices=[],services=[],current=null,captures=0;let nonce=0;
 await context.route('**/api/users/me/connector**',async route=>{
  const request=route.request();const url=new URL(request.url());const action=url.pathname.split('/connector')[1];let body={};
  if(!action)body={devices,services,available:[{id:'apple',name:'Apple Music'}]};
  else if(action==='/intent'){const data=request.postDataJSON();current={protocol:'aurral-connector-v1',userId:'1',nonce:`fixture-nonce-${++nonce}`,kind:data.kind,service:data.service||null,expires:Date.now()+300000};body=current;}
  else if(action==='/pair'){const data=request.postDataJSON();assert.equal(data.nonce,current.nonce);devices=[{id:data.deviceId}];body={ok:true};}
  else if(action==='/capture'){const data=request.postDataJSON();assert.equal(data.nonce,current.nonce);assert.equal(data.service,'apple');assert.equal(data.credential.session,'fixture-private-session');captures++;services=[{id:'apple'}];body={ok:true};}
  await route.fulfill({status:200,contentType:'application/json',body:JSON.stringify(body)});
 });
 const page=await context.newPage();await page.goto('http://127.0.0.1:4175/connector-preview.html');
 const api={scripting:{executeScript:async({func,args=[]})=>[{result:await page.evaluate(({code,args})=>(0,eval)(`(${code})`)(...args),{code:func.toString(),args})}]}};
 await page.getByRole('button',{name:'Pair Aurral Connector',exact:true}).waitFor();
 assert.ok(await page.getByRole('button',{name:'Connect Apple Music',exact:true}).isDisabled());
 await page.getByRole('button',{name:'Pair Aurral Connector',exact:true}).click();await page.locator('#aurral-connector-request').waitFor({state:'attached'});
 const pairing=await requestFromTab(api,1);assert.equal(pairing.kind,'pair');
 await deliver(api,1,pairing,{kind:'pair',deviceId:'fixture-device-123456'});
 await page.getByRole('button',{name:'Connect Apple Music',exact:true}).waitFor();assert.ok(await page.getByRole('button',{name:'Connect Apple Music',exact:true}).isEnabled());assert.equal(captures,0);
 await assert.rejects(deliver(api,1,pairing,{kind:'pair',deviceId:'fixture-device-123456'}));
 await page.getByRole('button',{name:'Connect Apple Music',exact:true}).click();await page.locator('#aurral-connector-request').waitFor({state:'attached'});
 const capture=await requestFromTab(api,1);assert.equal(capture.service,'apple');
 await assert.rejects(deliver(api,1,{...capture,origin:'https://wrong.invalid'},{kind:'capture'}));
 await deliver(api,1,capture,{kind:'capture',service:'apple',deviceId:'fixture-device-123456',credential:{session:'fixture-private-session'}});
 await page.getByText('Apple Music: Session connected').waitFor();assert.equal(captures,1);assert.ok(!(await page.locator('body').innerText()).includes('fixture-private-session'));
 await page.getByRole('button',{name:'Reconnect Apple Music',exact:true}).click();await page.locator('#aurral-connector-request').waitFor({state:'attached'});const cancelled=await requestFromTab(api,1);await page.getByRole('button',{name:'Cancel request',exact:true}).click();
 await assert.rejects(deliver(api,1,cancelled,{kind:'capture',service:'apple',credential:{session:'never-delivered'}}));assert.equal(captures,1);
 console.log('PASS: real React/browser handoff separates pairing and capture; acknowledges completion; rejects replay, wrong origin and cancelled requests; never renders credentials. Chrome API transport is a test shim, not a loaded extension.');
}finally{await browser.close();}
