import test from 'node:test';import assert from 'node:assert/strict';
globalThis.chrome={permissions:{onAdded:{addListener(){}}},runtime:{onMessage:{addListener(){}},id:'fixture'},cookies:{onChanged:{addListener(){}}}};
const {finishPending}=await import('../../connector-extension/background.js');
function fake({paired=true,pending=true,expired=false}={}){
 const request={origin:'https://aurral.invalid',userId:'1',service:'apple',nonce:'fixture-request',expires:Date.now()+(expired?-1:60000)};
 const local={pairings:paired?{'https://aurral.invalid|1':'device'}:{}};
 const session=pending?{pending:{tabId:4,request,deviceId:'device'}}:{};const calls=[];
 const storage=(data)=>({get:async()=>({...data}),set:async value=>Object.assign(data,value),remove:async key=>{delete data[key];}});
 const api={storage:{local:storage(local),session:storage(session)},cookies:{get:async query=>{calls.push({query});return{value:'PRIVATE_SESSION'};}},scripting:{executeScript:async options=>{calls.push({delivery:options.args});return[{result:{ok:true}}];}}};
 return{api,local,session,calls};
}
test('install/pair alone never reads a cookie',async()=>{const f=fake({pending:false});await finishPending(f.api);assert.deepEqual(f.calls,[]);});
test('unpaired or expired requests are discarded without cookie access',async()=>{for(const options of [{paired:false},{expired:true}]){const f=fake(options);await finishPending(f.api);assert.deepEqual(f.calls,[]);assert.ok(!f.session.pending);}});
test('capture sends one named service cookie and never stores it',async()=>{const f=fake();await finishPending(f.api);assert.equal(f.calls.length,2);assert.deepEqual(f.calls[0].query,{url:'https://music.apple.com/',name:'media-user-token'});assert.equal(f.calls[1].delivery[1].credential.session,'PRIVATE_SESSION');assert.equal(f.calls[1].delivery[0].origin,'https://aurral.invalid');assert.ok(!JSON.stringify([f.local,f.session]).includes('PRIVATE_SESSION'));assert.ok(!f.session.pending);});
test('failed or missing cookie permission cannot complete a handoff',async()=>{const f=fake();f.api.cookies=undefined;await finishPending(f.api);assert.ok(!f.calls.length);assert.match(f.session.notice,/ended/);assert.ok(!f.session.pending);});
