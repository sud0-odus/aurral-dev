# Aurral Connector preview

This is a reusable Manifest V3 browser connector. Installing it does not connect
Apple or grant access to streaming sessions. Pairing and service authorization
are separate actions. Apple Music is the first service adapter; Spotify and
other service adapters are not implemented in this release.

## Install once (Chrome / Edge)

1. Extract the extension ZIP into a folder you will keep.
2. Open chrome://extensions or edge://extensions.
3. Enable Developer mode, select Load unpacked, and choose the folder containing
   manifest.json. Pin Aurral Connector to the toolbar if helpful.
4. In Aurral Profile, create a Pair Aurral Connector request. While that Aurral tab
   is active, open the toolbar extension and approve pairing with that server.

## Connect a service separately

In Aurral Profile choose Connect Apple Music. Open the connector toolbar icon
while that Aurral tab is active and approve Apple-specific access. It uses the
Apple Music account currently signed in in that browser profile. Sign into the
intended account on Apple's website first if you use multiple Apple accounts.
If not signed in, a regular Apple Music tab opens. Keep the Aurral tab open;
its active login and a short-lived, account-bound request complete the handoff.

Captured session values are not stored by the extension. It stores only a random
installation ID and the servers/accounts explicitly paired with it. A pending
handoff lives in Chrome session storage for at most five minutes; expired requests
cannot deliver. Aurral validates the Apple session before storing it encrypted
for the authenticated user. Removing a paired browser revokes the service sessions
associated with that browser. Browser-level permissions can be removed in the
browser's extension settings.

## Adding services

Each service needs a separately reviewed extension adapter under adapters/ and
a matching server validator in backend/services/connector/adapters.js. Its host
access must be declared optional and requested only when the user connects it.
Do not add generic all-cookie export or arbitrary destination URLs. Services with
existing OAuth authorization should use that authorization instead of capturing
sessions unnecessarily. There are no hosted browser processes or custom remote
viewers in this implementation.

## Test limits

The cloud's managed Chromium blocks unpacked extension installation. Unit tests
and the actual React/browser-message handoff are exercised with a Chrome API
transport shim. Extension installation, optional permission prompts and a real
Apple session still require a check in a user's Chrome/Edge browser. No live Apple
connection is claimed solely from these local tests. Session connection is the
first stage; playlist import and personal discovery seeding are not added here.
