export async function requestFromTab(api, tabId) {
  const [result] = await api.scripting.executeScript({ target: { tabId }, func: () => {
    const node = document.getElementById("aurral-connector-request");
    if (!node) return null;
    const request = JSON.parse(node.textContent);
    if (request.protocol !== "aurral-connector-v1" || !["http:", "https:"].includes(location.protocol)) return null;
    return { ...request, origin: location.origin };
  } });
  return result?.result;
}
export async function deliver(api, tabId, request, message) {
  const [result] = await api.scripting.executeScript({ target: { tabId }, args: [request, message], func: async (expected, payload) => {
    if (location.origin !== expected.origin) throw new Error("Aurral tab changed");
    const node = document.getElementById("aurral-connector-request");
    const current = node && JSON.parse(node.textContent);
    if (!current || current.nonce !== expected.nonce || current.userId !== expected.userId || current.expires <= Date.now()) throw new Error("Create a fresh request in Aurral");
    return new Promise((resolve) => {
      const timer = setTimeout(() => { window.removeEventListener("message", receive); resolve({ ok: false, error: "Aurral did not confirm the request" }); }, 55000);
      function receive(event) {
        if (event.source !== window || event.origin !== location.origin || event.data?.type !== "aurral-connector-result" || event.data.nonce !== expected.nonce) return;
        clearTimeout(timer); window.removeEventListener("message", receive); resolve({ ok: event.data.ok === true });
      }
      window.addEventListener("message", receive);
      window.postMessage({ type: "aurral-connector-submit", nonce: expected.nonce, ...payload }, location.origin);
    });
  } });
  if (!result?.result?.ok) throw new Error("Aurral did not accept the connection. Check its Profile page.");
}
export const pairingKey = (request) => `${request.origin}|${request.userId}`;
