import { apple } from "./apple.js";
// Add independently reviewed service adapters here; no arbitrary cookie export.
export const adapters = new Map([[apple.id, apple]]);
