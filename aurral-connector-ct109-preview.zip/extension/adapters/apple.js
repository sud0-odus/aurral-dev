export const apple = {
  id: "apple", name: "Apple Music", origins: ["https://music.apple.com/*"], loginUrl: "https://music.apple.com/",
  async capture(api) {
    const cookie = await api.cookies.get({ url: "https://music.apple.com/", name: "media-user-token" });
    if (!cookie?.value) return null;
    return { session: cookie.value, expires: cookie.expirationDate ? cookie.expirationDate * 1000 : null };
  },
  matches(change) { return !change.removed && change.cookie?.name === "media-user-token" && /(^|\.)music\.apple\.com$/.test(change.cookie.domain.replace(/^\./, "")); },
};
