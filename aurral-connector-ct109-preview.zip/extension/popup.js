import { adapters } from "./adapters/index.js";
import { deliver, requestFromTab, pairingKey } from "./bridge.js";
const status = document.getElementById("status"), action = document.getElementById("action");
let context;
async function initialize() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  const request = await requestFromTab(chrome, tab.id);
  if (!request || request.expires <= Date.now()) return;
  const saved = await chrome.storage.local.get(["deviceId", "pairings"]);
  const deviceId = saved.deviceId || crypto.randomUUID();
  await chrome.storage.local.set({ deviceId });
  context = { request, tabId: tab.id, deviceId };
  document.getElementById("server").textContent = `Aurral server: ${request.origin}`;
  if (request.kind === "pair") {
    status.textContent = "Pair this browser with the signed-in account on this Aurral server? No streaming sessions are read during pairing.";
    action.textContent = "Pair this browser";
  } else {
    if (saved.pairings?.[pairingKey(request)] !== deviceId) { status.textContent = "Pair this browser with this Aurral account first."; return; }
    const adapter = adapters.get(request.service);
    if (!adapter) { status.textContent = "This connector version does not support that service."; return; }
    status.textContent = `Connect the ${adapter.name} account currently signed in in this browser. If needed, sign into the intended account on its website first.`;
    action.textContent = `Allow ${adapter.name} connection`;
  }
  action.hidden = false;
}
action.onclick = async () => {
  // Request optional access directly from this explicit user click.
  const { request, tabId, deviceId } = context;
  const adapter = request.kind === "capture" && adapters.get(request.service);
  const permission = adapter ? chrome.permissions.request({ permissions: ["cookies"], origins: adapter.origins }) : Promise.resolve(true);
  action.disabled = true;
  try {
    if (!(await permission)) throw new Error("Service permission was not granted.");
    if (request.kind === "pair") {
      await deliver(chrome, tabId, request, { kind: "pair", deviceId });
      const { pairings = {} } = await chrome.storage.local.get("pairings");
      pairings[pairingKey(request)] = deviceId;
      await chrome.storage.local.set({ pairings });
      status.textContent = "Paired. Choose a service in Aurral when you want to connect it.";
    } else {
      await chrome.storage.session.set({ pending: { tabId, request, deviceId } });
      await chrome.runtime.sendMessage({ type: "capture-pending" });
      const { pending, notice } = await chrome.storage.session.get(["pending", "notice"]);
      if (pending) { await chrome.tabs.create({ url: adapter.loginUrl }); status.textContent = "Sign in through the normal service tab. Keep the Aurral tab open; the connector will finish there."; }
      else status.textContent = notice || "Return to Aurral for the result.";
    }
    action.hidden = true;
  } catch (error) { status.textContent = error.message || "Connection failed. Return to Aurral."; action.disabled = false; }
};
initialize().catch(() => { status.textContent = "Open your Aurral Profile, create a pairing or service request, then reopen this extension."; });
