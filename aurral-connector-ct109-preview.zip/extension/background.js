import { adapters } from "./adapters/index.js";
import { deliver, pairingKey } from "./bridge.js";
let completing = false;
let rerun = false;
export async function finishPending(api = chrome) {
  if (completing) { rerun = true; return; }
  completing = true;
  let ownedNonce;
  try {
    const { pending } = await api.storage.session.get("pending");
    if (!pending) return;
    ownedNonce = pending.request.nonce;
    if (pending.request.expires <= Date.now()) { await api.storage.session.remove("pending"); return; }
    const { pairings = {} } = await api.storage.local.get("pairings");
    if (pairings[pairingKey(pending.request)] !== pending.deviceId) { await api.storage.session.remove("pending"); return; }
    const adapter = adapters.get(pending.request.service);
    if (!adapter) throw new Error("Unsupported service");
    const credential = await adapter.capture(api);
    if (!credential) return;
    // Erase the pending request before sending; credentials are never stored.
    await api.storage.session.remove("pending");
    await deliver(api, pending.tabId, pending.request, { kind: "capture", service: adapter.id, deviceId: pending.deviceId, credential });
    await api.storage.session.set({ notice: "Service connected. Return to Aurral." });
  } catch {
    const { pending } = await api.storage.session.get("pending");
    if (pending?.request.nonce === ownedNonce) await api.storage.session.remove("pending");
    await api.storage.session.set({ notice: "Connection ended. Check Aurral and create a fresh request." });
  } finally {
    completing = false;
    if (rerun) { rerun = false; void finishPending(api); }
  }
}
let listening = false;
function listenForServiceChanges() {
  if (listening || !chrome.cookies?.onChanged) return;
  listening = true;
  chrome.cookies.onChanged.addListener(change => {
    if ([...adapters.values()].some(adapter => adapter.matches(change))) void finishPending();
  });
}
listenForServiceChanges();
chrome.permissions.onAdded.addListener(listenForServiceChanges);
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.id !== chrome.runtime.id || message?.type !== "capture-pending") return;
  void finishPending().then(() => respond({ ok: true })); return true;
});
