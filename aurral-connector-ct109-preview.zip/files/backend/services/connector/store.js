import crypto from "node:crypto";
import { db } from "../../config/db-sqlite.js";
import { getSettingsEncryptionKey } from "../../db/helpers/settings.js";
import { encryptWithKey, decryptWithKey } from "../../config/encryption.js";

const KEY = "browserConnectorV1";
const intents = new Map();
const read = () => JSON.parse(db.prepare("SELECT value FROM settings WHERE key=?").get(KEY)?.value || "{}");
const write = (value) => db.prepare("INSERT OR REPLACE INTO settings(key,value) VALUES (?,?)").run(KEY, JSON.stringify(value));
const uid = (id) => String(id);
const key = () => { const value = getSettingsEncryptionKey(); if (!value || value.length !== 32) throw new Error("Connector encryption is unavailable"); return value; };
export const validDevice = (id) => typeof id === "string" && /^[a-zA-Z0-9-]{16,80}$/.test(id);
export function createIntent(userId, kind, service = null) {
  const now = Date.now();
  for (const [nonce, intent] of intents) if (intent.expires <= now || intent.userId === uid(userId)) intents.delete(nonce);
  if (intents.size >= 100) throw new Error("Connection capacity reached");
  const nonce = crypto.randomBytes(32).toString("base64url");
  const intent = { userId: uid(userId), kind, service, expires: now + 5 * 60000 };
  intents.set(nonce, intent);
  return { protocol: "aurral-connector-v1", userId: uid(userId), nonce, kind, service, expires: intent.expires };
}
export function consumeIntent(userId, nonce, kind, service = null) {
  const item = intents.get(nonce);
  if (!item || item.userId !== uid(userId) || item.kind !== kind || item.service !== service || item.expires <= Date.now()) throw new Error("Connection request expired or belongs to another account");
  intents.delete(nonce);
}
export function publicStatus(userId) {
  const saved = read()[uid(userId)] || { devices: {}, services: {} };
  return { devices: Object.entries(saved.devices).map(([id, value]) => ({ id, ...value })),
    services: Object.entries(saved.services).filter(([, value]) => !value.expires || value.expires > Date.now()).map(([id, value]) => ({ id, connectedAt: value.connectedAt, expires: value.expires || null })) };
}
export function pairDevice(userId, deviceId) {
  if (!validDevice(deviceId)) throw new Error("Invalid connector identifier");
  const data = read(); const user = data[uid(userId)] ||= { devices: {}, services: {} };
  if (Object.keys(user.devices).length >= 8 && !user.devices[deviceId]) throw new Error("Remove an old connector before pairing another");
  user.devices[deviceId] = { pairedAt: Date.now() }; write(data);
}
export function requireDevice(userId, deviceId) {
  const devices = read()[uid(userId)]?.devices || {};
  if (!validDevice(deviceId) || !Object.hasOwn(devices, deviceId)) throw new Error("Pair this connector with your account first");
}
export function saveSession(userId, deviceId, service, credentials, expires) {
  requireDevice(userId, deviceId);
  const data = read(); const user = data[uid(userId)];
  const encrypted = encryptWithKey(JSON.stringify(credentials), key());
  if (!encrypted.startsWith("AURRAL_ENC:")) throw new Error("Connector encryption failed");
  user.services[service] = { encrypted, deviceId, connectedAt: Date.now(), expires }; write(data);
}
export function readSession(userId, service) {
  const saved = read()[uid(userId)]?.services?.[service];
  if (!saved || (saved.expires && saved.expires <= Date.now())) return null;
  const value = decryptWithKey(saved.encrypted, key());
  if (typeof value !== "string" || value.startsWith("AURRAL_ENC:")) return null;
  try { return JSON.parse(value); } catch { return null; }
}
export function revoke(userId, deviceId = null, service = null) {
  const data = read(); const user = data[uid(userId)]; if (!user) return;
  if (deviceId) { delete user.devices[deviceId]; for (const [id, session] of Object.entries(user.services)) if (session.deviceId === deviceId) delete user.services[id]; }
  if (service) delete user.services[service];
  for (const [nonce, item] of intents) if (item.userId === uid(userId)) intents.delete(nonce);
  write(data);
}
