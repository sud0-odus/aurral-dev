// Each service owns its credential validation; capture is never arbitrary URLs/cookies.
let cached, pending;
async function boundedText(url, maximum, fetcher) {
  const response = await fetcher(url, { signal: AbortSignal.timeout(15000), redirect: "error", headers: { "User-Agent": "Mozilla/5.0" } });
  if (!response.ok) throw new Error("Apple connection could not be validated");
  const reader = response.body.getReader(); const chunks = []; let size = 0;
  try { while (true) { const { done, value } = await reader.read(); if (done) break; size += value.length; if (size > maximum) throw new Error("Apple response exceeded its limit"); chunks.push(Buffer.from(value)); } }
  finally { await reader.cancel(); }
  return Buffer.concat(chunks).toString("utf8");
}
export async function getAppleWebToken(fetcher = fetch) {
  if (cached?.expires > Date.now()) return cached.token;
  if (pending) return pending;
  pending = (async () => {
    const html = await boundedText("https://music.apple.com/us/browse", 2000000, fetcher);
    const bundle = html.match(/\/assets\/index~[A-Za-z0-9]+\.js/)?.[0];
    if (!bundle) throw new Error("Apple web authorization format changed");
    const js = await boundedText(`https://music.apple.com${bundle}`, 12000000, fetcher);
    for (const token of js.match(/[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{10,}/g) || []) {
      try { const claims = JSON.parse(Buffer.from(token.split(".")[1], "base64url"));
        if (claims.iss === "AMPWebPlay" && claims.exp * 1000 > Date.now() + 60000) {
          cached = { token, expires: Math.min(claims.exp * 1000 - 60000, Date.now() + 3600000) }; return token;
        }
      } catch { /* Ignore unrelated bundle strings. */ }
    }
    throw new Error("Apple web authorization is unavailable");
  })();
  try { return await pending; } finally { pending = null; }
}
async function validateAppleSession(credential, { fetcher = fetch, webToken = getAppleWebToken } = {}) {
  if ( typeof credential?.session !== "string" || !credential.session || credential.session.length > 16000 || /[\r\n]/.test(credential.session)) throw new Error("Invalid service session");
  const authorization = await webToken(fetcher);
  const headers = { Authorization: `Bearer ${authorization}`, "Music-User-Token": credential.session, Origin: "https://music.apple.com", Referer: "https://music.apple.com/" };
  const text = await boundedText("https://amp-api.music.apple.com/v1/me/library/playlists?limit=1", 1000000,
    (url, options) => fetcher(url, { ...options, headers: { ...options.headers, ...headers } }));
  let body; try { body = JSON.parse(text); } catch { throw new Error("Apple returned an invalid response"); }
  if (!Array.isArray(body.data)) throw new Error("Apple did not confirm access to the library");
  return { credentials: { session: credential.session }, expires: Number.isFinite(credential.expires) && credential.expires > Date.now() ? credential.expires : null };
}

const registry = new Map([
  ["apple", { id: "apple", name: "Apple Music", method: "browser-session", validate: validateAppleSession }],
]);
export const connectorServices = [...registry.values()].map(({ id, name, method }) => ({ id, name, method }));
export async function validateConnectorSession(service, credential, options) {
  const adapter = registry.get(service);
  if (!adapter) throw new Error("Unsupported connector service");
  return adapter.validate(credential, options);
}
