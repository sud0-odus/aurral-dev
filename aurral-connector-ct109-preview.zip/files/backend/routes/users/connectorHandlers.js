import { requireAuth, requireUserAccount } from "../../middleware/requirePermission.js";
import * as store from "../../services/connector/store.js";
import { connectorServices, validateConnectorSession } from "../../services/connector/adapters.js";
export function registerConnector(router, { validate = validateConnectorSession } = {}) {
  const guard = [requireAuth, requireUserAccount];
  const wrap = (fn) => async (req, res) => {
    res.set("Cache-Control", "no-store");
    try { await fn(req, res); } catch { res.status(400).json({ error: "Connector request failed. Check the account, pairing and service session, then create a fresh request." }); }
  };
  const root = "/me/connector";
  router.get(root, ...guard, wrap((req, res) => res.json({ ...store.publicStatus(req.user.id), available: connectorServices })));
  router.post(`${root}/intent`, ...guard, wrap((req, res) => {
    const { kind, service } = req.body || {};
    if (kind !== "pair" && !(kind === "capture" && connectorServices.some(s => s.id === service))) return res.status(400).json({ error: "Unsupported connector operation" });
    res.json(store.createIntent(req.user.id, kind, kind === "capture" ? service : null));
  }));
  router.post(`${root}/pair`, ...guard, wrap((req, res) => {
    store.consumeIntent(req.user.id, req.body?.nonce, "pair"); store.pairDevice(req.user.id, req.body?.deviceId); res.json({ ok: true });
  }));
  router.post(`${root}/capture`, ...guard, wrap(async (req, res) => {
    const { nonce, service, deviceId, credential } = req.body || {};
    store.requireDevice(req.user.id, deviceId);
    store.consumeIntent(req.user.id, nonce, "capture", service);
    const result = await validate(service, credential);
    // Recheck pairing after external validation so concurrent revocation wins.
    store.saveSession(req.user.id, deviceId, service, result.credentials, result.expires);
    res.json({ ok: true });
  }));
  router.delete(`${root}/devices/:id`, ...guard, wrap((req, res) => { store.revoke(req.user.id, req.params.id); res.json({ ok: true }); }));
  router.delete(`${root}/services/:id`, ...guard, wrap((req, res) => { store.revoke(req.user.id, null, req.params.id); res.json({ ok: true }); }));
}
