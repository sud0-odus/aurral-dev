# CT109 duration references and release-refresh batching (patch 4)

Requires Aurral v2.11.0 with matching-batch patch 3 installed. Incremental backend update; no dependency install or frontend build.

## Changes

- When the existing track resolver still has no positive reference duration, it makes at most one additional Last.fm album.getInfo request, using the existing Last.fm client/cache/rate limiter. Timeout five seconds, no retries. It accepts a seconds-to-milliseconds duration only for the exact normalized artist credit, album title and one unambiguous matching track title. Different versions/editions, conflicting track artists, duplicate titles and invalid lengths are rejected. Album titles and track titles retain version words during comparison. Existing release/request/track.getInfo reference durations take precedence. The downloaded candidate's length is never used to invent its own reference, and this fallback does not invent recording IDs.
- Valid duration evidence in a pipeline payload survives an invalid/zero stored placeholder. Alternate pressing durations survive reconstruction of the track request.
- Review messages distinguish an unreadable file duration from a missing requested recording duration. Duration mismatch wording uses the nearest permitted reference length.
- Successful Library scans request release-metadata work in a fixed ten-minute batching window instead of five seconds. Repeated scans preserve the first deadline; manual requests can expedite it. Existing per-artist success/failure refresh intervals are retained. This batches this one scan-triggered task, not all scheduled tasks.
- Queue concurrency remains two, with the existing six-job admission limit. Earlier patches and the installed user-initial UI are retained.

## Limits

The fallback can help when Last.fm's album tracklist supplies a duration absent from track.getInfo; it cannot guarantee metadata exists for every track. A configured API key is not proof of a successful lookup. Missing metadata remains unresolved rather than weakening the existing match thresholds.

Existing Review jobs are not bulk approved, retried or rewritten. The changes apply when the normal resolver/validator next runs for a job. Other title, artist, version and quality checks still apply. No new broad profiling collection is required to install this patch.

## Install from Proxmox

After downloading/extracting the kit inside CT109:

```
pct exec 109 -- python3 /tmp/aurral-ct109-duration-refresh-patch/apply-patch.py --check
pct exec 109 -- python3 /tmp/aurral-ct109-duration-refresh-patch/apply-patch.py --install
pct exec 109 -- python3 /tmp/aurral-ct109-duration-refresh-patch/apply-patch.py --enable
```

Check validates the exact previous source and payload. Install stops aurral.service, creates private source/database backups under /opt/aurral-patch-backups/duration-refresh-*, installs the backend changes and leaves Aurral stopped. Enable starts it and verifies health/matcher checks. The installer does not edit settings, queue rows or media. Fifteen source files are checked, including ten unchanged guards and five changes. The marker is /opt/aurral-duration-refresh-patch.json. Keep the earlier backups.

## Rollback this patch

```
pct exec 109 -- python3 /tmp/aurral-ct109-duration-refresh-patch/apply-patch.py --rollback
pct exec 109 -- systemctl start aurral.service
```

Restores pre-patch source and preserves the current database and completed work. Do not use an earlier kit's rollback to undo patch 4.

The optional collector/launcher are included for convenience, but another broad profile is not required now. The two inspect scripts remain read-only; no credentials or production reports are included in this package. The Lidarr diagnostic only checks saved credentials and therefore cannot rule out an environment-configured connection.
