# Validation: configurable Lidarr library exclusions, patch 5

- Broad regression: 1,664 passed, zero failed/skipped/cancelled across Library,
  playlists, downloads, track matching, Honker, settings and frontend helper
  suites. Two-test concurrency under a two-CPU/3 GiB process-group guard;
  peak 950.2 MiB, elapsed 329.7 seconds.
- Final focused boundary/settings checks after tightening path validation:
  30 passed, zero failures; peak 164.8 MiB, 12 seconds. Earlier focused scan,
  watcher, settings and settings-search set: 64 passed. Counts overlap.
- Full/targeted scan regression seeds a hardlinked canonical/aliased file,
  previously indexed transfer files and legitimate imported tracks. Exclusions
  prevent traversal/metadata reads of excluded trees, remove only their index
  records, retain canonical/ordinary files and preserve all physical files.
  Subsequent targeted imports still appear.
- Empty configuration excludes no deployment-specific folder names. Custom
  roots and nested exclusions work; excluding the Lidarr view preserves
  Aurral ownership of its canonical root. Component-prefix boundaries avoid
  matching similarly named sibling folders. Normalization rejects malformed,
  relative, filesystem-root and excessive input.
- API tests verify persistence, clearing, partial-save preservation, normalized
  GET values, invalid-value rejection before writes, one reconciliation for
  active changes, no root-discovery request for exclusion edits and no extra
  reconciliation for reordered equivalent lists.
- Watcher tests verify that excluded directories are never recursively
  registered/traversed, nested exclusion ancestors are split, new artists
  generate updates, canonical Aurral/imported paths remain active, mapping is
  applied before matching, limits/failures release handles, and the API stays
  responsive while an isolated watcher child blocks.
- Real isolated watcher tests run against temporary local directories, both
  directly and through remote path mappings. Excluded transfers/aliases emit
  no changes; ordinary nested files and newly added artists still do.
- Browser component check: empty initial value, multiline editing with a pause
  after newline, no partial-path updates during typing, commit on leaving the
  field, clearing the list, desktop/mobile layout and no page errors. The full
  frontend builds successfully; final build peak 889.4 MiB, 4.0 seconds.
- Scoped backend/frontend ESLint and git diff --check pass.
- Installer: 17 tests pass, covering unknown/corrupt files, introduction/removal
  of the new module, interrupted installs, failures after atomic file creation,
  later user edits, frontend backup/restore, current-database preservation and
  code/frontend/new-module rollback together. Final installer test peak 58 MiB.
- Actual 25-file payload and prebuilt frontend pass source/payload hashes and
  syntax checks against a synthetic pre-patch app, then install/enable/rollback
  with service and health calls mocked. Current fixture DB work survives;
  previous UI/source return and only the introduced module is removed.

No direct production CT109 connection was made. Live throughput and absence
of all physical duplicate music files are not established by these checks.
The default exclusion list is empty. Deployment-specific paths are entered
through the UI by the operator; the installer inserts none and edits no
settings/queue/database rows. No production reports or credentials are shipped.
