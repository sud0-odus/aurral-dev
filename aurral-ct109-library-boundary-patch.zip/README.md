# Aurral v2.11 configurable Lidarr library exclusions (CT109 patch 5)

Requires the duration-refresh-4 update. Adds an editable exclusion list in
Settings > Lidarr > Library scanning > Excluded folders. A rebuilt frontend is
included; no dependency install or container-side build is required.

## Behavior

The setting is integrations.lidarr.scanExclusions, an array of absolute LOCAL
folder paths. It defaults to an empty list. There are no deployment-specific
paths compiled into the application or inserted by the installer. The form
accepts one path per line. Finish editing and click outside the field to
commit the whole list through the normal settings autosave. This prevents
partial paths from restarting watchers on each typing pause. Saving
normalizes/deduplicates paths. Paths can be
changed or cleared in the UI. Up to 64 entries are supported. Relative paths,
NUL/newline-containing paths, overly long paths and the filesystem root are
rejected. Folder existence is not checked synchronously on the API thread.

Paths are compared in Aurral's local Lidarr-library view, after root path
mapping. An exclusion skips that folder and all descendants for full/targeted
Lidarr library scans and watches. Aurral's own download-root scanning and
watching remain active. Exclusions do not delete music, move files, change
Lidarr acquisition settings or prevent Lidarr itself from importing files.

When exclusions change while Lidarr is connected, saving queues a coalesced
library reconciliation and restarts automatic watching using the new list.
Unchanged/reordered equivalent lists do not queue another reconciliation.
Unrelated partial settings saves preserve the list. A reconciliation can
remove excluded file records from Aurral's Lidarr index; media files remain.

A recursive watcher has no native ignore option. The isolated child now splits
watching only along ancestors of excluded folders, watching permitted branches
recursively. Excluded subtrees are never recursively registered. New artists
and nested directories still generate changes; failures release watchers and
leave manual refresh available. There is a limit of 1024 explicit watcher
registrations per root, with a visible error/manual-refresh fallback instead of
unbounded split registrations. Existing watcher process isolation is retained.

## Apply to CT109

Run check, install and enable using apply-patch.py. Installation stops Aurral,
backs up its database, source and frontend locally, installs the update, and
leaves Aurral stopped until enable. It does not edit application settings or
queue rows. Existing source hashes must match patch 4 exactly. The new helper
module must be absent before installation. Unknown edits are refused.

Marker: /opt/aurral-library-boundary-patch.json
Backups: /opt/aurral-patch-backups/library-boundary-*

After enable, refresh the browser. Before connecting Lidarr, enter the local
folders you want excluded. For the layout established in CT109's inventory,
the suggested entries are:

```
/music/Aurral
/music/Downloads
```

These are deployment instructions, NOT application defaults. Aurral keeps
indexing its own output through /downloads/aurral. Lidarr's imported music
outside those folders remains available through /music. Use the alias paths
inside the Lidarr root, rather than the canonical /downloads paths.

You can save the exclusions while Lidarr is unconfigured, then configure the
Lidarr URL/API key and save. Keep monitoring/search-on-add as previously chosen.
No broad profiling or duplicate deletion is required. Verify that one known
Lidarr-imported album appears and plays, and that existing Aurral music remains.

## Rollback

Use this kit's apply-patch.py --rollback. It restores previous code/frontend,
removes only the helper module introduced by this patch, preserves the current
database and leaves Aurral stopped. Existing backups/markers are retained.
Previous code does not enforce the new exclusion setting. Reassess the Lidarr
connection before restarting without the boundary protection. Clearing the
list in the new UI restores ordinary scanning without a code rollback.

The update changes CT109 application code/UI only. It does not repair or
reconfigure other containers, change mounts or copy existing music. Existing
library reuse, source priorities and worker concurrency are preserved. This
prevents the configured overlap from being indexed through the Lidarr view;
it is not a content-hash deduplication tool or a guarantee against separate
acquisitions of different versions/qualities.
